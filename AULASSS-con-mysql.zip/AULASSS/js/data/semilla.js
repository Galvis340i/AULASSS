import { Almacen, obtenerBase, siguienteId } from './almacen.js';
import { cifrarContrasena } from '../utils/cifrado.js';
import { ROLES } from './constantes.js';

// Contraseña de demostración común para todas las cuentas semilla.
const CONTRASENA_DEMO = 'Institucion2026';

export async function sembrarSiVacio() {
  const base = obtenerBase();
  if (base.usuarios.length > 0) {
    completarDatosAcademicos();
    sembrarCiclo2SiCorresponde();
    sembrarCiclo3SiCorresponde();
    return;
  }

  const facultades = [
    { facultad_id: siguienteId('facultad'), facultad_nombre: 'Ciencias Agronómicas', facultad_estado: 'Activa' },
    { facultad_id: siguienteId('facultad'), facultad_nombre: 'Ciencias Humanas', facultad_estado: 'Activa' },
    { facultad_id: siguienteId('facultad'), facultad_nombre: 'Ingeniería', facultad_estado: 'Activa' },
  ];
  Almacen.reemplazarColeccion('facultades', facultades);

  const [agronomicas, humanas, ingenieria] = facultades;

  const carreras = [
    { carrera_id: siguienteId('carrera'), carrera_nombre: 'Ingeniería Agronómica', facultad_id: agronomicas.facultad_id, carrera_estado: 'Activa' },
    { carrera_id: siguienteId('carrera'), carrera_nombre: 'Ingeniería Ambiental', facultad_id: agronomicas.facultad_id, carrera_estado: 'Activa' },
    { carrera_id: siguienteId('carrera'), carrera_nombre: 'Psicología', facultad_id: humanas.facultad_id, carrera_estado: 'Activa' },
    { carrera_id: siguienteId('carrera'), carrera_nombre: 'Administración', facultad_id: humanas.facultad_id, carrera_estado: 'Activa' },
    { carrera_id: siguienteId('carrera'), carrera_nombre: 'Contaduría', facultad_id: humanas.facultad_id, carrera_estado: 'Activa' },
    { carrera_id: siguienteId('carrera'), carrera_nombre: 'Ingeniería de Sistemas', facultad_id: ingenieria.facultad_id, carrera_estado: 'Activa' },
    { carrera_id: siguienteId('carrera'), carrera_nombre: 'Ingeniería Industrial', facultad_id: ingenieria.facultad_id, carrera_estado: 'Activa' },
    { carrera_id: siguienteId('carrera'), carrera_nombre: 'Ingeniería Electrónica', facultad_id: ingenieria.facultad_id, carrera_estado: 'Activa' },
    { carrera_id: siguienteId('carrera'), carrera_nombre: 'Ingeniería Ambiental', facultad_id: ingenieria.facultad_id, carrera_estado: 'Activa' },
  ];
  Almacen.reemplazarColeccion('carreras', carreras);

  const hash = await cifrarContrasena(CONTRASENA_DEMO);
  const usuariosSemilla = [
    { usu_nombres: 'Laura', usu_apellidos: 'Ramírez', usu_correo: 'admin.sistema@uninstitucional.edu.co', usu_rol: ROLES.ADMIN_SISTEMA, facultad_id: null },
    { usu_nombres: 'Carlos', usu_apellidos: 'Peña', usu_correo: 'coordinador.ingenieria@uninstitucional.edu.co', usu_rol: ROLES.COORDINADOR, facultad_id: ingenieria.facultad_id },
    { usu_nombres: 'Marcela', usu_apellidos: 'Gómez', usu_correo: 'docente.demo@uninstitucional.edu.co', usu_rol: ROLES.DOCENTE, facultad_id: ingenieria.facultad_id },
    { usu_nombres: 'Andrés', usu_apellidos: 'Torres', usu_correo: 'plantafisica@uninstitucional.edu.co', usu_rol: ROLES.ADMIN_PLANTA, facultad_id: null },
    { usu_nombres: 'Diana', usu_apellidos: 'Salas', usu_correo: 'decano.ingenieria@uninstitucional.edu.co', usu_rol: ROLES.DECANO, facultad_id: ingenieria.facultad_id },
  ].map((u) => ({
    usu_id: siguienteId('usuario'),
    usu_pwd_hash: hash,
    usu_estado: 'Activo',
    ...u,
  }));

  Almacen.reemplazarColeccion('usuarios', usuariosSemilla);
  sembrarCiclo2SiCorresponde();
  sembrarCiclo3SiCorresponde();
}


function completarDatosAcademicos() {
  const base = obtenerBase();
  const ingenieria = base.facultades.find((f) => f.facultad_nombre === 'Ingeniería');
  if (ingenieria) {
    const nombres = ['Ingeniería de Sistemas', 'Ingeniería Industrial', 'Ingeniería Electrónica', 'Ingeniería Ambiental'];
    const carreras = [...base.carreras];
    for (const nombre of nombres) {
      if (!carreras.some((c) => c.facultad_id === ingenieria.facultad_id && c.carrera_nombre === nombre)) {
        carreras.push({ carrera_id: siguienteId('carrera'), carrera_nombre: nombre, facultad_id: ingenieria.facultad_id, carrera_estado: 'Activa' });
      }
    }
    Almacen.reemplazarColeccion('carreras', carreras);
  }
  if (base.cursos.length) {
    const cursos = base.cursos.map((c) => ({
      ...c,
      curso_horas_sesion: Number(c.curso_horas_sesion) > 0 ? Number(c.curso_horas_sesion) : 2,
      curso_sesiones_semana: Number(c.curso_sesiones_semana) > 0 ? Number(c.curso_sesiones_semana) : 1,
    }));
    Almacen.reemplazarColeccion('cursos', cursos);
  }
}

export { CONTRASENA_DEMO };


function sembrarCiclo2SiCorresponde() {
  const base = obtenerBase();
  if (base.aulas.length || base.tecnologias.length || base.cursos.length || base.franjas.length) return;
  const ingenieria = base.facultades.find((f) => f.facultad_nombre === 'Ingeniería');
  const sistemas = base.carreras.find((c) => c.carrera_nombre === 'Ingeniería de Sistemas');
  const tecs = [
    { tec_id: siguienteId('tecnologia'), tec_nombre: 'Proyector' },
    { tec_id: siguienteId('tecnologia'), tec_nombre: 'Computadores' },
    { tec_id: siguienteId('tecnologia'), tec_nombre: 'Software especializado' },
    { tec_id: siguienteId('tecnologia'), tec_nombre: 'Mobiliario de laboratorio' },
  ];
  const aulas = [
    { aula_id: siguienteId('aula'), aula_codigo: 'LAB-101', aula_edificio: 'Bloque A', aula_capacidad: 30, aula_tipo: 'Laboratorio', aula_estado: 'Activa' },
    { aula_id: siguienteId('aula'), aula_codigo: 'SAL-202', aula_edificio: 'Bloque B', aula_capacidad: 40, aula_tipo: 'Salón', aula_estado: 'Activa' },
    { aula_id: siguienteId('aula'), aula_codigo: 'AUD-001', aula_edificio: 'Bloque Central', aula_capacidad: 120, aula_tipo: 'Auditorio', aula_estado: 'Activa' },
  ];
  const relaciones = [
    { aula_id: aulas[0].aula_id, tec_id: tecs[0].tec_id },
    { aula_id: aulas[0].aula_id, tec_id: tecs[1].tec_id },
    { aula_id: aulas[0].aula_id, tec_id: tecs[2].tec_id },
    { aula_id: aulas[1].aula_id, tec_id: tecs[0].tec_id },
    { aula_id: aulas[2].aula_id, tec_id: tecs[0].tec_id },
  ];
  const cursos = [
    { curso_id: siguienteId('curso'), curso_nombre: 'Programación Web', carrera_id: sistemas?.carrera_id ?? null, curso_docente: 'Marcela Gómez', curso_num_estudiantes: 28, curso_tec_requerida: 'Computadores', curso_prioridad: 'Alta', curso_horas_sesion: 2, curso_sesiones_semana: 2 },
    { curso_id: siguienteId('curso'), curso_nombre: 'Arquitectura de Computadores', carrera_id: sistemas?.carrera_id ?? null, curso_docente: 'Marcela Gómez', curso_num_estudiantes: 25, curso_tec_requerida: 'Proyector', curso_prioridad: 'Media', curso_horas_sesion: 2, curso_sesiones_semana: 1 },
  ];
  const franjas = [
    { franja_id: siguienteId('franja'), franja_dia: 'Lunes', franja_hora_inicio: '07:00', franja_hora_fin: '09:00' },
    { franja_id: siguienteId('franja'), franja_dia: 'Lunes', franja_hora_inicio: '09:00', franja_hora_fin: '11:00' },
    { franja_id: siguienteId('franja'), franja_dia: 'Martes', franja_hora_inicio: '07:00', franja_hora_fin: '09:00' },
    { franja_id: siguienteId('franja'), franja_dia: 'Miércoles', franja_hora_inicio: '14:00', franja_hora_fin: '16:00' },
  ];
  Almacen.reemplazarColeccion('tecnologias', tecs);
  Almacen.reemplazarColeccion('aulas', aulas);
  Almacen.reemplazarColeccion('aulaTecnologias', relaciones);
  Almacen.reemplazarColeccion('cursos', cursos);
  Almacen.reemplazarColeccion('franjas', franjas);
}


function sembrarCiclo3SiCorresponde() {
  const base = obtenerBase();
  if (base.parametrosPeso.length || base.asignaciones.length) return;
  const pesos = [
    { peso_id: siguienteId('peso'), peso_criterio: 'tecnologia', peso_valor: 30, peso_fecha_mod: new Date().toISOString(), usu_id_mod: 1 },
    { peso_id: siguienteId('peso'), peso_criterio: 'capacidad', peso_valor: 30, peso_fecha_mod: new Date().toISOString(), usu_id_mod: 1 },
    { peso_id: siguienteId('peso'), peso_criterio: 'cercania', peso_valor: 15, peso_fecha_mod: new Date().toISOString(), usu_id_mod: 1 },
    { peso_id: siguienteId('peso'), peso_criterio: 'prioridad_carrera', peso_valor: 15, peso_fecha_mod: new Date().toISOString(), usu_id_mod: 1 },
    { peso_id: siguienteId('peso'), peso_criterio: 'franja_preferida', peso_valor: 10, peso_fecha_mod: new Date().toISOString(), usu_id_mod: 1 },
  ];
  Almacen.reemplazarColeccion('parametrosPeso', pesos);
  Almacen.reemplazarColeccion('historialPesos', []);
  Almacen.reemplazarColeccion('asignaciones', []);
}
