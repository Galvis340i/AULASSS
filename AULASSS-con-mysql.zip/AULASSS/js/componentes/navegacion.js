import { MENU_POR_ROL } from '../data/menu.js';
import { ROLES_INFO, NOMBRE_INSTITUCION, NOMBRE_SISTEMA } from '../data/constantes.js';
import { Usuario } from '../models/Usuario.js';

const SVG_MARCA =
  '<svg viewBox="0 0 40 40" fill="none"><path d="M20 3 35 11v6c0 11-6.4 17.7-15 20-8.6-2.3-15-9-15-20v-6L20 3Z" stroke="#e2c989" stroke-width="1.6"/><path d="M20 11v18M13 15l7-4 7 4M13 25.5l7 4 7-4" stroke="#e2c989" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';

const SVG_SALIR =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3"/><path d="M15 16l4-4-4-4"/><path d="M19 12H9"/></svg>';

export function montarNavegacion(usuario, paginaActiva) {
  const contenedor = document.getElementById('nav-contenedor');
  if (!contenedor) return;

  const menu = MENU_POR_ROL[usuario.usu_rol] || [];
  const iniciales = `${usuario.usu_nombres[0] || ''}${usuario.usu_apellidos[0] || ''}`.toUpperCase();

  contenedor.innerHTML = `
    <div class="nav__marca">
      ${SVG_MARCA}
      <div class="nav__marca-texto">${NOMBRE_INSTITUCION}<small>${NOMBRE_SISTEMA}</small></div>
    </div>
    <button class="nav__hamburguesa" id="boton-menu" type="button" aria-expanded="false" aria-controls="nav-menu">☰ <span>Menú</span></button>
    <div class="nav__contenido" id="nav-menu"><div class="nav__seccion-titulo">Menú</div>
    ${menu
      .map(
        (item) => `
      <a class="nav__enlace ${item.href === paginaActiva ? 'activo' : ''}" href="${item.href}">
        ${item.icono}
        <span>${item.texto}</span>
      </a>`
      )
      .join('')}
    </div><div class="nav__pie">
      <div class="nav__usuario">
        <div class="nav__avatar">${iniciales}</div>
        <div class="nav__usuario-info">
          <strong>${usuario.usu_nombres} ${usuario.usu_apellidos}</strong>
          <span>${ROLES_INFO[usuario.usu_rol]?.etiqueta || usuario.usu_rol}</span>
        </div>
      </div>
      <button class="nav__salir" id="boton-salir" type="button">${SVG_SALIR}<span>Cerrar sesión</span></button>
    </div>
  `;

  const botonMenu = document.getElementById('boton-menu');
  botonMenu.addEventListener('click', () => { const abierto=contenedor.classList.toggle('nav--abierto'); botonMenu.setAttribute('aria-expanded', String(abierto)); });

  document.getElementById('boton-salir').addEventListener('click', () => {
    Usuario.cerrarSesion();
    window.location.replace('index.html');
  });
}
