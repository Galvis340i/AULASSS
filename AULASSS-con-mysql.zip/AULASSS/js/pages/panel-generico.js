import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { Facultad } from '../models/Facultad.js';

export async function montarInicioGenerico({ roles, pagina, mensaje }) {
  await sembrarSiVacio();
  const usuario = protegerPagina(roles);
  if (!usuario) return;

  montarNavegacion(usuario, pagina);
  document.getElementById('saludo').textContent = `Hola, ${usuario.usu_nombres}`;

  const facultad = usuario.facultad_id ? Facultad.porId(usuario.facultad_id) : null;
  document.getElementById('descripcion-facultad').textContent = facultad
    ? `Facultad de ${facultad.facultad_nombre}`
    : '';

  document.getElementById('mensaje-modulo').textContent = mensaje;
}
