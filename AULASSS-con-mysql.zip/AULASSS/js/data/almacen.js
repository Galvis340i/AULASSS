// Capa única de acceso a datos. Toda lectura/escritura del sistema pasa por
// aquí. Antes usaba localStorage; ahora habla con la API PHP (api/api.php),
// que a su vez guarda todo en MySQL. El resto de la aplicación (modelos,
// controladores, páginas) no cambió: siguen llamando a Almacen.listar(),
// Almacen.insertar(), etc. exactamente igual que antes.

const API_URL = 'api/api.php';

let base = null;

async function cargarDesdeServidor() {
  let respuesta;
  try {
    respuesta = await fetch(`${API_URL}?accion=cargarTodo`);
  } catch (error) {
    throw new Error('No se pudo conectar con el servidor. Verifica que Apache y MySQL estén encendidos en XAMPP.');
  }
  if (!respuesta.ok) {
    const cuerpo = await respuesta.json().catch(() => ({}));
    throw new Error(cuerpo.error || 'No se pudo cargar la información desde la base de datos.');
  }
  base = await respuesta.json();
}

// Envía un cambio a la API en segundo plano. No bloquea la interfaz (los
// modelos siguen siendo síncronos), pero deja constancia en consola si algo
// falla, por ejemplo si XAMPP se apagó a mitad de una sesión.
function sincronizar(accion, datos = {}) {
  fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ accion, ...datos }),
  })
    .then(async (respuesta) => {
      if (!respuesta.ok) {
        const cuerpo = await respuesta.json().catch(() => ({}));
        console.error(`[BD] Error en "${accion}":`, cuerpo.error || respuesta.statusText);
      }
    })
    .catch((error) => console.error(`[BD] No se pudo sincronizar "${accion}" con el servidor:`, error));
}

// Top-level await: los módulos ES modernos esperan a que esto termine antes
// de ejecutar cualquier código que importe este archivo, así que todas las
// funciones de abajo pueden asumir que "base" ya está cargada.
await cargarDesdeServidor();

export function inicializarBase() {
  // Con MySQL la base siempre existe (aunque las tablas estén vacías),
  // así que aquí no hay nada que sembrar; se conserva por compatibilidad.
  return base;
}

export function obtenerBase() {
  return base;
}

export function siguienteId(coleccion) {
  base.secuencias[coleccion] = (base.secuencias[coleccion] || 0) + 1;
  return base.secuencias[coleccion];
}

export const Almacen = {
  listar(coleccion) {
    return base[coleccion] ? [...base[coleccion]] : [];
  },
  obtenerPorId(coleccion, id, campoId) {
    return (base[coleccion] || []).find((registro) => registro[campoId] === id) || null;
  },
  insertar(coleccion, registro) {
    base[coleccion].push(registro);
    sincronizar('insertar', { coleccion, registro });
    return registro;
  },
  insertarMasivo(coleccion, registros) {
    base[coleccion].push(...registros);
    registros.forEach((registro) => sincronizar('insertar', { coleccion, registro }));
    return registros;
  },
  actualizar(coleccion, id, campoId, cambios) {
    const indice = base[coleccion].findIndex((registro) => registro[campoId] === id);
    if (indice === -1) return null;
    base[coleccion][indice] = { ...base[coleccion][indice], ...cambios };
    sincronizar('actualizar', { coleccion, id, campoId, cambios });
    return base[coleccion][indice];
  },
  reemplazarColeccion(coleccion, registros) {
    base[coleccion] = registros;
    sincronizar('reemplazarColeccion', { coleccion, registros });
  },
  registrarAcceso(registro) {
    const completo = { ...registro, fecha: new Date().toISOString() };
    base.registrosAcceso.push(completo);
    if (base.registrosAcceso.length > 1000) base.registrosAcceso = base.registrosAcceso.slice(-1000);
    sincronizar('insertar', { coleccion: 'registrosAcceso', registro: completo });
  },
  // Usado por CargaMasivaController tras una inserción masiva, para que el
  // contador en memoria no quede desactualizado durante la misma sesión.
  fijarSecuencia(clave, valor) {
    base.secuencias[clave] = valor;
  },
  restablecerTodo() {
    sincronizar('restablecerTodo');
    for (const coleccion of Object.keys(base)) {
      if (coleccion !== 'secuencias') base[coleccion] = [];
    }
  },
};
