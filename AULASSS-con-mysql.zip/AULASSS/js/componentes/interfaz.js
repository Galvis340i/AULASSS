export function abrirModal(id) {
  const modal = document.getElementById(id);
  if (modal) { modal.removeAttribute('hidden'); modal.classList.add('modal--abierto'); }
}

export function cerrarModal(id) {
  const modal = document.getElementById(id);
  if (modal) { modal.classList.remove('modal--abierto'); modal.setAttribute('hidden', ''); }
}

export function mostrarAviso(idContenedor, tipo, mensaje) {
  const contenedor = document.getElementById(idContenedor);
  if (!contenedor) return;
  contenedor.innerHTML = mensaje ? `<div class="aviso aviso-${tipo}">${mensaje}</div>` : '';
}

export function formatearFecha(marcaTiempo) {
  return new Date(marcaTiempo).toLocaleString('es-CO', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}
