# Modelo de datos — Ciclo 1

El modelo implementado para este ciclo contempla la estructura académica y de identidad definida para Facultad, Carrera y Usuario. La tabla de recuperación se utiliza como soporte del flujo de recuperación de contraseña de un solo uso.

![Diagrama entidad-relación](DER-ciclo1.svg)

## Relaciones

- Una facultad puede ofrecer cero o muchas carreras.
- Una facultad puede tener cero o muchos usuarios asociados.
- Un usuario puede generar cero o muchas solicitudes de recuperación.
- El correo institucional del usuario se maneja como dato único en la lógica de persistencia de la versión simulada.
