import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES } from '../data/constantes.js';
import { Usuario } from '../models/Usuario.js';
import { Facultad } from '../models/Facultad.js';
import { Carrera } from '../models/Carrera.js';

await sembrarSiVacio();
const usuario = protegerPagina([ROLES.ADMIN_SISTEMA]);
if (usuario) {
  montarNavegacion(usuario, 'panel-administrador.html');
  document.getElementById('saludo').textContent = `Hola, ${usuario.usu_nombres}`;

  const usuarios = Usuario.listarTodos();
  const facultades = Facultad.listarTodas();
  const carreras = Carrera.listarTodas();

  const usuariosActivos = usuarios.filter((u) => u.usu_estado === 'Activo').length;
  const facultadesActivas = facultades.filter((f) => f.facultad_estado === 'Activa').length;
  const carrerasActivas = carreras.filter((c) => c.carrera_estado === 'Activa').length;

  document.getElementById('tarjetas-resumen').innerHTML = `
    <div class="tarjeta-metrica">
      <span class="etiqueta">Usuarios activos</span>
      <strong>${usuariosActivos}</strong>
      <span class="detalle">${usuarios.length} en total</span>
    </div>
    <div class="tarjeta-metrica">
      <span class="etiqueta">Facultades</span>
      <strong>${facultadesActivas}</strong>
      <span class="detalle">${facultades.length} en total</span>
    </div>
    <div class="tarjeta-metrica">
      <span class="etiqueta">Carreras</span>
      <strong>${carrerasActivas}</strong>
      <span class="detalle">${carreras.length} en total</span>
    </div>
  `;

  const cuerpoTabla = document.querySelector('#tabla-facultades tbody');
  cuerpoTabla.innerHTML = facultades
    .map((f) => {
      const total = Carrera.porFacultad(f.facultad_id).length;
      const insignia =
        f.facultad_estado === 'Activa'
          ? '<span class="insignia insignia-activo">Activa</span>'
          : '<span class="insignia insignia-inactivo">Inactiva</span>';
      return `<tr><td>${f.facultad_nombre}</td><td>${total}</td><td>${insignia}</td></tr>`;
    })
    .join('');
}
