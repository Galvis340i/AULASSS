-- =====================================================================
-- Sistema de Asignación de Aulas — Esquema MySQL + datos semilla
-- Importar este archivo completo en phpMyAdmin (pestaña "Importar").
-- =====================================================================

CREATE DATABASE IF NOT EXISTS aulas_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE aulas_db;

-- ---------------------------------------------------------------------
-- Tablas
-- ---------------------------------------------------------------------

CREATE TABLE facultad (
  facultad_id INT PRIMARY KEY AUTO_INCREMENT,
  facultad_nombre VARCHAR(120) NOT NULL,
  facultad_estado VARCHAR(20) NOT NULL DEFAULT 'Activa'
) ENGINE=InnoDB;

CREATE TABLE carrera (
  carrera_id INT PRIMARY KEY AUTO_INCREMENT,
  carrera_nombre VARCHAR(120) NOT NULL,
  facultad_id INT NOT NULL,
  carrera_estado VARCHAR(20) NOT NULL DEFAULT 'Activa',
  CONSTRAINT fk_carrera_facultad FOREIGN KEY (facultad_id) REFERENCES facultad(facultad_id),
  CONSTRAINT uq_carrera_facultad_nombre UNIQUE (facultad_id, carrera_nombre)
) ENGINE=InnoDB;

CREATE TABLE usuario (
  usu_id INT PRIMARY KEY AUTO_INCREMENT,
  usu_nombres VARCHAR(100) NOT NULL,
  usu_apellidos VARCHAR(100) NOT NULL,
  usu_correo VARCHAR(180) NOT NULL UNIQUE,
  usu_pwd_hash VARCHAR(255) NOT NULL,
  usu_rol VARCHAR(30) NOT NULL,
  facultad_id INT NULL,
  usu_estado VARCHAR(20) NOT NULL DEFAULT 'Activo',
  CONSTRAINT fk_usuario_facultad FOREIGN KEY (facultad_id) REFERENCES facultad(facultad_id)
) ENGINE=InnoDB;

CREATE TABLE recuperacion_contrasena (
  token VARCHAR(48) PRIMARY KEY,
  usu_id INT NOT NULL,
  creado BIGINT NOT NULL,  -- epoch en milisegundos (Date.now() del navegador)
  expira BIGINT NOT NULL,  -- epoch en milisegundos (Date.now() del navegador)
  usada BOOLEAN NOT NULL DEFAULT FALSE,
  CONSTRAINT fk_recuperacion_usuario FOREIGN KEY (usu_id) REFERENCES usuario(usu_id)
) ENGINE=InnoDB;

CREATE TABLE aula (
  aula_id INT PRIMARY KEY AUTO_INCREMENT,
  aula_codigo VARCHAR(30) NOT NULL UNIQUE,
  aula_edificio VARCHAR(80) NOT NULL,
  aula_capacidad INT NOT NULL,
  aula_tipo VARCHAR(30) NOT NULL,
  aula_estado VARCHAR(15) NOT NULL DEFAULT 'Activa'
) ENGINE=InnoDB;

CREATE TABLE tecnologia (
  tec_id INT PRIMARY KEY AUTO_INCREMENT,
  tec_nombre VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE aula_tecnologia (
  aula_id INT NOT NULL,
  tec_id INT NOT NULL,
  PRIMARY KEY (aula_id, tec_id),
  CONSTRAINT fk_aula_tecnologia_aula FOREIGN KEY (aula_id) REFERENCES aula(aula_id),
  CONSTRAINT fk_aula_tecnologia_tec FOREIGN KEY (tec_id) REFERENCES tecnologia(tec_id)
) ENGINE=InnoDB;

CREATE TABLE curso (
  curso_id INT PRIMARY KEY AUTO_INCREMENT,
  curso_nombre VARCHAR(100) NOT NULL,
  carrera_id INT NOT NULL,
  curso_docente VARCHAR(100) NOT NULL,
  curso_num_estudiantes INT NOT NULL,
  curso_tec_requerida VARCHAR(80) NOT NULL,
  curso_prioridad VARCHAR(20) NOT NULL,
  curso_horas_sesion DECIMAL(4,2) NOT NULL DEFAULT 2,
  curso_sesiones_semana INT NOT NULL DEFAULT 1,
  CONSTRAINT fk_curso_carrera FOREIGN KEY (carrera_id) REFERENCES carrera(carrera_id)
) ENGINE=InnoDB;

CREATE TABLE franja_horaria (
  franja_id INT PRIMARY KEY AUTO_INCREMENT,
  franja_dia VARCHAR(15) NOT NULL,
  franja_hora_inicio TIME NOT NULL,
  franja_hora_fin TIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE parametro_peso (
  peso_id INT PRIMARY KEY AUTO_INCREMENT,
  peso_criterio VARCHAR(40) NOT NULL UNIQUE,
  peso_valor DECIMAL(5,2) NOT NULL,
  peso_fecha_mod DATETIME NOT NULL,
  usu_id_mod INT NULL,
  CONSTRAINT fk_peso_usuario FOREIGN KEY (usu_id_mod) REFERENCES usuario(usu_id),
  CONSTRAINT ck_peso_valor CHECK (peso_valor >= 0 AND peso_valor <= 100)
) ENGINE=InnoDB;

CREATE TABLE historial_peso (
  historial_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  peso_id INT NULL,
  peso_criterio VARCHAR(40) NOT NULL,
  peso_valor DECIMAL(5,2) NOT NULL,
  peso_fecha_mod DATETIME NOT NULL,
  usu_id_mod INT NULL,
  CONSTRAINT fk_hist_peso FOREIGN KEY (peso_id) REFERENCES parametro_peso(peso_id),
  CONSTRAINT fk_hist_usuario FOREIGN KEY (usu_id_mod) REFERENCES usuario(usu_id)
) ENGINE=InnoDB;

CREATE TABLE asignacion (
  asignacion_id INT PRIMARY KEY AUTO_INCREMENT,
  curso_id INT NOT NULL,
  aula_id INT NULL,
  franja_id INT NULL,
  asignacion_hora_inicio TIME NULL,
  asignacion_hora_fin TIME NULL,
  asignacion_puntaje DECIMAL(7,2) NOT NULL DEFAULT 0,
  asignacion_tipo VARCHAR(20) NOT NULL,
  asignacion_estado VARCHAR(20) NOT NULL,
  usu_id_mod INT NULL,
  asignacion_fecha_mod DATETIME NOT NULL,
  CONSTRAINT fk_asig_curso FOREIGN KEY (curso_id) REFERENCES curso(curso_id),
  CONSTRAINT fk_asig_aula FOREIGN KEY (aula_id) REFERENCES aula(aula_id),
  CONSTRAINT fk_asig_franja FOREIGN KEY (franja_id) REFERENCES franja_horaria(franja_id),
  CONSTRAINT fk_asig_usuario FOREIGN KEY (usu_id_mod) REFERENCES usuario(usu_id)
) ENGINE=InnoDB;

CREATE TABLE registro_acceso (
  acceso_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  usu_id INT NOT NULL,
  modulo VARCHAR(80) NOT NULL,
  fecha DATETIME NOT NULL,
  CONSTRAINT fk_acceso_usuario FOREIGN KEY (usu_id) REFERENCES usuario(usu_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Datos semilla (idénticos a los que hoy genera js/data/semilla.js)
-- Contraseña de todas las cuentas de demo: Institucion2026
-- (hash SHA-256, igual al que calcula el navegador en js/utils/cifrado.js)
-- ---------------------------------------------------------------------

INSERT INTO facultad (facultad_id, facultad_nombre, facultad_estado) VALUES
 (1, 'Ciencias Agronómicas', 'Activa'),
 (2, 'Ciencias Humanas', 'Activa'),
 (3, 'Ingeniería', 'Activa');

INSERT INTO carrera (carrera_id, carrera_nombre, facultad_id, carrera_estado) VALUES
 (1, 'Ingeniería Agronómica', 1, 'Activa'),
 (2, 'Ingeniería Ambiental', 1, 'Activa'),
 (3, 'Psicología', 2, 'Activa'),
 (4, 'Administración', 2, 'Activa'),
 (5, 'Contaduría', 2, 'Activa'),
 (6, 'Ingeniería de Sistemas', 3, 'Activa'),
 (7, 'Ingeniería Industrial', 3, 'Activa'),
 (8, 'Ingeniería Electrónica', 3, 'Activa'),
 (9, 'Ingeniería Ambiental', 3, 'Activa');

INSERT INTO usuario (usu_id, usu_nombres, usu_apellidos, usu_correo, usu_pwd_hash, usu_rol, facultad_id, usu_estado) VALUES
 (1, 'Laura', 'Ramírez', 'admin.sistema@uninstitucional.edu.co', 'bce46842eb39ea78f6d9195582841d5f4619576bab36a6cf755f1a795d776b37', 'ADMIN_SISTEMA', NULL, 'Activo'),
 (2, 'Carlos', 'Peña', 'coordinador.ingenieria@uninstitucional.edu.co', 'bce46842eb39ea78f6d9195582841d5f4619576bab36a6cf755f1a795d776b37', 'COORDINADOR', 3, 'Activo'),
 (3, 'Marcela', 'Gómez', 'docente.demo@uninstitucional.edu.co', 'bce46842eb39ea78f6d9195582841d5f4619576bab36a6cf755f1a795d776b37', 'DOCENTE', 3, 'Activo'),
 (4, 'Andrés', 'Torres', 'plantafisica@uninstitucional.edu.co', 'bce46842eb39ea78f6d9195582841d5f4619576bab36a6cf755f1a795d776b37', 'ADMIN_PLANTA', NULL, 'Activo'),
 (5, 'Diana', 'Salas', 'decano.ingenieria@uninstitucional.edu.co', 'bce46842eb39ea78f6d9195582841d5f4619576bab36a6cf755f1a795d776b37', 'DECANO', 3, 'Activo');

INSERT INTO tecnologia (tec_id, tec_nombre) VALUES
 (1, 'Proyector'),
 (2, 'Computadores'),
 (3, 'Software especializado'),
 (4, 'Mobiliario de laboratorio');

INSERT INTO aula (aula_id, aula_codigo, aula_edificio, aula_capacidad, aula_tipo, aula_estado) VALUES
 (1, 'LAB-101', 'Bloque A', 30, 'Laboratorio', 'Activa'),
 (2, 'SAL-202', 'Bloque B', 40, 'Salón', 'Activa'),
 (3, 'AUD-001', 'Bloque Central', 120, 'Auditorio', 'Activa');

INSERT INTO aula_tecnologia (aula_id, tec_id) VALUES
 (1, 1), (1, 2), (1, 3),
 (2, 1),
 (3, 1);

INSERT INTO curso (curso_id, curso_nombre, carrera_id, curso_docente, curso_num_estudiantes, curso_tec_requerida, curso_prioridad, curso_horas_sesion, curso_sesiones_semana) VALUES
 (1, 'Programación Web', 6, 'Marcela Gómez', 28, 'Computadores', 'Alta', 2, 2),
 (2, 'Arquitectura de Computadores', 6, 'Marcela Gómez', 25, 'Proyector', 'Media', 2, 1);

INSERT INTO franja_horaria (franja_id, franja_dia, franja_hora_inicio, franja_hora_fin) VALUES
 (1, 'Lunes', '07:00:00', '09:00:00'),
 (2, 'Lunes', '09:00:00', '11:00:00'),
 (3, 'Martes', '07:00:00', '09:00:00'),
 (4, 'Miércoles', '14:00:00', '16:00:00');

INSERT INTO parametro_peso (peso_id, peso_criterio, peso_valor, peso_fecha_mod, usu_id_mod) VALUES
 (1, 'tecnologia', 30, NOW(), 1),
 (2, 'capacidad', 30, NOW(), 1),
 (3, 'cercania', 15, NOW(), 1),
 (4, 'prioridad_carrera', 15, NOW(), 1),
 (5, 'franja_preferida', 10, NOW(), 1);
