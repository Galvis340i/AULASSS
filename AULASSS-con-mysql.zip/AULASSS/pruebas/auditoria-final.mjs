import assert from 'node:assert/strict';

globalThis.localStorage={_m:new Map(),getItem(k){return this._m.get(k)??null},setItem(k,v){this._m.set(k,String(v))},removeItem(k){this._m.delete(k)}};
globalThis.performance={now:()=>Date.now()};

const {Almacen}=await import('../js/data/almacen.js');
const {AsignacionController}=await import('../js/controllers/AsignacionController.js');
const {Asignacion}=await import('../js/models/Asignacion.js');
const {Aula}=await import('../js/models/Aula.js');
const {Curso}=await import('../js/models/Curso.js');
const {FranjaHoraria}=await import('../js/models/FranjaHoraria.js');
const {Tecnologia}=await import('../js/models/Tecnologia.js');
const {AulaTecnologia}=await import('../js/models/AulaTecnologia.js');
const {ParametroPeso}=await import('../js/models/ParametroPeso.js');

function base(){
  Almacen.reemplazarColeccion('facultades',[{facultad_id:1,facultad_nombre:'Ingeniería',facultad_estado:'Activa'}]);
  Almacen.reemplazarColeccion('carreras',[{carrera_id:1,carrera_nombre:'Ingeniería de Sistemas',facultad_id:1,carrera_estado:'Activa'}]);
  Almacen.reemplazarColeccion('usuarios',[{usu_id:1,usu_nombres:'Coord',usu_apellidos:'Demo',usu_correo:'coord@uninstitucional.edu.co',usu_rol:'Coordinador',facultad_id:1,usu_estado:'Activo'}]);
  Almacen.reemplazarColeccion('aulas',[{aula_id:1,aula_codigo:'A1',aula_edificio:'Bloque A',aula_capacidad:40,aula_tipo:'Salón',aula_estado:'Activa'}]);
  Almacen.reemplazarColeccion('tecnologias',[{tec_id:1,tec_nombre:'Proyector'}]);
  Almacen.reemplazarColeccion('aulaTecnologias',[{aula_id:1,tec_id:1}]);
  Almacen.reemplazarColeccion('franjas',[
    {franja_id:1,franja_dia:'Lunes',franja_hora_inicio:'07:00',franja_hora_fin:'09:00'},
    {franja_id:2,franja_dia:'Lunes',franja_hora_inicio:'08:00',franja_hora_fin:'10:00'},
  ]);
  Almacen.reemplazarColeccion('cursos',[]); Almacen.reemplazarColeccion('asignaciones',[]);
  Almacen.reemplazarColeccion('parametrosPeso',[
    {peso_id:1,peso_criterio:'tecnologia',peso_valor:30},{peso_id:2,peso_criterio:'capacidad',peso_valor:30},{peso_id:3,peso_criterio:'cercania',peso_valor:15},{peso_id:4,peso_criterio:'prioridad_carrera',peso_valor:15},{peso_id:5,peso_criterio:'franja_preferida',peso_valor:10}
  ]);
  Almacen.reemplazarColeccion('registrosAcceso',[]); Almacen.reemplazarColeccion('historialPesos',[]);
}

base();
const tests=[]; const t=async(id,fn)=>{await fn();tests.push(id)};

await t('AUD-01',()=>{
  const c1=Curso.crear({curso_nombre:'Curso A',carrera_id:1,curso_docente:'Docente A',curso_num_estudiantes:20,curso_tec_requerida:'Proyector',curso_prioridad:'Media'});
  const c2=Curso.crear({curso_nombre:'Curso B',carrera_id:1,curso_docente:'Docente B',curso_num_estudiantes:20,curso_tec_requerida:'Proyector',curso_prioridad:'Media'});
  assert.equal(c1.ok,true);assert.equal(c2.ok,true);
  const a=AsignacionController.ejecutarAsignacion(1); assert.equal(a.ok,true); assert.equal(a.asignados,1); assert.equal(a.conflictos,1);
});

await t('AUD-02',()=>{
  // The only room is already occupied 07:00-09:00; an 08:00-10:00 assignment must be rejected.
  const r=AsignacionController.validarAjuste({asignacion_id:1,curso_id:2,aula_id:1,franja_id:2});
  assert.equal(r.ok,false); assert.match(r.error,/ocupada/);
});

await t('AUD-03',()=>{
  // A different docente cannot overlap an existing room booking; 10:00-12:00 is valid because it touches, but does not overlap, 08:00-10:00.
  Almacen.reemplazarColeccion('franjas',[...FranjaHoraria.listarTodas(),{franja_id:3,franja_dia:'Lunes',franja_hora_inicio:'10:00',franja_hora_fin:'12:00'}]);
  const r=AsignacionController.validarAjuste({asignacion_id:2,curso_id:2,aula_id:1,franja_id:3});
  assert.equal(r.ok,true);
});

await t('AUD-04',()=>{
  Almacen.reemplazarColeccion('franjas',FranjaHoraria.listarTodas().filter(f=>f.franja_id!==3));
  const before=Asignacion.listarTodas().filter(a=>a.curso_id===2&&a.asignacion_estado==='conflicto').length;
  const r=AsignacionController.ejecutarAsignacion(1); assert.equal(r.ok,true);
  const after=Asignacion.listarTodas().filter(a=>a.curso_id===2&&a.asignacion_estado==='conflicto').length;
  assert.equal(after,1); assert.equal(before,1);
});

await t('AUD-05',()=>{
  Almacen.reemplazarColeccion('aulaTecnologias',[]);
  const r=Aula.eliminar(1); assert.equal(r.ok,false); assert.match(r.error,/asignaciones/);
});
await t('AUD-06',()=>{
  const r=Curso.eliminar(1); assert.equal(r.ok,false); assert.match(r.error,/asignaciones/);
});
await t('AUD-07',()=>{
  const r=FranjaHoraria.eliminar(1); assert.equal(r.ok,false); assert.match(r.error,/asignaciones/);
});
await t('AUD-08',()=>{
  assert.equal(ParametroPeso.sumaPesos(),100);
});

console.log(`${tests.length}/8 comprobaciones críticas de auditoría aprobadas.`);
