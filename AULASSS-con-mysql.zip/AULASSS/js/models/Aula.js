import { Almacen, siguienteId } from '../data/almacen.js';
const COLECCION = 'aulas';
export class Aula {
  constructor({ aula_id, aula_codigo, aula_edificio, aula_capacidad, aula_tipo, aula_estado }) {
    this.aula_id = aula_id; this.aula_codigo = aula_codigo; this.aula_edificio = aula_edificio;
    this.aula_capacidad = aula_capacidad; this.aula_tipo = aula_tipo; this.aula_estado = aula_estado;
  }
  static listarTodas() { return Almacen.listar(COLECCION); }
  static porId(id) { return Almacen.obtenerPorId(COLECCION, id, 'aula_id'); }
  static codigoYaExiste(codigo, excluirId=null) { const x=codigo.trim().toLowerCase(); return this.listarTodas().some(a=>a.aula_codigo.toLowerCase()===x && a.aula_id!==excluirId); }
  static crear(datos) { if(!Number.isInteger(datos.aula_capacidad)||datos.aula_capacidad<1) return {ok:false,error:'La capacidad debe ser un entero mayor que 0.'}; if(!datos.aula_codigo?.trim()) return {ok:false,error:'El código del aula es obligatorio.'}; if(!datos.aula_edificio?.trim()) return {ok:false,error:'El edificio o bloque es obligatorio.'}; if(!datos.aula_tipo) return {ok:false,error:'El tipo de aula es obligatorio.'}; if(this.codigoYaExiste(datos.aula_codigo)) return {ok:false,error:'Ya existe un aula con ese código.'}; const r=Almacen.insertar(COLECCION,{aula_id:siguienteId('aula'),...datos,aula_codigo:datos.aula_codigo.trim().toUpperCase(),aula_edificio:datos.aula_edificio.trim(),aula_estado:'Activa'}); return {ok:true,aula:r}; }
  static actualizar(id,datos) { if(!Number.isInteger(datos.aula_capacidad)||datos.aula_capacidad<1) return {ok:false,error:'La capacidad debe ser un entero mayor que 0.'}; if(!datos.aula_codigo?.trim()||!datos.aula_edificio?.trim()||!datos.aula_tipo) return {ok:false,error:'Completa todos los datos del aula.'}; if(this.codigoYaExiste(datos.aula_codigo,id)) return {ok:false,error:'Ya existe un aula con ese código.'}; const r=Almacen.actualizar(COLECCION,id,'aula_id',{...datos,aula_codigo:datos.aula_codigo.trim().toUpperCase(),aula_edificio:datos.aula_edificio.trim()}); return {ok:true,aula:r}; }
  static cambiarEstado(id,estado) { return Almacen.actualizar(COLECCION,id,'aula_id',{aula_estado:estado}); }
  static eliminar(id) { const base=Almacen.listar(COLECCION); if(!base.some(a=>a.aula_id===id)) return {ok:false,error:'El aula no existe.'}; if(Almacen.listar('aulaTecnologias').some(r=>r.aula_id===id)) return {ok:false,error:'No se puede eliminar un aula con tecnologías asociadas. Inactívala en su lugar.'}; if(Almacen.listar('asignaciones').some(r=>r.aula_id===id))return {ok:false,error:'No se puede eliminar un aula con asignaciones registradas. Inactívala en su lugar.'}; Almacen.reemplazarColeccion(COLECCION,base.filter(a=>a.aula_id!==id)); return {ok:true}; }
}
