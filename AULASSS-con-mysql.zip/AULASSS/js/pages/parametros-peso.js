import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES } from '../data/constantes.js';
import { ParametroPeso } from '../models/ParametroPeso.js';
import { Usuario } from '../models/Usuario.js';
import { Almacen } from '../data/almacen.js';
import { formatearFecha, mostrarAviso } from '../componentes/interfaz.js';

await sembrarSiVacio();
const usuario = protegerPagina([ROLES.ADMIN_SISTEMA]);
if (!usuario) throw new Error('Acceso no autorizado');
montarNavegacion(usuario, 'parametros-peso.html');
ParametroPeso.asegurarIniciales(usuario.usu_id);
const form = document.getElementById('form-pesos');
const suma = document.getElementById('suma-pesos');
const ids = ParametroPeso.criterios();

function pintar() {
  const datos = ParametroPeso.listarTodas();
  ids.forEach(c => { document.getElementById(c).value = datos.find(p => p.peso_criterio === c)?.peso_valor ?? 0; });
  suma.textContent = `${ParametroPeso.sumaPesos()}%`;
  const hist = [...Almacen.listar('historialPesos')].reverse();
  const usuarios = Almacen.listar('usuarios');
  document.getElementById('historial').innerHTML = hist.length ? hist.slice(0, 40).map(h => `<tr><td>${formatearFecha(h.historial_fecha || h.peso_fecha_mod)}</td><td>${h.peso_criterio}</td><td>${h.peso_valor}%</td><td>${usuarios.find(u=>u.usu_id===h.usu_id_mod)?.usu_nombres || 'Administrador'}</td></tr>`).join('') : '<tr><td colspan="4" class="estado-vacio-tabla">Aún no hay cambios registrados.</td></tr>';
}
form.addEventListener('input', () => { const valores = Object.fromEntries(ids.map(c => [c, Number(document.getElementById(c).value || 0)])); suma.textContent = `${Object.values(valores).reduce((a,b)=>a+b,0)}%`; });
form.addEventListener('submit', e => { e.preventDefault(); const valores = Object.fromEntries(ids.map(c => [c, Number(document.getElementById(c).value || 0)])); const r=ParametroPeso.guardarTodos(valores, usuario.usu_id); if(!r.ok){mostrarAviso('zona-aviso','error',r.error);return;} mostrarAviso('zona-aviso','ok','Los parámetros fueron guardados correctamente.'); pintar(); });
pintar();
