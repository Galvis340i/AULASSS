# Registro de revisión — Ciclo 3

## Alcance
Se revisan RF9 Parámetros de Pesos, RF10 Motor de Asignación y RF11 Ajuste Manual, junto con los riesgos R3.1–R3.4.

## Evidencias ejecutables
- `ejecutar-pruebas-ciclo3.mjs`: pruebas automatizadas del modelo y controladores.
- `MATRIZ_PRUEBAS_CICLO3.md`: relación entre comprobaciones y resultados esperados.
- `resultado-ultima-ejecucion.txt`: salida de la última ejecución.

## Observaciones de modelo
El UML del Ciclo 3 define `Asignacion`, `ParametroPeso`, `Curso`, `Aula` y `FranjaHoraria`, y contempla `asignacion_tipo` automática/manual y `asignacion_estado` confirmada/conflicto. El ERS no incorpora en `Curso` un campo para una franja preferida ni en `Aula` una relación de cercanía a facultad; por ello esos dos componentes se mantienen neutrales en el cálculo actual en vez de inventar atributos que no pertenecen al modelo aprobado.

## Riesgos revisados
- R3.1: prueba piloto y prueba de volumen para verificar que el algoritmo finaliza.
- R3.2: regla de desempate explícita: cercanía y luego `aula_id`.
- R3.3: bloqueo de ejecución por facultad durante el proceso; en la versión con localStorage es un mecanismo de exclusión entre sesiones del navegador, no una transacción MySQL.
- R3.4: el CRUD de parámetros no permite guardar una suma distinta de 100%.
