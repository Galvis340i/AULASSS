import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES, ROLES_INFO, ROLES_CREABLES_POR_ADMIN_SISTEMA } from '../data/constantes.js';
import { Usuario } from '../models/Usuario.js';
import { Facultad } from '../models/Facultad.js';
import { abrirModal, cerrarModal, mostrarAviso } from '../componentes/interfaz.js';
import {
  esCorreoInstitucionalValido,
  esContrasenaValida,
  campoNoVacio,
  mostrarErrorCampo,
  limpiarErroresFormulario,
} from '../utils/validadores.js';

await sembrarSiVacio();
const admin = protegerPagina([ROLES.ADMIN_SISTEMA]);
if (!admin) throw new Error('Sesión no válida');

montarNavegacion(admin, 'administrador-usuarios.html');

const ROLES_QUE_REQUIEREN_FACULTAD = [ROLES.COORDINADOR, ROLES.DECANO, ROLES.DOCENTE];

let filtroTexto = '';
let usuarioEnEdicion = null;

function facultades() {
  return Facultad.listarTodas();
}

function nombreFacultad(id) {
  const f = facultades().find((x) => x.facultad_id === id);
  return f ? f.facultad_nombre : '—';
}

function pintarTabla() {
  const cuerpo = document.getElementById('cuerpo-tabla');
  const vacio = document.getElementById('tabla-vacia');
  const texto = filtroTexto.trim().toLowerCase();

  const usuarios = Usuario.listarTodos()
    .filter((u) => {
      if (!texto) return true;
      const nombreCompleto = `${u.usu_nombres} ${u.usu_apellidos}`.toLowerCase();
      return nombreCompleto.includes(texto) || u.usu_correo.toLowerCase().includes(texto);
    })
    .sort((a, b) => a.usu_nombres.localeCompare(b.usu_nombres));

  if (usuarios.length === 0) {
    cuerpo.innerHTML = '';
    vacio.classList.remove('oculto');
    return;
  }
  vacio.classList.add('oculto');

  cuerpo.innerHTML = usuarios
    .map((u) => {
      const insigniaEstado =
        u.usu_estado === 'Activo'
          ? '<span class="insignia insignia-activo">Activo</span>'
          : '<span class="insignia insignia-inactivo">Inhabilitado</span>';
      const accionEstado = u.usu_estado === 'Activo' ? 'inhabilitar' : 'reactivar';
      const iconoEstado =
        u.usu_estado === 'Activo'
          ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M8.5 8.5l7 7"/></svg>'
          : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="m9 12 2 2 4-4"/></svg>';

      return `
        <tr>
          <td class="celda-principal">
            <strong>${u.usu_nombres} ${u.usu_apellidos}</strong>
            <span>${u.usu_correo}</span>
          </td>
          <td><span class="insignia insignia-rol">${ROLES_INFO[u.usu_rol]?.etiqueta || u.usu_rol}</span></td>
          <td>${u.facultad_id ? nombreFacultad(u.facultad_id) : '—'}</td>
          <td>${insigniaEstado}</td>
          <td>
            <div class="acciones-fila">
              <button class="icono-btn" title="Editar" data-accion="editar" data-id="${u.usu_id}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/></svg>
              </button>
              <button class="icono-btn" title="${accionEstado === 'inhabilitar' ? 'Inhabilitar' : 'Reactivar'}" data-accion="${accionEstado}" data-id="${u.usu_id}">
                ${iconoEstado}
              </button>
            </div>
          </td>
        </tr>`;
    })
    .join('');
}

function poblarSelectRoles(modo) {
  const select = document.getElementById('usuario-rol');
  const roles = modo === 'crear' ? ROLES_CREABLES_POR_ADMIN_SISTEMA : Object.values(ROLES);
  select.innerHTML = roles.map((r) => `<option value="${r}">${ROLES_INFO[r].etiqueta}</option>`).join('');
}

function poblarSelectFacultades() {
  const select = document.getElementById('usuario-facultad');
  select.innerHTML =
    '<option value="">Selecciona una facultad</option>' +
    facultades()
      .filter((f) => f.facultad_estado === 'Activa')
      .map((f) => `<option value="${f.facultad_id}">${f.facultad_nombre}</option>`)
      .join('');
}

function actualizarVisibilidadFacultad() {
  const rol = document.getElementById('usuario-rol').value;
  const campo = document.getElementById('campo-usuario-facultad');
  campo.style.display = ROLES_QUE_REQUIEREN_FACULTAD.includes(rol) ? 'block' : 'none';
}

function abrirModalCrear() {
  usuarioEnEdicion = null;
  document.getElementById('titulo-modal-usuario').textContent = 'Nuevo usuario';
  document.getElementById('form-usuario').reset();
  document.getElementById('usuario-id').value = '';
  document.getElementById('campo-usuario-contrasena').style.display = 'block';
  document.getElementById('usuario-correo').disabled = false;
  poblarSelectRoles('crear');
  poblarSelectFacultades();
  actualizarVisibilidadFacultad();
  mostrarAviso('zona-aviso-usuario', null, '');
  limpiarErroresFormulario(['usuario-nombres', 'usuario-apellidos', 'usuario-correo', 'usuario-contrasena', 'usuario-facultad']);
  abrirModal('modal-usuario');
}

function abrirModalEditar(id) {
  const u = Usuario.porId(id);
  if (!u) return;
  usuarioEnEdicion = u;
  document.getElementById('titulo-modal-usuario').textContent = 'Editar usuario';
  document.getElementById('usuario-id').value = u.usu_id;
  document.getElementById('usuario-nombres').value = u.usu_nombres;
  document.getElementById('usuario-apellidos').value = u.usu_apellidos;
  document.getElementById('usuario-correo').value = u.usu_correo;
  document.getElementById('usuario-correo').disabled = true; // el correo no se reasigna
  document.getElementById('campo-usuario-contrasena').style.display = 'none';
  poblarSelectRoles('editar');
  document.getElementById('usuario-rol').value = u.usu_rol;
  poblarSelectFacultades();
  document.getElementById('usuario-facultad').value = u.facultad_id || '';
  actualizarVisibilidadFacultad();
  mostrarAviso('zona-aviso-usuario', null, '');
  limpiarErroresFormulario(['usuario-nombres', 'usuario-apellidos', 'usuario-correo', 'usuario-contrasena', 'usuario-facultad']);
  abrirModal('modal-usuario');
}

document.getElementById('boton-nuevo').addEventListener('click', abrirModalCrear);
document.getElementById('cerrar-modal-usuario').addEventListener('click', () => cerrarModal('modal-usuario'));
document.getElementById('cancelar-modal-usuario').addEventListener('click', () => cerrarModal('modal-usuario'));
document.getElementById('usuario-rol').addEventListener('change', actualizarVisibilidadFacultad);

document.getElementById('form-usuario').addEventListener('submit', async (evento) => {
  evento.preventDefault();
  mostrarAviso('zona-aviso-usuario', null, '');
  limpiarErroresFormulario(['usuario-nombres', 'usuario-apellidos', 'usuario-correo', 'usuario-contrasena', 'usuario-facultad']);

  const nombres = document.getElementById('usuario-nombres').value.trim();
  const apellidos = document.getElementById('usuario-apellidos').value.trim();
  const correo = document.getElementById('usuario-correo').value.trim();
  const contrasena = document.getElementById('usuario-contrasena').value;
  const rol = document.getElementById('usuario-rol').value;
  const facultadId = document.getElementById('usuario-facultad').value;
  const requiereFacultad = ROLES_QUE_REQUIEREN_FACULTAD.includes(rol);

  let valido = true;
  if (!campoNoVacio(nombres)) { mostrarErrorCampo('usuario-nombres', 'Requerido.'); valido = false; }
  if (!campoNoVacio(apellidos)) { mostrarErrorCampo('usuario-apellidos', 'Requerido.'); valido = false; }
  if (!esCorreoInstitucionalValido(correo)) {
    mostrarErrorCampo('usuario-correo', 'Usa un correo institucional válido.');
    valido = false;
  }
  if (requiereFacultad && !facultadId) {
    mostrarErrorCampo('usuario-facultad', 'Selecciona la facultad.');
    valido = false;
  }
  if (!usuarioEnEdicion && !esContrasenaValida(contrasena)) {
    mostrarErrorCampo('usuario-contrasena', 'Mínimo 8 caracteres, con letras y números.');
    valido = false;
  }
  if (!valido) return;

  const botonGuardar = document.getElementById('guardar-usuario');
  botonGuardar.disabled = true;

  if (usuarioEnEdicion) {
    Usuario.actualizarDatos(usuarioEnEdicion.usu_id, {
      usu_nombres: nombres,
      usu_apellidos: apellidos,
      usu_rol: rol,
      facultad_id: requiereFacultad ? Number(facultadId) : null,
    });
    cerrarModal('modal-usuario');
    pintarTabla();
  } else {
    const resultado = await Usuario.crear({
      usu_nombres: nombres,
      usu_apellidos: apellidos,
      usu_correo: correo,
      contrasenaInicial: contrasena,
      usu_rol: rol,
      facultad_id: requiereFacultad ? Number(facultadId) : null,
    });
    if (!resultado.ok) {
      mostrarAviso('zona-aviso-usuario', 'error', resultado.error);
      botonGuardar.disabled = false;
      return;
    }
    cerrarModal('modal-usuario');
    pintarTabla();
  }
  botonGuardar.disabled = false;
});

// ---- Cambio de estado (inhabilitar / reactivar) ----
let usuarioObjetivoEstado = null;
let nuevoEstadoObjetivo = null;

document.getElementById('cuerpo-tabla').addEventListener('click', (evento) => {
  const boton = evento.target.closest('button[data-accion]');
  if (!boton) return;
  const id = Number(boton.dataset.id);
  const accion = boton.dataset.accion;

  if (accion === 'editar') {
    abrirModalEditar(id);
    return;
  }

  const u = Usuario.porId(id);
  if (!u) return;
  usuarioObjetivoEstado = u;
  nuevoEstadoObjetivo = accion === 'inhabilitar' ? 'Inhabilitado' : 'Activo';

  document.getElementById('titulo-modal-estado').textContent =
    accion === 'inhabilitar' ? 'Inhabilitar usuario' : 'Reactivar usuario';
  document.getElementById('texto-modal-estado').innerHTML =
    accion === 'inhabilitar'
      ? `¿Inhabilitar a <strong>${u.usu_nombres} ${u.usu_apellidos}</strong>? No podrá iniciar sesión, pero su historial se conserva.`
      : `¿Reactivar a <strong>${u.usu_nombres} ${u.usu_apellidos}</strong>? Podrá volver a iniciar sesión de inmediato.`;
  abrirModal('modal-estado');
});

document.getElementById('cerrar-modal-estado').addEventListener('click', () => cerrarModal('modal-estado'));
document.getElementById('cancelar-modal-estado').addEventListener('click', () => cerrarModal('modal-estado'));
document.getElementById('confirmar-modal-estado').addEventListener('click', () => {
  if (!usuarioObjetivoEstado) return;
  Usuario.cambiarEstado(usuarioObjetivoEstado.usu_id, nuevoEstadoObjetivo);
  cerrarModal('modal-estado');
  pintarTabla();
});

document.getElementById('buscador').addEventListener('input', (evento) => {
  filtroTexto = evento.target.value;
  pintarTabla();
});

pintarTabla();
