# Ciclo 4 — Integración, carga masiva y reportes

Este ciclo incorpora la carga masiva de aulas/cursos y el módulo de reportes, integrando los ciclos anteriores.

## Carga masiva
- Acepta `.csv` y `.xlsx`.
- Límite de archivo: 5 MB.
- Revisión previa de todas las filas antes de guardar.
- Errores identificados por fila.
- Confirmación explícita antes de incorporar datos.
- Para cursos se valida carrera activa, pertenencia a la facultad del coordinador, tecnología existente y prioridad válida.
- Para aulas se valida código único, capacidad, tipo y estado.
- La carga masiva utiliza una escritura única para reducir el tiempo de procesamiento.

## Reportes
- Consulta de asignaciones autorizadas por rol.
- Filtros por facultad, carrera y docente.
- Rango de fechas con validación.
- Indicadores de cursos consultados, asignados, automáticos, manuales y sin asignación.
- Ocupación por aula.
- Cursos en conflicto.
- Exportación a Excel compatible (`.xls`).
- Generación de PDF mediante la impresión del reporte desde el navegador.
- Aviso de confidencialidad incluido en los reportes.

## RNF y límites de esta versión
La sesión mantiene la arquitectura de frontend con datos simulados en `localStorage`. Por ello:
- La aplicación de bcrypt/Argon2, respaldos diarios del servidor y restauración ante fallas de infraestructura se concretan al conectar la API y MySQL.
- La interfaz sí aplica control de acceso por rol, límites de carga, validaciones, protección de información y parámetros dinámicos.
- El registro de acceso a reportes se conserva localmente para la demostración.
