const CLAVE_SESION = 'aulas_sesion_v1';

export function guardarSesion({ usu_id, token }) {
  localStorage.setItem(CLAVE_SESION, JSON.stringify({ usu_id, token }));
}

export function obtenerSesion() {
  const crudo = localStorage.getItem(CLAVE_SESION);
  if (!crudo) return null;
  try {
    return JSON.parse(crudo);
  } catch {
    return null;
  }
}

export function limpiarSesion() {
  localStorage.removeItem(CLAVE_SESION);
}
