<?php
// =====================================================================
// Configuración de conexión a MySQL (XAMPP).
// Si tu XAMPP usa otro usuario/clave de MySQL, ajústalo aquí.
// =====================================================================

$DB_HOST = 'localhost';
$DB_NAME = 'aulas_db';
$DB_USER = 'root';
$DB_PASS = ''; // XAMPP por defecto no trae contraseña para 'root'

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'No se pudo conectar a la base de datos: ' . $e->getMessage()]);
    exit;
}
