<?php
// =====================================================================
// API genérica de persistencia — sustituye a localStorage.
// Un solo endpoint que entiende las mismas operaciones que el objeto
// "Almacen" del frontend (listar, insertar, actualizar, reemplazarColeccion...),
// para no tener que reescribir toda la lógica de negocio que ya vive en
// los modelos JS. Cada "colección" del frontend se mapea a su tabla real.
// =====================================================================

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

require_once __DIR__ . '/config.php';

// Colección (nombre usado en el frontend) => [tabla real, columna id]
// 'idCompuesto' => true indica que la tabla no tiene una sola columna id (ej. relación N:M).
const MAPA_COLECCIONES = [
    'usuarios'         => ['tabla' => 'usuario',                'id' => 'usu_id'],
    'facultades'       => ['tabla' => 'facultad',               'id' => 'facultad_id'],
    'carreras'         => ['tabla' => 'carrera',                'id' => 'carrera_id'],
    'recuperaciones'   => ['tabla' => 'recuperacion_contrasena','id' => 'token'],
    'aulas'            => ['tabla' => 'aula',                   'id' => 'aula_id'],
    'tecnologias'      => ['tabla' => 'tecnologia',             'id' => 'tec_id'],
    'aulaTecnologias'  => ['tabla' => 'aula_tecnologia',        'id' => null],
    'cursos'           => ['tabla' => 'curso',                  'id' => 'curso_id'],
    'franjas'          => ['tabla' => 'franja_horaria',         'id' => 'franja_id'],
    'parametrosPeso'   => ['tabla' => 'parametro_peso',         'id' => 'peso_id'],
    'historialPesos'   => ['tabla' => 'historial_peso',         'id' => 'historial_id'],
    'asignaciones'     => ['tabla' => 'asignacion',             'id' => 'asignacion_id'],
    'registrosAcceso'  => ['tabla' => 'registro_acceso',        'id' => 'acceso_id'],
];

// Secuencias que el frontend pide con siguienteId(clave); se calculan a partir del MAX real.
const MAPA_SECUENCIAS = [
    'usuario'        => ['tabla' => 'usuario',        'id' => 'usu_id'],
    'facultad'       => ['tabla' => 'facultad',       'id' => 'facultad_id'],
    'carrera'        => ['tabla' => 'carrera',        'id' => 'carrera_id'],
    'aula'           => ['tabla' => 'aula',           'id' => 'aula_id'],
    'tecnologia'     => ['tabla' => 'tecnologia',     'id' => 'tec_id'],
    'aulaTecnologia' => ['tabla' => 'aula_tecnologia','id' => null],
    'curso'          => ['tabla' => 'curso',          'id' => 'curso_id'],
    'franja'         => ['tabla' => 'franja_horaria', 'id' => 'franja_id'],
    'peso'           => ['tabla' => 'parametro_peso', 'id' => 'peso_id'],
    'asignacion'     => ['tabla' => 'asignacion',     'id' => 'asignacion_id'],
];

function responder($datos, $codigo = 200) {
    http_response_code($codigo);
    echo json_encode($datos);
    exit;
}

// El frontend envía fechas en formato ISO (new Date().toISOString()) y
// booleanos nativos de JS; MySQL necesita 'YYYY-MM-DD HH:MM:SS' y 0/1.
function normalizarValor($valor) {
    if (is_bool($valor)) return $valor ? 1 : 0;
    if (is_string($valor) && preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/', $valor)) {
        $valor = str_replace('T', ' ', $valor);
        $valor = preg_replace('/\.\d+Z?$|Z$/', '', $valor);
    }
    return $valor;
}

function normalizarRegistro($registro) {
    $normalizado = [];
    foreach ($registro as $columna => $valor) {
        $normalizado[$columna] = normalizarValor($valor);
    }
    return $normalizado;
}

// Solo se permiten nombres de columna con letras, números y guion bajo.
// Evita que alguien inyecte SQL a través de las claves del JSON recibido.
function validarColumnas($registro) {
    foreach (array_keys($registro) as $columna) {
        if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $columna)) {
            responder(['ok' => false, 'error' => "Nombre de columna no válido: {$columna}"], 400);
        }
    }
}

function tablaValida($coleccion) {
    if (!isset(MAPA_COLECCIONES[$coleccion])) {
        responder(['ok' => false, 'error' => "Colección no reconocida: {$coleccion}"], 400);
    }
    return MAPA_COLECCIONES[$coleccion];
}

function calcularSecuencias($pdo) {
    $secuencias = [];
    foreach (MAPA_SECUENCIAS as $clave => $info) {
        if ($info['id'] === null) { $secuencias[$clave] = 0; continue; }
        $stmt = $pdo->query("SELECT MAX({$info['id']}) AS m FROM {$info['tabla']}");
        $max = $stmt->fetch()['m'];
        $secuencias[$clave] = $max ? (int)$max : 0;
    }
    return $secuencias;
}

// ---------------------------------------------------------------------
// GET ?accion=cargarTodo -> toda la "base" en un solo JSON,
// con la misma forma que usaba la versión de localStorage.
// ---------------------------------------------------------------------
function cargarTodo($pdo) {
    $base = [];
    foreach (MAPA_COLECCIONES as $coleccion => $info) {
        $base[$coleccion] = $pdo->query("SELECT * FROM {$info['tabla']}")->fetchAll();
    }
    $base['secuencias'] = calcularSecuencias($pdo);
    responder($base);
}

// ---------------------------------------------------------------------
// Operaciones de escritura
// ---------------------------------------------------------------------
function insertar($pdo, $coleccion, $registro) {
    $info = tablaValida($coleccion);
    if (empty($registro)) responder(['ok' => false, 'error' => 'Registro vacío.'], 400);
    $registro = normalizarRegistro($registro);
    validarColumnas($registro);
    $columnas = array_keys($registro);
    $marcadores = array_map(fn($c) => ':' . $c, $columnas);
    $sql = "INSERT INTO {$info['tabla']} (" . implode(',', $columnas) . ") VALUES (" . implode(',', $marcadores) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($registro);
    responder(['ok' => true, 'registro' => $registro]);
}

function actualizar($pdo, $coleccion, $id, $campoId, $cambios) {
    $info = tablaValida($coleccion);
    $campoId = $campoId ?: $info['id'];
    validarColumnas([$campoId => null]);
    if (empty($cambios)) responder(['ok' => false, 'error' => 'Sin cambios.'], 400);
    $cambios = normalizarRegistro($cambios);
    validarColumnas($cambios);
    $set = implode(',', array_map(fn($c) => "{$c} = :{$c}", array_keys($cambios)));
    $sql = "UPDATE {$info['tabla']} SET {$set} WHERE {$campoId} = :__id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_merge($cambios, ['__id' => $id]));
    responder(['ok' => true]);
}

function reemplazarColeccion($pdo, $coleccion, $registros) {
    $info = tablaValida($coleccion);
    $pdo->beginTransaction();
    try {
        $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
        $pdo->exec("DELETE FROM {$info['tabla']}");
        foreach ($registros as $registro) {
            $registro = normalizarRegistro($registro);
            validarColumnas($registro);
            $columnas = array_keys($registro);
            $marcadores = array_map(fn($c) => ':' . $c, $columnas);
            $sql = "INSERT INTO {$info['tabla']} (" . implode(',', $columnas) . ") VALUES (" . implode(',', $marcadores) . ")";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($registro);
        }
        $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
        $pdo->commit();
        responder(['ok' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        responder(['ok' => false, 'error' => $e->getMessage()], 500);
    }
}

function restablecerTodo($pdo) {
    $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
    foreach (MAPA_COLECCIONES as $info) {
        $pdo->exec("DELETE FROM {$info['tabla']}");
    }
    $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
    responder(['ok' => true]);
}

// ---------------------------------------------------------------------
// Enrutado
// ---------------------------------------------------------------------
$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo === 'GET') {
    $accion = $_GET['accion'] ?? '';
    if ($accion === 'cargarTodo') { cargarTodo($pdo); }
    responder(['ok' => false, 'error' => 'Acción GET no reconocida.'], 400);
}

if ($metodo === 'POST') {
    $cuerpo = json_decode(file_get_contents('php://input'), true) ?? [];
    $accion = $cuerpo['accion'] ?? '';

    switch ($accion) {
        case 'insertar':
            insertar($pdo, $cuerpo['coleccion'], $cuerpo['registro']);
            break;
        case 'actualizar':
            actualizar($pdo, $cuerpo['coleccion'], $cuerpo['id'], $cuerpo['campoId'] ?? null, $cuerpo['cambios']);
            break;
        case 'reemplazarColeccion':
            reemplazarColeccion($pdo, $cuerpo['coleccion'], $cuerpo['registros']);
            break;
        case 'restablecerTodo':
            restablecerTodo($pdo);
            break;
        default:
            responder(['ok' => false, 'error' => "Acción POST no reconocida: {$accion}"], 400);
    }
}

responder(['ok' => false, 'error' => 'Método no soportado.'], 405);
