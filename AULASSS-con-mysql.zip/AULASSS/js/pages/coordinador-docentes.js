import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES } from '../data/constantes.js';
import { Usuario } from '../models/Usuario.js';
import { abrirModal, cerrarModal, mostrarAviso } from '../componentes/interfaz.js';
import {
  esCorreoInstitucionalValido,
  esContrasenaValida,
  campoNoVacio,
  mostrarErrorCampo,
  limpiarErroresFormulario,
} from '../utils/validadores.js';

await sembrarSiVacio();
const coordinador = protegerPagina([ROLES.COORDINADOR]);
if (!coordinador) throw new Error('Sesión no válida');
montarNavegacion(coordinador, 'coordinador-docentes.html');

let filtroTexto = '';
let docenteEnEdicion = null;

function misDocentes() {
  return Usuario.listarTodos().filter(
    (u) => u.usu_rol === ROLES.DOCENTE && u.facultad_id === coordinador.facultad_id
  );
}

function pintarTabla() {
  const cuerpo = document.getElementById('cuerpo-tabla');
  const vacio = document.getElementById('tabla-vacia');
  const texto = filtroTexto.trim().toLowerCase();

  const docentes = misDocentes()
    .filter((d) => {
      if (!texto) return true;
      const nombreCompleto = `${d.usu_nombres} ${d.usu_apellidos}`.toLowerCase();
      return nombreCompleto.includes(texto) || d.usu_correo.toLowerCase().includes(texto);
    })
    .sort((a, b) => a.usu_nombres.localeCompare(b.usu_nombres));

  if (docentes.length === 0) {
    cuerpo.innerHTML = '';
    vacio.classList.remove('oculto');
    return;
  }
  vacio.classList.add('oculto');

  cuerpo.innerHTML = docentes
    .map((d) => {
      const insignia =
        d.usu_estado === 'Activo'
          ? '<span class="insignia insignia-activo">Activo</span>'
          : '<span class="insignia insignia-inactivo">Inhabilitado</span>';
      const accion = d.usu_estado === 'Activo' ? 'inhabilitar' : 'reactivar';
      const icono =
        d.usu_estado === 'Activo'
          ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M8.5 8.5l7 7"/></svg>'
          : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="m9 12 2 2 4-4"/></svg>';
      return `
        <tr>
          <td class="celda-principal"><strong>${d.usu_nombres} ${d.usu_apellidos}</strong><span>${d.usu_correo}</span></td>
          <td>${insignia}</td>
          <td>
            <div class="acciones-fila">
              <button class="icono-btn" title="Editar" data-accion="editar" data-id="${d.usu_id}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/></svg>
              </button>
              <button class="icono-btn" title="${accion === 'inhabilitar' ? 'Inhabilitar' : 'Reactivar'}" data-accion="${accion}" data-id="${d.usu_id}">${icono}</button>
            </div>
          </td>
        </tr>`;
    })
    .join('');
}

function abrirModalCrear() {
  docenteEnEdicion = null;
  document.getElementById('titulo-modal-docente').textContent = 'Nuevo docente';
  document.getElementById('form-docente').reset();
  document.getElementById('docente-id').value = '';
  document.getElementById('campo-docente-contrasena').style.display = 'block';
  document.getElementById('docente-correo').disabled = false;
  mostrarAviso('zona-aviso-docente', null, '');
  limpiarErroresFormulario(['docente-nombres', 'docente-apellidos', 'docente-correo', 'docente-contrasena']);
  abrirModal('modal-docente');
}

function abrirModalEditar(id) {
  const d = Usuario.porId(id);
  if (!d) return;
  docenteEnEdicion = d;
  document.getElementById('titulo-modal-docente').textContent = 'Editar docente';
  document.getElementById('docente-id').value = d.usu_id;
  document.getElementById('docente-nombres').value = d.usu_nombres;
  document.getElementById('docente-apellidos').value = d.usu_apellidos;
  document.getElementById('docente-correo').value = d.usu_correo;
  document.getElementById('docente-correo').disabled = true;
  document.getElementById('campo-docente-contrasena').style.display = 'none';
  mostrarAviso('zona-aviso-docente', null, '');
  limpiarErroresFormulario(['docente-nombres', 'docente-apellidos', 'docente-correo', 'docente-contrasena']);
  abrirModal('modal-docente');
}

document.getElementById('boton-nuevo').addEventListener('click', abrirModalCrear);
document.getElementById('cerrar-modal-docente').addEventListener('click', () => cerrarModal('modal-docente'));
document.getElementById('cancelar-modal-docente').addEventListener('click', () => cerrarModal('modal-docente'));

document.getElementById('form-docente').addEventListener('submit', async (evento) => {
  evento.preventDefault();
  mostrarAviso('zona-aviso-docente', null, '');
  limpiarErroresFormulario(['docente-nombres', 'docente-apellidos', 'docente-correo', 'docente-contrasena']);

  const nombres = document.getElementById('docente-nombres').value.trim();
  const apellidos = document.getElementById('docente-apellidos').value.trim();
  const correo = document.getElementById('docente-correo').value.trim();
  const contrasena = document.getElementById('docente-contrasena').value;

  let valido = true;
  if (!campoNoVacio(nombres)) { mostrarErrorCampo('docente-nombres', 'Requerido.'); valido = false; }
  if (!campoNoVacio(apellidos)) { mostrarErrorCampo('docente-apellidos', 'Requerido.'); valido = false; }
  if (!esCorreoInstitucionalValido(correo)) { mostrarErrorCampo('docente-correo', 'Usa un correo institucional válido.'); valido = false; }
  if (!docenteEnEdicion && !esContrasenaValida(contrasena)) {
    mostrarErrorCampo('docente-contrasena', 'Mínimo 8 caracteres, con letras y números.');
    valido = false;
  }
  if (!valido) return;

  const botonGuardar = document.getElementById('guardar-docente');
  botonGuardar.disabled = true;

  if (docenteEnEdicion) {
    Usuario.actualizarDatos(docenteEnEdicion.usu_id, { usu_nombres: nombres, usu_apellidos: apellidos });
    cerrarModal('modal-docente');
    pintarTabla();
  } else {
    const resultado = await Usuario.crear({
      usu_nombres: nombres,
      usu_apellidos: apellidos,
      usu_correo: correo,
      contrasenaInicial: contrasena,
      usu_rol: ROLES.DOCENTE,
      facultad_id: coordinador.facultad_id,
    });
    if (!resultado.ok) {
      mostrarAviso('zona-aviso-docente', 'error', resultado.error);
      botonGuardar.disabled = false;
      return;
    }
    cerrarModal('modal-docente');
    pintarTabla();
  }
  botonGuardar.disabled = false;
});

let docenteObjetivoEstado = null;
let nuevoEstadoObjetivo = null;

document.getElementById('cuerpo-tabla').addEventListener('click', (evento) => {
  const boton = evento.target.closest('button[data-accion]');
  if (!boton) return;
  const id = Number(boton.dataset.id);
  const accion = boton.dataset.accion;

  if (accion === 'editar') {
    abrirModalEditar(id);
    return;
  }

  const d = Usuario.porId(id);
  if (!d) return;
  docenteObjetivoEstado = d;
  nuevoEstadoObjetivo = accion === 'inhabilitar' ? 'Inhabilitado' : 'Activo';

  document.getElementById('titulo-modal-estado').textContent = accion === 'inhabilitar' ? 'Inhabilitar docente' : 'Reactivar docente';
  document.getElementById('texto-modal-estado').innerHTML =
    accion === 'inhabilitar'
      ? `¿Inhabilitar a <strong>${d.usu_nombres} ${d.usu_apellidos}</strong>? No podrá iniciar sesión, pero su historial se conserva.`
      : `¿Reactivar a <strong>${d.usu_nombres} ${d.usu_apellidos}</strong>?`;
  abrirModal('modal-estado');
});

document.getElementById('cerrar-modal-estado').addEventListener('click', () => cerrarModal('modal-estado'));
document.getElementById('cancelar-modal-estado').addEventListener('click', () => cerrarModal('modal-estado'));
document.getElementById('confirmar-modal-estado').addEventListener('click', () => {
  if (!docenteObjetivoEstado) return;
  Usuario.cambiarEstado(docenteObjetivoEstado.usu_id, nuevoEstadoObjetivo);
  cerrarModal('modal-estado');
  pintarTabla();
});

document.getElementById('buscador').addEventListener('input', (evento) => {
  filtroTexto = evento.target.value;
  pintarTabla();
});

pintarTabla();
