import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES } from '../data/constantes.js';
import { Facultad } from '../models/Facultad.js';
import { Carrera } from '../models/Carrera.js';
import { abrirModal, cerrarModal, mostrarAviso } from '../componentes/interfaz.js';
import { campoNoVacio, mostrarErrorCampo, limpiarErroresFormulario } from '../utils/validadores.js';

await sembrarSiVacio();
const admin = protegerPagina([ROLES.ADMIN_SISTEMA]);
if (!admin) throw new Error('Sesión no válida');
montarNavegacion(admin, 'administrador-carreras.html');

let filtroTexto = '';
let carreraEnEdicion = null;

function nombreFacultad(id) {
  const f = Facultad.porId(id);
  return f ? f.facultad_nombre : '—';
}

function poblarSelectFacultades() {
  const select = document.getElementById('carrera-facultad');
  select.innerHTML =
    '<option value="">Selecciona una facultad</option>' +
    Facultad.listarTodas()
      .filter((f) => f.facultad_estado === 'Activa')
      .map((f) => `<option value="${f.facultad_id}">${f.facultad_nombre}</option>`)
      .join('');
}

function pintarTabla() {
  const cuerpo = document.getElementById('cuerpo-tabla');
  const vacio = document.getElementById('tabla-vacia');
  const texto = filtroTexto.trim().toLowerCase();

  const carreras = Carrera.listarTodas()
    .filter((c) => !texto || c.carrera_nombre.toLowerCase().includes(texto))
    .sort((a, b) => a.carrera_nombre.localeCompare(b.carrera_nombre));

  if (carreras.length === 0) {
    cuerpo.innerHTML = '';
    vacio.classList.remove('oculto');
    return;
  }
  vacio.classList.add('oculto');

  cuerpo.innerHTML = carreras
    .map((c) => {
      const insignia =
        c.carrera_estado === 'Activa'
          ? '<span class="insignia insignia-activo">Activa</span>'
          : '<span class="insignia insignia-inactivo">Inactiva</span>';
      const accion = c.carrera_estado === 'Activa' ? 'inactivar' : 'activar';
      const icono =
        c.carrera_estado === 'Activa'
          ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M8.5 8.5l7 7"/></svg>'
          : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="m9 12 2 2 4-4"/></svg>';
      return `
        <tr>
          <td class="celda-principal"><strong>${c.carrera_nombre}</strong></td>
          <td>${nombreFacultad(c.facultad_id)}</td>
          <td>${insignia}</td>
          <td>
            <div class="acciones-fila">
              <button class="icono-btn" title="Editar" data-accion="editar" data-id="${c.carrera_id}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/></svg>
              </button>
              <button class="icono-btn" title="${accion === 'inactivar' ? 'Inactivar' : 'Activar'}" data-accion="${accion}" data-id="${c.carrera_id}">${icono}</button>
            </div>
          </td>
        </tr>`;
    })
    .join('');
}

function abrirModalCrear() {
  carreraEnEdicion = null;
  document.getElementById('titulo-modal-carrera').textContent = 'Nueva carrera';
  document.getElementById('form-carrera').reset();
  document.getElementById('carrera-id').value = '';
  poblarSelectFacultades();
  mostrarAviso('zona-aviso-carrera', null, '');
  limpiarErroresFormulario(['carrera-nombre', 'carrera-facultad']);
  abrirModal('modal-carrera');
}

function abrirModalEditar(id) {
  const c = Carrera.porId(id);
  if (!c) return;
  carreraEnEdicion = c;
  document.getElementById('titulo-modal-carrera').textContent = 'Editar carrera';
  document.getElementById('carrera-id').value = c.carrera_id;
  document.getElementById('carrera-nombre').value = c.carrera_nombre;
  poblarSelectFacultades();
  document.getElementById('carrera-facultad').value = c.facultad_id;
  mostrarAviso('zona-aviso-carrera', null, '');
  limpiarErroresFormulario(['carrera-nombre', 'carrera-facultad']);
  abrirModal('modal-carrera');
}

document.getElementById('boton-nuevo').addEventListener('click', abrirModalCrear);
document.getElementById('cerrar-modal-carrera').addEventListener('click', () => cerrarModal('modal-carrera'));
document.getElementById('cancelar-modal-carrera').addEventListener('click', () => cerrarModal('modal-carrera'));

document.getElementById('form-carrera').addEventListener('submit', (evento) => {
  evento.preventDefault();
  mostrarAviso('zona-aviso-carrera', null, '');
  limpiarErroresFormulario(['carrera-nombre', 'carrera-facultad']);

  const nombre = document.getElementById('carrera-nombre').value.trim();
  const facultadId = document.getElementById('carrera-facultad').value;

  let valido = true;
  if (!campoNoVacio(nombre)) { mostrarErrorCampo('carrera-nombre', 'Ingresa el nombre de la carrera.'); valido = false; }
  if (!facultadId) { mostrarErrorCampo('carrera-facultad', 'Selecciona la facultad.'); valido = false; }
  if (!valido) return;

  const resultado = carreraEnEdicion
    ? Carrera.actualizar(carreraEnEdicion.carrera_id, { carrera_nombre: nombre, facultad_id: Number(facultadId) })
    : Carrera.crear({ carrera_nombre: nombre, facultad_id: Number(facultadId) });

  if (!resultado.ok) {
    mostrarAviso('zona-aviso-carrera', 'error', resultado.error);
    return;
  }
  cerrarModal('modal-carrera');
  pintarTabla();
});

let carreraObjetivoEstado = null;
let nuevoEstadoObjetivo = null;

document.getElementById('cuerpo-tabla').addEventListener('click', (evento) => {
  const boton = evento.target.closest('button[data-accion]');
  if (!boton) return;
  const id = Number(boton.dataset.id);
  const accion = boton.dataset.accion;

  if (accion === 'editar') {
    abrirModalEditar(id);
    return;
  }

  const c = Carrera.porId(id);
  if (!c) return;
  carreraObjetivoEstado = c;
  nuevoEstadoObjetivo = accion === 'inactivar' ? 'Inactiva' : 'Activa';

  document.getElementById('titulo-modal-estado').textContent = accion === 'inactivar' ? 'Inactivar carrera' : 'Activar carrera';
  document.getElementById('texto-modal-estado').innerHTML =
    accion === 'inactivar'
      ? `¿Marcar <strong>${c.carrera_nombre}</strong> como inactiva?`
      : `¿Marcar <strong>${c.carrera_nombre}</strong> como activa nuevamente?`;
  abrirModal('modal-estado');
});

document.getElementById('cerrar-modal-estado').addEventListener('click', () => cerrarModal('modal-estado'));
document.getElementById('cancelar-modal-estado').addEventListener('click', () => cerrarModal('modal-estado'));
document.getElementById('confirmar-modal-estado').addEventListener('click', () => {
  if (!carreraObjetivoEstado) return;
  Carrera.cambiarEstado(carreraObjetivoEstado.carrera_id, nuevoEstadoObjetivo);
  cerrarModal('modal-estado');
  pintarTabla();
});

document.getElementById('buscador').addEventListener('input', (evento) => {
  filtroTexto = evento.target.value;
  pintarTabla();
});

pintarTabla();
