import { ParametroPeso } from '../models/ParametroPeso.js';

export class ParametroPesoController {
  static obtenerPesos() {
    ParametroPeso.asegurarIniciales();
    return ParametroPeso.listarTodas();
  }
  static guardarPesos(pesos, usu_id) { return ParametroPeso.guardarTodos(pesos, usu_id); }
}
