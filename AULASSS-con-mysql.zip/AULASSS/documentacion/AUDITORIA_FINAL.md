# Auditoría final del sistema

## Alcance

Se revisó la versión integrada correspondiente a los cuatro ciclos frente al ERS, el modelo UML y la matriz de riesgos entregados para el proyecto.

## Hallazgos corregidos

### 1. Solapamiento real de horarios
La versión anterior comparaba algunas ocupaciones mediante una clave que exigía que las franjas fueran idénticas. Eso permitía que una franja de 07:00–09:00 y otra de 08:00–10:00 ocuparan simultáneamente el mismo aula o docente.

Se corrigió el motor para comprobar intersección real de intervalos de tiempo. Los intervalos que solo se tocan (por ejemplo 09:00–11:00 después de 07:00–09:00) no se consideran solapados.

### 2. Integridad de datos relacionados
Se impide eliminar un aula, curso o franja horaria cuando existen asignaciones relacionadas. La alternativa es conservar el registro y utilizar su estado correspondiente cuando aplique.

### 3. Conflictos repetidos
Al volver a ejecutar el motor sobre un curso que continúa en conflicto, no se acumulan registros de conflicto duplicados.

### 4. Previsualización de carga masiva
Los valores mostrados en la previsualización de archivos se escapan antes de insertarse en HTML.

### 5. Registro de acceso a reportes
La consulta y las acciones de exportación/generación de reportes dejan registro local de acceso para la demostración.

### 6. Empaquetado
La entrega final se empaqueta con el proyecto directamente en la raíz del ZIP, evitando una carpeta contenedora innecesaria.

## Limitaciones que permanecen por la arquitectura acordada

Esta versión utiliza HTML, CSS, JavaScript y `localStorage`. Por ello no se presenta como cumplimiento literal de capacidades que dependen del servidor, especialmente hashing bcrypt/Argon2, disponibilidad del 95 %, copias de respaldo/restauración y concurrencia transaccional real. Esas capacidades quedan para la integración con API y MySQL.

El criterio de cercanía y el de franja preferida permanecen neutrales porque el modelo aprobado no contiene todavía los datos necesarios para calcularlos: no existe una relación de cercanía aula-facultad ni un atributo de franja preferida en Curso. No se inventaron esos datos.

## Resultado

- Pruebas Ciclo 4: **12/12 aprobadas**.
- Auditoría crítica adicional: **8/8 aprobadas**.
- Sintaxis de todos los JavaScript: **aprobada**.
- Referencias locales de los HTML: **sin faltantes**.
