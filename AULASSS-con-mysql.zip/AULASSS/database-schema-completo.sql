-- Esquema de referencia para la futura conexión con MySQL.
-- La aplicación del Ciclo 1 actualmente utiliza localStorage; este archivo
-- no es ejecutado por el frontend.

CREATE TABLE facultad (
  facultad_id INT PRIMARY KEY AUTO_INCREMENT,
  facultad_nombre VARCHAR(120) NOT NULL,
  facultad_estado VARCHAR(20) NOT NULL DEFAULT 'Activa'
);

CREATE TABLE carrera (
  carrera_id INT PRIMARY KEY AUTO_INCREMENT,
  carrera_nombre VARCHAR(120) NOT NULL,
  facultad_id INT NOT NULL,
  carrera_estado VARCHAR(20) NOT NULL DEFAULT 'Activa',
  CONSTRAINT fk_carrera_facultad FOREIGN KEY (facultad_id) REFERENCES facultad(facultad_id),
  CONSTRAINT uq_carrera_facultad_nombre UNIQUE (facultad_id, carrera_nombre)
);

CREATE TABLE usuario (
  usu_id INT PRIMARY KEY AUTO_INCREMENT,
  usu_nombres VARCHAR(100) NOT NULL,
  usu_apellidos VARCHAR(100) NOT NULL,
  usu_correo VARCHAR(180) NOT NULL UNIQUE,
  usu_pwd_hash VARCHAR(255) NOT NULL,
  usu_rol VARCHAR(30) NOT NULL,
  facultad_id INT NULL,
  usu_estado VARCHAR(20) NOT NULL DEFAULT 'Activo',
  CONSTRAINT fk_usuario_facultad FOREIGN KEY (facultad_id) REFERENCES facultad(facultad_id)
);

CREATE TABLE recuperacion_contrasena (
  token VARCHAR(48) PRIMARY KEY,
  usu_id INT NOT NULL,
  creado DATETIME NOT NULL,
  expira DATETIME NOT NULL,
  usada BOOLEAN NOT NULL DEFAULT FALSE,
  CONSTRAINT fk_recuperacion_usuario FOREIGN KEY (usu_id) REFERENCES usuario(usu_id)
);

CREATE TABLE aula (
  aula_id INT PRIMARY KEY AUTO_INCREMENT,
  aula_codigo VARCHAR(30) NOT NULL UNIQUE,
  aula_edificio VARCHAR(80) NOT NULL,
  aula_capacidad INT NOT NULL,
  aula_tipo VARCHAR(30) NOT NULL,
  aula_estado VARCHAR(15) NOT NULL DEFAULT 'Activa'
);

CREATE TABLE tecnologia (
  tec_id INT PRIMARY KEY AUTO_INCREMENT,
  tec_nombre VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE aula_tecnologia (
  aula_id INT NOT NULL,
  tec_id INT NOT NULL,
  PRIMARY KEY (aula_id, tec_id),
  CONSTRAINT fk_aula_tecnologia_aula FOREIGN KEY (aula_id) REFERENCES aula(aula_id),
  CONSTRAINT fk_aula_tecnologia_tec FOREIGN KEY (tec_id) REFERENCES tecnologia(tec_id)
);

CREATE TABLE curso (
  curso_id INT PRIMARY KEY AUTO_INCREMENT,
  curso_nombre VARCHAR(100) NOT NULL,
  carrera_id INT NOT NULL,
  curso_docente VARCHAR(100) NOT NULL,
  curso_num_estudiantes INT NOT NULL,
  curso_tec_requerida VARCHAR(80) NOT NULL,
  curso_prioridad VARCHAR(20) NOT NULL,
  curso_horas_sesion DECIMAL(4,2) NOT NULL DEFAULT 2,
  curso_sesiones_semana INT NOT NULL DEFAULT 1,
  CONSTRAINT fk_curso_carrera FOREIGN KEY (carrera_id) REFERENCES carrera(carrera_id)
);

CREATE TABLE franja_horaria (
  franja_id INT PRIMARY KEY AUTO_INCREMENT,
  franja_dia VARCHAR(15) NOT NULL,
  franja_hora_inicio TIME NOT NULL,
  franja_hora_fin TIME NOT NULL
);


CREATE TABLE parametro_peso (
  peso_id INT PRIMARY KEY AUTO_INCREMENT,
  peso_criterio VARCHAR(40) NOT NULL UNIQUE,
  peso_valor DECIMAL(5,2) NOT NULL,
  peso_fecha_mod DATETIME NOT NULL,
  usu_id_mod INT NULL,
  CONSTRAINT fk_peso_usuario FOREIGN KEY (usu_id_mod) REFERENCES usuario(usu_id),
  CONSTRAINT ck_peso_valor CHECK (peso_valor >= 0 AND peso_valor <= 100)
);

CREATE TABLE historial_peso (
  historial_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  peso_id INT NULL,
  peso_criterio VARCHAR(40) NOT NULL,
  peso_valor DECIMAL(5,2) NOT NULL,
  peso_fecha_mod DATETIME NOT NULL,
  usu_id_mod INT NULL,
  CONSTRAINT fk_hist_peso FOREIGN KEY (peso_id) REFERENCES parametro_peso(peso_id),
  CONSTRAINT fk_hist_usuario FOREIGN KEY (usu_id_mod) REFERENCES usuario(usu_id)
);

CREATE TABLE asignacion (
  asignacion_id INT PRIMARY KEY AUTO_INCREMENT,
  curso_id INT NOT NULL,
  aula_id INT NULL,
  franja_id INT NULL,
  asignacion_hora_inicio TIME NULL,
  asignacion_hora_fin TIME NULL,
  asignacion_puntaje DECIMAL(7,2) NOT NULL DEFAULT 0,
  asignacion_tipo VARCHAR(20) NOT NULL,
  asignacion_estado VARCHAR(20) NOT NULL,
  usu_id_mod INT NULL,
  asignacion_fecha_mod DATETIME NOT NULL,
  CONSTRAINT fk_asig_curso FOREIGN KEY (curso_id) REFERENCES curso(curso_id),
  CONSTRAINT fk_asig_aula FOREIGN KEY (aula_id) REFERENCES aula(aula_id),
  CONSTRAINT fk_asig_franja FOREIGN KEY (franja_id) REFERENCES franja_horaria(franja_id),
  CONSTRAINT fk_asig_usuario FOREIGN KEY (usu_id_mod) REFERENCES usuario(usu_id)
);

-- Registro técnico de accesos a información protegida (sin crear una clase adicional del dominio).
CREATE TABLE registro_acceso (
  acceso_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  usu_id INT NOT NULL,
  modulo VARCHAR(80) NOT NULL,
  fecha DATETIME NOT NULL,
  CONSTRAINT fk_acceso_usuario FOREIGN KEY (usu_id) REFERENCES usuario(usu_id)
);
