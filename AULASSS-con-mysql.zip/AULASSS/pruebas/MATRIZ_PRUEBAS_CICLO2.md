# Matriz de pruebas — Ciclo 2

| ID | Comprobación | Resultado esperado |
|---|---|---|
| C2-01 | Crear aula con código repetido | El sistema rechaza el registro. |
| C2-02 | Crear aula con capacidad 0 o decimal | El sistema rechaza el registro. |
| C2-03 | Inactivar y reactivar aula | El estado cambia sin eliminar el registro. |
| C2-04 | Crear tecnología repetida | El sistema rechaza el registro. |
| C2-05 | Asociar dos tecnologías a un aula | Se conservan dos relaciones independientes con la estructura Aula–Tecnología. |
| C2-06 | Intentar eliminar tecnología asociada | El sistema bloquea la eliminación y conserva la relación. |
| C2-07 | Crear curso con carrera de otra facultad | El sistema rechaza el registro. |
| C2-08 | Registrar curso con estudiantes no enteros o menores que 1 | El sistema rechaza el registro. |
| C2-09 | Registrar curso con tecnología obligatoria | El curso conserva el nombre de la tecnología seleccionada. |
| C2-10 | Crear franja con inicio posterior/igual al fin | El sistema rechaza el registro. |
| C2-11 | Crear franja idéntica existente | El sistema rechaza el duplicado. |
| C2-12 | Persistencia | Los datos continúan después de recargar la página. |

## Riesgos considerados
- R2.1: las validaciones de capacidad, duplicados, pertenencia de carrera y horarios evitan datos maestros inválidos.
- R2.2: Tecnología y AulaTecnologia son entidades separadas en el modelo y en la implementación.
- R2.3: `curso_num_estudiantes` se maneja como cantidad agregada; no existe listado individual de estudiantes.
- R2.4: `curso_tec_requerida` conserva una sola tecnología obligatoria, conforme al modelo entregado.
