# Registro de revisión — Ciclo 2

Se revisó el desarrollo contra el alcance del Ciclo 2: Aula, Tecnología, Curso y Franja Horaria.

## Evidencias funcionales
- Aulas: alta, consulta, edición, cambio de estado y asociación de tecnologías.
- Tecnologías: alta, consulta, edición y eliminación controlada.
- Cursos: alta, consulta, edición y eliminación restringida a la facultad del coordinador.
- Franjas horarias: alta, consulta, edición y eliminación con validación de rango.

## Mitigación del riesgo de datos maestros
Las validaciones se ejecutan antes de guardar: código de aula único, capacidad positiva, tecnología única, pertenencia de carrera a la facultad del coordinador, cantidad de estudiantes entera y rango horario válido.

## Decisión de modelo
`Tecnologia` y `AulaTecnologia` permanecen separadas. `curso_num_estudiantes` es un dato agregado y `curso_tec_requerida` mantiene una única tecnología obligatoria, tal como está definido en el modelo de este ciclo.
