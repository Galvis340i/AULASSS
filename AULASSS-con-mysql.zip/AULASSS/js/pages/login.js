import { sembrarSiVacio } from '../data/semilla.js';
import { Usuario } from '../models/Usuario.js';
import { ROLES_INFO } from '../data/constantes.js';
import { campoNoVacio, limpiarErroresFormulario, mostrarErrorCampo, limpiarErrorCampo } from '../utils/validadores.js';
import { mostrarAviso } from '../componentes/interfaz.js';

await sembrarSiVacio();

// Si ya hay una sesión activa, saltar directo a su panel.
const sesionExistente = Usuario.sesionActual();
if (sesionExistente) {
  window.location.replace(ROLES_INFO[sesionExistente.usu_rol]?.inicio || 'index.html');
}

const formulario = document.getElementById('form-login');
const botonLogin = document.getElementById('boton-login');

formulario.addEventListener('submit', async (evento) => {
  evento.preventDefault();
  mostrarAviso('zona-aviso', null, '');
  limpiarErroresFormulario(['correo', 'contrasena']);

  const correo = document.getElementById('correo').value.trim();
  const contrasena = document.getElementById('contrasena').value;

  let valido = true;
  if (!campoNoVacio(correo)) {
    mostrarErrorCampo('correo', 'Ingresa tu correo institucional.');
    valido = false;
  }
  if (!campoNoVacio(contrasena)) {
    mostrarErrorCampo('contrasena', 'Ingresa tu contraseña.');
    valido = false;
  }
  if (!valido) return;

  botonLogin.disabled = true;
  botonLogin.textContent = 'Ingresando…';

  const resultado = await Usuario.iniciarSesion(correo, contrasena);

  if (!resultado.ok) {
    mostrarAviso('zona-aviso', 'error', resultado.error);
    botonLogin.disabled = false;
    botonLogin.textContent = 'Ingresar';
    return;
  }

  const destino = ROLES_INFO[resultado.usuario.usu_rol]?.inicio || 'index.html';
  window.location.href = destino;
});

document.getElementById('correo').addEventListener('input', () => limpiarErrorCampo('correo'));
document.getElementById('contrasena').addEventListener('input', () => limpiarErrorCampo('contrasena'));
