// Valores compartidos por todo el sistema.

export const ROLES = {
  ADMIN_SISTEMA: 'AdminSistema',
  COORDINADOR: 'Coordinador',
  DOCENTE: 'Docente',
  ADMIN_PLANTA: 'AdminPlantaFisica',
  DECANO: 'Decano',
};

export const ROLES_INFO = {
  [ROLES.ADMIN_SISTEMA]: { etiqueta: 'Administrador del sistema', inicio: 'panel-administrador.html' },
  [ROLES.COORDINADOR]: { etiqueta: 'Coordinador académico', inicio: 'panel-coordinador.html' },
  [ROLES.DOCENTE]: { etiqueta: 'Docente', inicio: 'panel-docente.html' },
  [ROLES.ADMIN_PLANTA]: { etiqueta: 'Administrador de planta física', inicio: 'panel-planta-fisica.html' },
  [ROLES.DECANO]: { etiqueta: 'Decano', inicio: 'panel-decano.html' },
};

// Roles que el Administrador del sistema puede crear directamente.
export const ROLES_CREABLES_POR_ADMIN_SISTEMA = [ROLES.COORDINADOR, ROLES.ADMIN_PLANTA, ROLES.DECANO];

// Dominio institucional aceptado para el correo de acceso.
export const DOMINIO_INSTITUCIONAL = '@uninstitucional.edu.co';

// Vigencia máxima del enlace de un solo uso para restablecer contraseña (minutos).
export const VIGENCIA_RECUPERACION_MIN = 3;

export const NOMBRE_INSTITUCION = 'Universidad';
export const NOMBRE_SISTEMA = 'Asignación de Aulas';
