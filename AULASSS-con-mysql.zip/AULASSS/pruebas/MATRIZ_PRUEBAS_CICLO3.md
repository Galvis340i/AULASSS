# Matriz de pruebas — Ciclo 3

| ID | Comprobación | Resultado esperado |
|---|---|---|
| C3-01 | Inicialización de parámetros | Existen los 5 criterios y suman 100% |
| C3-02 | Pesos con suma distinta de 100% | La actualización es rechazada |
| C3-03 | Cambio válido de pesos | Se guardan los 5 valores |
| C3-04 | Histórico de parámetros | Se conserva el valor anterior de cada criterio |
| C3-05 | Asignación automática | Los cursos compatibles reciben aula y franja |
| C3-06 | Restricción dura | Se rechaza una combinación con capacidad insuficiente |
| C3-07 | Ajuste manual | Se valida, modifica y registra usuario/tipo |
| C3-08 | Bloqueo de ejecución | Una segunda ejecución concurrente es rechazada |
| C3-09 | Pesos vigentes | El motor utiliza la configuración actual |
| C3-10 | Integridad de asignaciones | Las confirmadas tienen estado consistente |
| C3-11 | Desempate | Ante igualdad de puntaje se aplica cercanía y luego aula_id |
| C3-12 | Curso sin combinación válida | Se registra como conflicto para ajuste manual |
