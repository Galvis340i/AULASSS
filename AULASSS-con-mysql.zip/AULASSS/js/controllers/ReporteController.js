import { Curso } from '../models/Curso.js';
import { Carrera } from '../models/Carrera.js';
import { Facultad } from '../models/Facultad.js';
import { Aula } from '../models/Aula.js';
import { FranjaHoraria } from '../models/FranjaHoraria.js';
import { Asignacion } from '../models/Asignacion.js';
import { ROLES } from '../data/constantes.js';

function permitido(curso,usuario){
  if(usuario.usu_rol===ROLES.DECANO||usuario.usu_rol===ROLES.COORDINADOR){
    const carrera=Carrera.porId(curso.carrera_id); return carrera?.facultad_id===usuario.facultad_id;
  }
  return false;
}
export function datosReporte(usuario,{tipo='facultad',valor='',desde='',hasta=''}={}){
  const cursos=Curso.listarTodas().filter(c=>permitido(c,usuario));
  const carreras=Carrera.listarTodas(), facultades=Facultad.listarTodas(), asignaciones=Asignacion.confirmadas();
  const fechaOk=a=>{if(!desde&&!hasta)return true; const d=String(a.asignacion_fecha_mod||'').slice(0,10); return (!desde||d>=desde)&&(!hasta||d<=hasta);};
  const rows=cursos.flatMap(c=>{const car=carreras.find(x=>x.carrera_id===c.carrera_id),fac=facultades.find(x=>x.facultad_id===car?.facultad_id); const lista=asignaciones.filter(x=>x.curso_id===c.curso_id&&fechaOk(x)); return lista.length?lista.map(a=>{const aula=Aula.porId(a.aula_id),franja=FranjaHoraria.porId(a.franja_id); return {curso:c,carrera:car,facultad:fac,asignacion:a,aula,franja};}):[{curso:c,carrera:car,facultad:fac,asignacion:null,aula:null,franja:null}];}).filter(r=>{
    const q=String(valor).trim().toLowerCase(); if(!q)return true;
    if(tipo==='facultad')return r.facultad?.facultad_nombre.toLowerCase().includes(q);
    if(tipo==='carrera')return r.carrera?.carrera_nombre.toLowerCase().includes(q);
    if(tipo==='docente')return r.curso.curso_docente.toLowerCase().includes(q);
    return true;
  });
  const asignados=rows.filter(r=>r.asignacion), automaticos=asignados.filter(r=>r.asignacion.asignacion_tipo==='automática'),manuales=asignados.filter(r=>r.asignacion.asignacion_tipo==='manual'); const cursosAsignados=new Set(asignados.map(r=>r.curso.curso_id));
  const aulasUsadas=new Map(); for(const r of asignados){if(r.aula)aulasUsadas.set(r.aula.aula_id,(aulasUsadas.get(r.aula.aula_id)||0)+1)}
  const totalFranjas=Math.max(FranjaHoraria.listarTodas().length,1);
  const aulas=Array.from(aulasUsadas.entries()).map(([id,cantidad])=>({aula:Aula.porId(id),cantidad,porcentaje:Math.min(100,Math.round(cantidad/totalFranjas*100))}));
  const conflictos=cursos.filter(c=>!asignaciones.some(a=>a.curso_id===c.curso_id&&a.asignacion_estado==='confirmada')).map(c=>({curso:c,carrera:carreras.find(x=>x.carrera_id===c.carrera_id),facultad:facultades.find(x=>x.facultad_id===carreras.find(x=>x.carrera_id===c.carrera_id)?.facultad_id)}));
  return {rows,cursos:cursos.length,asignados:cursosAsignados.size,automaticos:automaticos.length,manuales:manuales.length,conflictos,aulas,desde,hasta,tipo,valor,facultad:facultades.find(f=>f.facultad_id===usuario.facultad_id)};
}
export function nombreFiltro(data){return data.valor?`${data.tipo}: ${data.valor}`:'Toda la información autorizada';}
