# Matriz de pruebas — Ciclo 1

Estas pruebas son la evidencia funcional del primer ciclo. No forman parte de las pantallas de los usuarios del sistema.

| Prueba | Alcance comprobado | Evidencia |
|---|---|---|
| C1-01 | Estructura de facultades | Ejecución de `npm run test:ciclo1` |
| C1-02 | Estructura de carreras y relación con facultad | Ejecución de `npm run test:ciclo1` |
| C1-03 | Formato de correo institucional | Ejecución de `npm run test:ciclo1` |
| C1-04 | Unicidad del correo | Ejecución de `npm run test:ciclo1` |
| C1-05 | Validación de contraseña | Ejecución de `npm run test:ciclo1` |
| C1-06 | Inicio de sesión válido | Ejecución de `npm run test:ciclo1` |
| C1-07 | Rechazo de credenciales incorrectas | Ejecución de `npm run test:ciclo1` |
| C1-08 | Rechazo de cuenta inhabilitada | Ejecución de `npm run test:ciclo1` |
| C1-09 | Cierre de sesión | Ejecución de `npm run test:ciclo1` |
| C1-10 | Roles administrables | Ejecución de `npm run test:ciclo1` |
| C1-11 | Menú por rol | Ejecución de `npm run test:ciclo1` |
| C1-12 | Recuperación de contraseña, vencimiento y un solo uso | Ejecución de `npm run test:ciclo1` |

## Riesgos del Ciclo 1

- **R1.1 — Roles y permisos:** queda comprobado mediante C1-10 y C1-11, además de las pruebas de acceso a las páginas durante la revisión manual.
- **R1.2 — Correo institucional:** queda comprobado mediante C1-03 y C1-04.
- **R1.3 — Vigencia del enlace:** queda comprobado mediante C1-12. La implementación usa una vigencia de 3 minutos, consistente con el requisito de seguridad del sistema.
- **R1.4 — Tiempo de validación de roles:** es un riesgo de cronograma y no una propiedad funcional del software; su evidencia corresponde al registro de revisión del ciclo y no a una prueba automática.
