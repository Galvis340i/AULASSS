import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES } from '../data/constantes.js';
import { AsignacionController } from '../controllers/AsignacionController.js';
import { Asignacion } from '../models/Asignacion.js';
import { Curso } from '../models/Curso.js';
import { Aula } from '../models/Aula.js';
import { FranjaHoraria } from '../models/FranjaHoraria.js';
import { Tecnologia } from '../models/Tecnologia.js';
import { Carrera } from '../models/Carrera.js';
import { Facultad } from '../models/Facultad.js';
import { mostrarAviso } from '../componentes/interfaz.js';

await sembrarSiVacio();
const usuario = protegerPagina([ROLES.COORDINADOR]);
if (!usuario) throw new Error('Acceso no autorizado');
montarNavegacion(usuario, 'asignaciones.html');
const facultad = Facultad.porId(usuario.facultad_id);
const modal = document.getElementById('modal-ajuste');
let filtro = '';

function textoFranja(f,a=null){ const ini=a?.asignacion_hora_inicio||f.franja_hora_inicio; const fin=a?.asignacion_hora_fin||f.franja_hora_fin; return `${f.franja_dia} ${ini}–${fin}`; }
function cursosFacultad(){ const carreras=new Set(Carrera.listarTodas().filter(c=>c.facultad_id===usuario.facultad_id).map(c=>c.carrera_id)); return Curso.listarTodas().filter(c=>carreras.has(c.carrera_id)); }
function datosVista(){ const cursos=cursosFacultad(); const mapCurso=new Map(cursos.map(c=>[c.curso_id,c])); const asignaciones=Asignacion.listarTodas().filter(a=>mapCurso.has(a.curso_id)); return {cursos,mapCurso,asignaciones}; }
function pintar(){
 const {cursos,mapCurso,asignaciones}=datosVista();
 const asignadas=asignaciones.filter(a=>a.asignacion_estado==='confirmada'); const cursosAsignados=new Set(asignadas.map(a=>a.curso_id));
 document.getElementById('resumen').innerHTML=`<div class="tarjeta-metrica"><span class="etiqueta">Cursos de la facultad</span><strong>${cursos.length}</strong></div><div class="tarjeta-metrica"><span class="etiqueta">Cursos asignados</span><strong>${cursosAsignados.size}</strong></div><div class="tarjeta-metrica"><span class="etiqueta">Pendientes</span><strong>${Math.max(cursos.length-cursosAsignados.size,0)}</strong></div>`;
 const filas=asignadas.filter(a=>mapCurso.get(a.curso_id).curso_nombre.toLowerCase().includes(filtro)).map(a=>{const c=mapCurso.get(a.curso_id),au=Aula.porId(a.aula_id),f=FranjaHoraria.porId(a.franja_id);return `<tr><td><div class="celda-principal"><strong>${c.curso_nombre}</strong><span>${c.curso_docente}</span></div></td><td>${au?.aula_codigo||'—'}</td><td>${f?textoFranja(f,a):'—'}</td><td>${a.asignacion_puntaje ?? '—'}</td><td>${a.asignacion_tipo}</td><td><span class="estado-pill activa">Confirmada</span></td><td><button class="btn-fantasma" data-ajustar="${a.asignacion_id}">Ajustar</button></td></tr>`}).join('');
 document.getElementById('tabla-asignaciones').innerHTML=filas||'<tr><td colspan="7" class="estado-vacio-tabla">No hay asignaciones para mostrar.</td></tr>';
 const ids=new Set(asignadas.map(a=>a.curso_id));
 const conflictos=cursos.filter(c=>!ids.has(c.curso_id));
 document.getElementById('tabla-conflictos').innerHTML=conflictos.length?conflictos.map(c=>{const ca=asignaciones.find(a=>a.curso_id===c.curso_id&&a.asignacion_estado==='conflicto');return `<tr><td><strong>${c.curso_nombre}</strong><div class="celda-principal"><span>${c.curso_docente}</span></div></td><td>No fue posible encontrar una combinación compatible.</td><td>${ca?`<button class="btn-secundario" data-ajustar="${ca.asignacion_id}">Ajustar manualmente</button>`:'—'}</td></tr>`}).join(''):'<tr><td colspan="3" class="estado-vacio-tabla">No hay cursos en conflicto.</td></tr>';
}
function abrir(id){
 const a=Asignacion.porId(id); if(!a)return; const c=Curso.porId(a.curso_id); if(!c)return;
 document.getElementById('asignacion_id').value=id; document.getElementById('curso_id').value=c.curso_id;
 document.getElementById('detalle-curso').innerHTML=`<strong>${c.curso_nombre}</strong><p>${c.curso_num_estudiantes} estudiantes · ${c.curso_tec_requerida} · ${c.curso_horas_sesion} h por sesión · ${c.curso_sesiones_semana} sesión(es) por semana</p>`;
 document.getElementById('aula_id').innerHTML='<option value="">Selecciona un aula</option>'+Aula.listarTodas().map(au=>`<option value="${au.aula_id}" ${au.aula_id===a.aula_id?'selected':''}>${au.aula_codigo} · ${au.aula_edificio} · ${au.aula_capacidad} cupos</option>`).join('');
 const franjas=FranjaHoraria.listarTodas(); document.getElementById('franja_id').innerHTML='<option value="">Selecciona una franja</option>'+franjas.map(f=>`<option value="${f.franja_id}" ${f.franja_id===a.franja_id?'selected':''}>${textoFranja(f)}</option>`).join('');
 const cargarHoras=()=>{const f=FranjaHoraria.porId(Number(document.getElementById('franja_id').value));const dur=Math.round(Number(c.curso_horas_sesion||2)*60);let opts='';if(f){let [h,m]=f.franja_hora_inicio.split(':').map(Number),[hf,mf]=f.franja_hora_fin.split(':').map(Number),ini=h*60+m,fin=hf*60+mf;for(let t=ini;t+dur<=fin;t+=30){const hh=String(Math.floor(t/60)).padStart(2,'0'),mm=String(t%60).padStart(2,'0');opts+=`<option value="${hh}:${mm}" ${a.asignacion_hora_inicio===`${hh}:${mm}`?'selected':''}>${hh}:${mm}</option>`;}} document.getElementById('hora_inicio').innerHTML='<option value="">Selecciona hora de inicio</option>'+opts;};
 document.getElementById('franja_id').onchange=cargarHoras; cargarHoras(); modal.hidden=false; modal.classList.add('modal--abierto');
}
function cerrar(){modal.classList.remove('modal--abierto');modal.hidden=true;}
document.getElementById('ejecutar').addEventListener('click',()=>{const b=document.getElementById('ejecutar');b.disabled=true;const r=AsignacionController.ejecutarAsignacion(usuario.facultad_id);b.disabled=false;if(!r.ok){mostrarAviso('zona-aviso','error',r.error);return;}mostrarAviso('zona-aviso',r.conflictos?'info':'ok',`Proceso terminado: ${r.asignados} asignados y ${r.conflictos} en conflicto.`);pintar();});
document.getElementById('buscar').addEventListener('input',e=>{filtro=e.target.value.trim().toLowerCase();pintar();});
document.getElementById('tabla-asignaciones').addEventListener('click',e=>{const b=e.target.closest('[data-ajustar]');if(b)abrir(Number(b.dataset.ajustar));});
document.getElementById('tabla-conflictos').addEventListener('click',e=>{const b=e.target.closest('[data-ajustar]');if(b)abrir(Number(b.dataset.ajustar));});
document.getElementById('form-ajuste').addEventListener('submit',e=>{e.preventDefault();const r=AsignacionController.ajustarAsignacion({asignacion_id:Number(document.getElementById('asignacion_id').value),curso_id:Number(document.getElementById('curso_id').value),aula_id:Number(document.getElementById('aula_id').value),franja_id:Number(document.getElementById('franja_id').value),hora_inicio:document.getElementById('hora_inicio').value},usuario.usu_id_mod||usuario.usu_id);if(!r.ok){mostrarAviso('zona-ajuste-aviso','error',r.error);return;}cerrar();mostrarAviso('zona-aviso','ok','La asignación fue modificada correctamente.');pintar();});
document.getElementById('cerrar-ajuste').addEventListener('click',cerrar);document.getElementById('cancelar-ajuste').addEventListener('click',cerrar);pintar();
