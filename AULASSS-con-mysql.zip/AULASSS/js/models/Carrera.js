import { Almacen, siguienteId } from '../data/almacen.js';

const COLECCION = 'carreras';

export class Carrera {
  constructor({ carrera_id, carrera_nombre, facultad_id, carrera_estado }) {
    this.carrera_id = carrera_id;
    this.carrera_nombre = carrera_nombre;
    this.facultad_id = facultad_id;
    this.carrera_estado = carrera_estado;
  }

  static listarTodas() {
    return Almacen.listar(COLECCION);
  }

  static porId(id) {
    return Almacen.obtenerPorId(COLECCION, id, 'carrera_id');
  }

  static porFacultad(facultad_id) {
    return Carrera.listarTodas().filter((c) => c.facultad_id === facultad_id);
  }

  static nombreYaExisteEnFacultad(nombre, facultad_id, excluirId = null) {
    const objetivo = nombre.trim().toLowerCase();
    return Carrera.listarTodas().some(
      (c) =>
        c.carrera_nombre.trim().toLowerCase() === objetivo &&
        c.facultad_id === facultad_id &&
        c.carrera_id !== excluirId
    );
  }

  static crear({ carrera_nombre, facultad_id }) {
    if (Carrera.nombreYaExisteEnFacultad(carrera_nombre, facultad_id)) {
      return { ok: false, error: 'Esa facultad ya tiene una carrera con ese nombre.' };
    }
    const registro = Almacen.insertar(COLECCION, {
      carrera_id: siguienteId('carrera'),
      carrera_nombre: carrera_nombre.trim(),
      facultad_id,
      carrera_estado: 'Activa',
    });
    return { ok: true, carrera: registro };
  }

  static actualizar(carrera_id, { carrera_nombre, facultad_id }) {
    if (Carrera.nombreYaExisteEnFacultad(carrera_nombre, facultad_id, carrera_id)) {
      return { ok: false, error: 'Esa facultad ya tiene una carrera con ese nombre.' };
    }
    const registro = Almacen.actualizar(COLECCION, carrera_id, 'carrera_id', {
      carrera_nombre: carrera_nombre.trim(),
      facultad_id,
    });
    return { ok: true, carrera: registro };
  }

  static cambiarEstado(carrera_id, nuevoEstado) {
    return Almacen.actualizar(COLECCION, carrera_id, 'carrera_id', { carrera_estado: nuevoEstado });
  }
}
