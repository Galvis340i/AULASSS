import { Almacen } from '../data/almacen.js';
const COLECCION='aulaTecnologias';
export class AulaTecnologia {
  constructor({ aula_id, tec_id }) { this.aula_id=aula_id; this.tec_id=tec_id; }
  static listarTodas(){return Almacen.listar(COLECCION);}
  static porAula(aula_id){return this.listarTodas().filter(r=>r.aula_id===aula_id);}
  static asociar(aula_id,tec_ids){
    const aula=Almacen.obtenerPorId('aulas',aula_id,'aula_id'); if(!aula)return {ok:false,error:'El aula seleccionada no existe.'};
    const tecnologias=Almacen.listar('tecnologias'); const validas=[...new Set(tec_ids.map(Number))].filter(id=>tecnologias.some(t=>t.tec_id===id));
    const actuales=this.porAula(aula_id); const nuevas=validas.filter(id=>!actuales.some(r=>r.tec_id===id));
    nuevas.forEach(tec_id=>Almacen.insertar(COLECCION,{aula_id,tec_id})); return {ok:true,agregadas:nuevas.length};
  }
  static desasociar(aula_id,tec_id){const base=this.listarTodas(); const existe=base.some(r=>r.aula_id===aula_id&&r.tec_id===tec_id); if(!existe)return {ok:false,error:'La asociación no existe.'}; Almacen.reemplazarColeccion(COLECCION,base.filter(r=>!(r.aula_id===aula_id&&r.tec_id===tec_id))); return {ok:true};}
}
