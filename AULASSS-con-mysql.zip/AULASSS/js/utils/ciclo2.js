import { sembrarSiVacio } from '../data/semilla.js';
export async function prepararCiclo2(){ await sembrarSiVacio(); }
export function escapar(texto){ return String(texto??'').replace(/[&<>'"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#039;'}[c])); }
