# Sistema Web de Asignación de Aulas — Versión integrada final

Versión de demostración institucional construida con HTML, CSS y JavaScript, usando `localStorage` como almacenamiento temporal. La estructura de datos y el SQL están preparados para la futura conexión con MySQL.

## Ejecución

Abrir el proyecto mediante un servidor local. No se recomienda abrir los HTML con `file://`, porque los módulos ES y algunas funciones del navegador requieren HTTP.

## Accesos de demostración

Todas las cuentas semilla usan la contraseña `Institucion2026`.

- admin.sistema@uninstitucional.edu.co
- coordinador.ingenieria@uninstitucional.edu.co
- docente.demo@uninstitucional.edu.co
- plantafisica@uninstitucional.edu.co
- decano.ingenieria@uninstitucional.edu.co

## Versión integrada final

Integra los cuatro ciclos: gestión académica, infraestructura, asignación automática y manual, carga masiva y reportes.

Las pruebas y la evidencia de validación están en `pruebas/`. No se muestran en las pantallas de los actores.

## Verificación final

Antes de esta entrega se ejecutaron las pruebas funcionales de los cuatro ciclos y una auditoría crítica adicional sobre solapamientos de horarios, integridad de asignaciones y eliminación de datos relacionados.

- Pruebas del Ciclo 4: 12/12 aprobadas.
- Auditoría crítica final: 8/8 aprobadas.
- Sintaxis JavaScript: verificada.
- Referencias locales HTML/CSS/JS: verificadas.

La carpeta `pruebas/` contiene la evidencia de las comprobaciones.
