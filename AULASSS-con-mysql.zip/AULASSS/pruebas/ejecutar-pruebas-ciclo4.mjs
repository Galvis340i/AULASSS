import assert from 'node:assert/strict';
globalThis.localStorage={_m:new Map(),getItem(k){return this._m.get(k)??null},setItem(k,v){this._m.set(k,String(v))},removeItem(k){this._m.delete(k)}};
globalThis.performance={now:()=>Date.now()};
const {Almacen}=await import('../js/data/almacen.js');
const {leerArchivo,validarFilas,confirmarCarga}=await import('../js/controllers/CargaMasivaController.js');
const {datosReporte}=await import('../js/controllers/ReporteController.js');
const {AsignacionController}=await import('../js/controllers/AsignacionController.js');
Almacen.reemplazarColeccion('facultades',[{facultad_id:1,facultad_nombre:'Ingeniería',facultad_estado:'Activa'},{facultad_id:2,facultad_nombre:'Ciencias Humanas',facultad_estado:'Activa'}]);
Almacen.reemplazarColeccion('carreras',[{carrera_id:1,carrera_nombre:'Ingeniería de Sistemas',facultad_id:1,carrera_estado:'Activa'},{carrera_id:2,carrera_nombre:'Psicología',facultad_id:2,carrera_estado:'Activa'}]);
Almacen.reemplazarColeccion('usuarios',[{usu_id:7,usu_nombres:'Coord',usu_apellidos:'Demo',usu_correo:'coord@uninstitucional.edu.co',usu_rol:'Coordinador',facultad_id:1,usu_estado:'Activo'},{usu_id:8,usu_nombres:'Decano',usu_apellidos:'Demo',usu_correo:'dec@uninstitucional.edu.co',usu_rol:'Decano',facultad_id:1,usu_estado:'Activo'}]);
Almacen.reemplazarColeccion('aulas',[{aula_id:1,aula_codigo:'A1',aula_edificio:'Bloque A',aula_capacidad:30,aula_tipo:'Laboratorio',aula_estado:'Activa'}]);
Almacen.reemplazarColeccion('tecnologias',[{tec_id:1,tec_nombre:'Computadores'}]);
Almacen.reemplazarColeccion('aulaTecnologias',[{aula_id:1,tec_id:1}]);
Almacen.reemplazarColeccion('cursos',[]);Almacen.reemplazarColeccion('franjas',[{franja_id:1,franja_dia:'Lunes',franja_hora_inicio:'07:00',franja_hora_fin:'09:00'}]);Almacen.reemplazarColeccion('asignaciones',[]);Almacen.reemplazarColeccion('parametrosPeso',[{peso_id:1,peso_criterio:'tecnologia',peso_valor:30},{peso_id:2,peso_criterio:'capacidad',peso_valor:30},{peso_id:3,peso_criterio:'cercania',peso_valor:15},{peso_id:4,peso_criterio:'prioridad_carrera',peso_valor:15},{peso_id:5,peso_criterio:'franja_preferida',peso_valor:10}]);
const tests=[];const t=async(id,fn)=>{await fn();tests.push(id)};
await t('C4-01',async()=>{const rows=await leerArchivo({name:'datos.csv',size:80,text:async()=>`aula_codigo,aula_edificio,aula_capacidad,aula_tipo,aula_estado\nA2,Bloque B,40,Salón,Activa\n`});assert.equal(rows.length,2)});
await t('C4-02',()=>{const v=validarFilas('aulas',[['aula_codigo','aula_edificio','aula_capacidad','aula_tipo','aula_estado'],['A2','Bloque B','40','Salón','Activa']]);assert.equal(v.ok,true)});
await t('C4-03',()=>{const v=validarFilas('aulas',[['aula_codigo','aula_edificio','aula_capacidad','aula_tipo','aula_estado'],['A1','Bloque B','40','Salón','Activa']]);assert.equal(v.ok,false);assert.match(v.errores[0],/ya existe/)})
await t('C4-04',()=>{const v=validarFilas('cursos',[['curso_nombre','carrera_nombre','curso_docente','curso_num_estudiantes','curso_tec_requerida','curso_prioridad'],['Curso X','No existe','Docente','20','Computadores','Alta']],{usu_rol:'Coordinador',facultad_id:1});assert.equal(v.ok,false);assert.ok(v.errores.some(e=>e.includes('carrera')))})
await t('C4-05',()=>{const v=validarFilas('aulas',[['aula_codigo','aula_edificio','aula_capacidad','aula_tipo','aula_estado'],['A3','Bloque C','30','Salón','Activa']]);const r=confirmarCarga('aulas',v.registros,7);assert.equal(r.ok,true);assert.equal(r.cargados,1)})
await t('C4-06',()=>{const file={name:'grande.csv',size:5*1024*1024+1,text:async()=>''};return leerArchivo(file).then(()=>assert.fail()).catch(e=>assert.match(e.message,/5 MB/))})
await t('C4-07',()=>{const filas=[['curso_nombre','carrera_nombre','curso_docente','curso_num_estudiantes','curso_tec_requerida','curso_prioridad'],...Array.from({length:1000},(_,i)=>[`Curso ${i}`,'Ingeniería de Sistemas','Docente',20,'Computadores','Media'])];const ini=Date.now();const v=validarFilas('cursos',filas,{usu_rol:'Coordinador',facultad_id:1});const ms=Date.now()-ini;assert.equal(v.ok,true);assert.equal(v.registros.length,1000);assert.ok(ms<30000,`validación: ${ms} ms`);const r=confirmarCarga('cursos',v.registros,7);assert.equal(r.ok,true);assert.equal(r.cargados,1000);assert.ok(r.ms<30000,`carga: ${r.ms} ms`)})
await t('C4-08',()=>{const d=datosReporte({usu_id:8,usu_rol:'Decano',facultad_id:1},{tipo:'carrera',valor:'Ingeniería de Sistemas'});assert.equal(d.rows.length,1000);assert.equal(d.conflictos.length,1000)})
await t('C4-09',()=>{const d=datosReporte({usu_id:8,usu_rol:'Decano',facultad_id:1},{tipo:'carrera',valor:'Psicología'});assert.equal(d.rows.length,0)})
await t('C4-10',()=>{Almacen.registrarAcceso({usu_id:8,modulo:'Reportes'});assert.equal(JSON.parse(localStorage.getItem('aulas_db_v1')).registrosAcceso.length,1)})
await t('C4-11',()=>{localStorage.setItem('aulas_carga_bloqueo_v1',JSON.stringify({token:'x',creado:Date.now()}));assert.equal(AsignacionController.ejecutarAsignacion(1).ok,false);localStorage.removeItem('aulas_carga_bloqueo_v1')})
await t('C4-12',()=>{const d=datosReporte({usu_id:8,usu_rol:'Decano',facultad_id:1},{tipo:'facultad',valor:''});assert.equal(d.cursos,1000);assert.equal(d.automaticos,0);assert.equal(d.manuales,0)})
console.log(`${tests.length}/12 comprobaciones del Ciclo 4 aprobadas.`);
