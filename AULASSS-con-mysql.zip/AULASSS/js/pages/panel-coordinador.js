import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES } from '../data/constantes.js';
import { Usuario } from '../models/Usuario.js';
import { Facultad } from '../models/Facultad.js';
import { Carrera } from '../models/Carrera.js';
import { Curso } from '../models/Curso.js';
import { FranjaHoraria } from '../models/FranjaHoraria.js';

await sembrarSiVacio();
const coordinador = protegerPagina([ROLES.COORDINADOR]);
if (coordinador) {
  montarNavegacion(coordinador, 'panel-coordinador.html');
  document.getElementById('saludo').textContent = `Hola, ${coordinador.usu_nombres}`;
  const facultad = Facultad.porId(coordinador.facultad_id);
  document.getElementById('descripcion-facultad').textContent = facultad ? `Facultad de ${facultad.facultad_nombre}` : '';
  const carreras = Carrera.listarTodas().filter(c => c.facultad_id === coordinador.facultad_id);
  const cursos = Curso.listarTodas().filter(c => carreras.some(carrera => carrera.carrera_id === c.carrera_id));
  const docentes = Usuario.listarTodos().filter(u => u.usu_rol === ROLES.DOCENTE && u.facultad_id === coordinador.facultad_id);
  document.getElementById('tarjetas-resumen').innerHTML = `
    <a class="tarjeta-metrica" href="cursos.html"><span class="etiqueta">Cursos de mi facultad</span><strong>${cursos.length}</strong><span class="detalle">Gestionar oferta académica</span></a>
    <a class="tarjeta-metrica" href="franjas.html"><span class="etiqueta">Franjas horarias</span><strong>${FranjaHoraria.listarTodas().length}</strong><span class="detalle">Consultar bloques disponibles</span></a>
    <div class="tarjeta-metrica"><span class="etiqueta">Docentes activos</span><strong>${docentes.filter(d => d.usu_estado === 'Activo').length}</strong><span class="detalle">${docentes.length} registrados</span></div>`;
}
