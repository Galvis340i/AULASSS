import { Aula } from '../models/Aula.js';
import { AulaTecnologia } from '../models/AulaTecnologia.js';

export class AulaController {
  static crearAula(datos) { return Aula.crear(datos); }
  static actualizarAula(id, datos) { return Aula.actualizar(id, datos); }
  static asociarTecnologias(aula_id, tec_ids) { return AulaTecnologia.asociar(aula_id, tec_ids); }
  static desasociarTecnologia(aula_id, tec_id) { return AulaTecnologia.desasociar(aula_id, tec_id); }
}
