# Ciclo 3 — Motor de asignación

Implementación alineada con el objetivo del ciclo: construir y calibrar el motor de asignación automática y el ajuste manual.

## Clases utilizadas
- `ParametroPeso`
- `Asignacion`
- `Curso`
- `Aula`
- `FranjaHoraria`
- `AulaTecnologia`
- `Tecnologia`
- `Carrera`

## Flujo de asignación
1. El coordinador ejecuta la asignación de su facultad.
2. Se adquiere un bloqueo de ejecución para la facultad.
3. Se leen los pesos vigentes.
4. Se obtienen los cursos pendientes.
5. Se generan combinaciones curso-aula-franja.
6. Se descartan capacidad, tecnología, solapamiento de aula y solapamiento de docente.
7. Se calcula el puntaje ponderado.
8. Se selecciona el mayor puntaje; en empate se usa cercanía y luego `aula_id`.
9. Si no hay combinación válida, el curso queda en estado `conflicto` para ajuste manual.
10. Se libera el bloqueo y se presenta el resumen.

## Ajuste manual
La nueva aula y franja se validan antes de confirmar. La modificación cambia `asignacion_tipo` a `manual` y registra `usu_id_mod` y `asignacion_fecha_mod`.

## Parámetros
Los cinco criterios son `tecnologia`, `capacidad`, `cercania`, `prioridad_carrera` y `franja_preferida`. La suma debe ser exactamente 100%. Los cambios conservan histórico.

## Datos simulados y MySQL
La interfaz trabaja con localStorage. El esquema SQL incorpora las tablas de parámetros, histórico y asignación para la futura conexión con MySQL.
