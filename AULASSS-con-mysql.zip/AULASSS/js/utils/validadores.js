import { DOMINIO_INSTITUCIONAL } from '../data/constantes.js';

export function esCorreoInstitucionalValido(correo) {
  if (!correo) return false;
  const patron = /^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
  return patron.test(correo.trim()) && correo.trim().toLowerCase().endsWith(DOMINIO_INSTITUCIONAL);
}

export function esContrasenaValida(contrasena) {
  // Mínimo 8 caracteres, al menos una letra y un número.
  if (!contrasena || contrasena.length < 8) return false;
  return /[A-Za-z]/.test(contrasena) && /[0-9]/.test(contrasena);
}

export function campoNoVacio(valor) {
  return typeof valor === 'string' && valor.trim().length > 0;
}

export function mostrarErrorCampo(idCampo, mensaje) {
  const input = document.getElementById(idCampo);
  const errorEl = document.getElementById(`error-${idCampo}`);
  if (input) input.classList.add('campo--error');
  if (errorEl) errorEl.textContent = mensaje;
}

export function limpiarErrorCampo(idCampo) {
  const input = document.getElementById(idCampo);
  const errorEl = document.getElementById(`error-${idCampo}`);
  if (input) input.classList.remove('campo--error');
  if (errorEl) errorEl.textContent = '';
}

export function limpiarErroresFormulario(idsCampos) {
  idsCampos.forEach(limpiarErrorCampo);
}
