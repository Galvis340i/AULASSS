import assert from 'node:assert/strict';
globalThis.localStorage={_m:new Map(),getItem(k){return this._m.get(k)??null},setItem(k,v){this._m.set(k,String(v))},removeItem(k){this._m.delete(k)}};
globalThis.performance={now:()=>Date.now()};
const {Almacen}=await import('../js/data/almacen.js');
const {ParametroPeso}=await import('../js/models/ParametroPeso.js');
const {Asignacion}=await import('../js/models/Asignacion.js');
const {AsignacionController}=await import('../js/controllers/AsignacionController.js');
Almacen.reemplazarColeccion('facultades',[{facultad_id:1,facultad_nombre:'Ingeniería',facultad_estado:'Activa'}]);
Almacen.reemplazarColeccion('carreras',[{carrera_id:1,carrera_nombre:'Ingeniería de Sistemas',facultad_id:1,carrera_estado:'Activa'}]);
Almacen.reemplazarColeccion('usuarios',[{usu_id:7,usu_nombres:'Coord',usu_apellidos:'Demo',usu_correo:'coord@uninstitucional.edu.co',usu_rol:'Coordinador',facultad_id:1,usu_estado:'Activo'}]);
Almacen.reemplazarColeccion('aulas',[{aula_id:1,aula_codigo:'A1',aula_edificio:'Bloque A',aula_capacidad:30,aula_tipo:'Laboratorio',aula_estado:'Activa'},{aula_id:2,aula_codigo:'A2',aula_edificio:'Bloque B',aula_capacidad:60,aula_tipo:'Salón',aula_estado:'Activa'}]);
Almacen.reemplazarColeccion('tecnologias',[{tec_id:1,tec_nombre:'Computadores'},{tec_id:2,tec_nombre:'Proyector'}]);
Almacen.reemplazarColeccion('aulaTecnologias',[{aula_id:1,tec_id:1},{aula_id:1,tec_id:2},{aula_id:2,tec_id:2}]);
Almacen.reemplazarColeccion('cursos',[{curso_id:1,curso_nombre:'Programación Web',carrera_id:1,curso_docente:'Docente A',curso_num_estudiantes:28,curso_tec_requerida:'Computadores',curso_prioridad:'Alta'},{curso_id:2,curso_nombre:'Redes',carrera_id:1,curso_docente:'Docente B',curso_num_estudiantes:50,curso_tec_requerida:'Proyector',curso_prioridad:'Media'}]);
Almacen.reemplazarColeccion('franjas',[{franja_id:1,franja_dia:'Lunes',franja_hora_inicio:'07:00',franja_hora_fin:'09:00'},{franja_id:2,franja_dia:'Lunes',franja_hora_inicio:'09:00',franja_hora_fin:'11:00'}]);
Almacen.reemplazarColeccion('parametrosPeso',[]);Almacen.reemplazarColeccion('historialPesos',[]);Almacen.reemplazarColeccion('asignaciones',[]);
const tests=[];const t=(id,fn)=>{fn();tests.push(id)};
t('C3-01',()=>{ParametroPeso.asegurarIniciales(7);assert.equal(ParametroPeso.sumaPesos(),100)});
t('C3-02',()=>assert.equal(ParametroPeso.guardarTodos({tecnologia:40,capacidad:40,cercania:10,prioridad_carrera:10,franja_preferida:10},7).ok,false));
t('C3-03',()=>{assert.equal(ParametroPeso.guardarTodos({tecnologia:40,capacidad:30,cercania:10,prioridad_carrera:10,franja_preferida:10},7).ok,true);assert.ok(ParametroPeso.listarTodas().length===5)});
t('C3-04',()=>assert.ok(JSON.parse(localStorage.getItem('aulas_db_v1')).historialPesos.length===5));
t('C3-05',()=>{const r=AsignacionController.ejecutarAsignacion(1);assert.equal(r.ok,true);assert.equal(r.asignados,2);assert.equal(Asignacion.confirmadas().length,2)});
t('C3-06',()=>{const a=Asignacion.confirmadas()[0];const c=JSON.parse(localStorage.getItem('aulas_db_v1')).cursos.find(x=>x.curso_id===a.curso_id);const r=AsignacionController.validarAjuste({asignacion_id:a.asignacion_id,curso_id:c.curso_id,aula_id:2,franja_id:a.franja_id});assert.equal(r.ok,false)});
t('C3-07',()=>{const a=Asignacion.confirmadas()[0];const c=JSON.parse(localStorage.getItem('aulas_db_v1')).cursos.find(x=>x.curso_id===a.curso_id);const fr=JSON.parse(localStorage.getItem('aulas_db_v1')).franjas.find(x=>x.franja_id!==a.franja_id);const r=AsignacionController.ajustarAsignacion({asignacion_id:a.asignacion_id,curso_id:c.curso_id,aula_id:a.aula_id,franja_id:fr.franja_id},7);assert.equal(r.ok,true);assert.equal(Asignacion.porId(a.asignacion_id).asignacion_tipo,'manual');assert.equal(Asignacion.porId(a.asignacion_id).usu_id_mod,7)});
t('C3-08',()=>{localStorage.setItem('aulas_motor_bloqueo_v1',JSON.stringify({token:'otro',facultad_id:1,creado:Date.now()}));assert.equal(AsignacionController.ejecutarAsignacion(1).ok,false);localStorage.removeItem('aulas_motor_bloqueo_v1')});
t('C3-09',()=>{const pesos=ParametroPeso.listarTodas();assert.equal(pesos.reduce((s,p)=>s+p.peso_valor,0),100)});
t('C3-10',()=>{const db=JSON.parse(localStorage.getItem('aulas_db_v1'));assert.ok(db.asignaciones.every(a=>a.asignacion_estado==='confirmada'))});

t('C3-11',()=>{
  const db=JSON.parse(localStorage.getItem('aulas_db_v1'));
  db.asignaciones=[]; db.secuencias.asignacion=0;
  db.cursos=[...Array.from({length:200},(_,i)=>({curso_id:i+1,curso_nombre:`Curso ${i+1}`,carrera_id:1,curso_docente:`Docente ${i+1}`,curso_num_estudiantes:20,curso_tec_requerida:'Computadores',curso_prioridad:'Media'}))];
  db.aulas=Array.from({length:20},(_,i)=>({aula_id:i+1,aula_codigo:`A${i+1}`,aula_edificio:'Bloque A',aula_capacidad:30,aula_tipo:'Salón',aula_estado:'Activa'}));
  db.aulaTecnologias=db.aulas.map(a=>({aula_id:a.aula_id,tec_id:1}));
  db.franjas=Array.from({length:10},(_,i)=>({franja_id:i+1,franja_dia:['Lunes','Martes','Miércoles','Jueves','Viernes'][i%5],franja_hora_inicio:'07:00',franja_hora_fin:'09:00'}));
  localStorage.setItem('aulas_db_v1',JSON.stringify(db));
  const inicio=Date.now(); const r=AsignacionController.ejecutarAsignacion(1); const ms=Date.now()-inicio;
  assert.equal(r.ok,true); assert.equal(r.totalProcesados,200); assert.ok(ms<5000,`La prueba piloto tardó ${ms} ms`);
});
t('C3-12',()=>{
  const db=JSON.parse(localStorage.getItem('aulas_db_v1'));
  const asig=Asignacion.listarTodas().find(a=>a.asignacion_estado==='conflicto');
  assert.ok(asig);
  const r=AsignacionController.ajustarAsignacion({asignacion_id:asig.asignacion_id,curso_id:asig.curso_id,aula_id:1,franja_id:1},7);
  assert.equal(r.ok,false);
});

console.log(`${tests.length}/12 comprobaciones del Ciclo 3 aprobadas.`);
