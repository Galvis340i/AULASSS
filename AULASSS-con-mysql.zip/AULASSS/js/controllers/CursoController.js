import { Carrera } from '../models/Carrera.js';
import { Curso } from '../models/Curso.js';

export class CursoController {
  static carreraPerteneceAFacultad(carrera_id, facultad_id) {
    const carrera = Carrera.porId(carrera_id);
    return Boolean(carrera && carrera.facultad_id === facultad_id && carrera.carrera_estado === 'Activa');
  }

  static crearCurso(datos, facultad_id) {
    if (!this.carreraPerteneceAFacultad(datos.carrera_id, facultad_id)) {
      return { ok: false, error: 'La carrera seleccionada no pertenece a tu facultad.' };
    }
    return Curso.crear(datos);
  }

  static actualizarCurso(id, datos, facultad_id) {
    if (!this.carreraPerteneceAFacultad(datos.carrera_id, facultad_id)) {
      return { ok: false, error: 'La carrera seleccionada no pertenece a tu facultad.' };
    }
    const curso = Curso.porId(id);
    if (!curso || !this.carreraPerteneceAFacultad(curso.carrera_id, facultad_id)) {
      return { ok: false, error: 'El curso no pertenece a tu facultad.' };
    }
    return Curso.actualizar(id, datos);
  }
}
