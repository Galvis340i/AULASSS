import { Almacen, siguienteId } from '../data/almacen.js';
const COLECCION='franjas';
export class FranjaHoraria {
  constructor({ franja_id, franja_dia, franja_hora_inicio, franja_hora_fin }) { Object.assign(this,{franja_id,franja_dia,franja_hora_inicio,franja_hora_fin}); }
  static listarTodas(){return Almacen.listar(COLECCION);}
  static porId(id){return Almacen.obtenerPorId(COLECCION,id,'franja_id');}
  static esDuplicada(datos,excluirId=null){return this.listarTodas().some(f=>f.franja_dia===datos.franja_dia&&f.franja_hora_inicio===datos.franja_hora_inicio&&f.franja_hora_fin===datos.franja_hora_fin&&f.franja_id!==excluirId);}
  static crear(datos){if(!datos.franja_dia||!datos.franja_hora_inicio||!datos.franja_hora_fin||datos.franja_hora_inicio>=datos.franja_hora_fin)return {ok:false,error:'La hora de inicio debe ser anterior a la hora de fin.'};if(this.esDuplicada(datos))return {ok:false,error:'Ya existe esa franja horaria.'};const r=Almacen.insertar(COLECCION,{franja_id:siguienteId('franja'),...datos});return {ok:true,franja:r};}
  static actualizar(id,datos){if(!datos.franja_dia||!datos.franja_hora_inicio||!datos.franja_hora_fin||datos.franja_hora_inicio>=datos.franja_hora_fin)return {ok:false,error:'La hora de inicio debe ser anterior a la hora de fin.'};if(this.esDuplicada(datos,id))return {ok:false,error:'Ya existe esa franja horaria.'};const r=Almacen.actualizar(COLECCION,id,'franja_id',datos);return {ok:true,franja:r};}
  static eliminar(id){if(!this.porId(id))return {ok:false,error:'La franja no existe.'};if(Almacen.listar('asignaciones').some(a=>a.franja_id===id))return {ok:false,error:'No se puede eliminar una franja con asignaciones registradas.'};const base=this.listarTodas();Almacen.reemplazarColeccion(COLECCION,base.filter(f=>f.franja_id!==id));return {ok:true};}
}
