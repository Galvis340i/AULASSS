import { Almacen, siguienteId } from '../data/almacen.js';

const COLECCION = 'parametrosPeso';
const HISTORIAL = 'historialPesos';
const CRITERIOS = ['tecnologia', 'capacidad', 'cercania', 'prioridad_carrera', 'franja_preferida'];

export class ParametroPeso {
  constructor({ peso_id, peso_criterio, peso_valor, peso_fecha_mod, usu_id_mod }) {
    Object.assign(this, { peso_id, peso_criterio, peso_valor, peso_fecha_mod, usu_id_mod });
  }

  static criterios() { return [...CRITERIOS]; }
  static listarTodas() { return Almacen.listar(COLECCION); }
  static porCriterio(criterio) { return this.listarTodas().find(p => p.peso_criterio === criterio) || null; }

  static sumaPesos() { return this.listarTodas().reduce((s, p) => s + Number(p.peso_valor || 0), 0); }

  static validarPesos(pesos) {
    const valores = {};
    for (const criterio of CRITERIOS) {
      const valor = Number(pesos[criterio]);
      if (!Number.isFinite(valor) || valor < 0 || valor > 100) {
        return { ok: false, error: 'Cada peso debe estar entre 0 y 100.' };
      }
      valores[criterio] = valor;
    }
    const suma = Object.values(valores).reduce((a, b) => a + b, 0);
    if (Math.abs(suma - 100) > 0.000001) {
      return { ok: false, error: `La suma de los pesos debe ser 100%. Actualmente es ${suma}%.` };
    }
    return { ok: true, valores };
  }

  static guardarTodos(pesos, usu_id_mod = null) {
    const validacion = this.validarPesos(pesos);
    if (!validacion.ok) return validacion;
    const ahora = new Date().toISOString();
    const actuales = this.listarTodas();
    const historial = Almacen.listar(HISTORIAL);
    const nuevos = CRITERIOS.map((criterio) => {
      const anterior = actuales.find(p => p.peso_criterio === criterio);
      if (anterior) {
        historial.push({ ...anterior, historial_id: `${Date.now()}-${criterio}`, historial_fecha: ahora });
        return { ...anterior, peso_valor: validacion.valores[criterio], peso_fecha_mod: ahora, usu_id_mod };
      }
      return { peso_id: siguienteId('peso'), peso_criterio: criterio, peso_valor: validacion.valores[criterio], peso_fecha_mod: ahora, usu_id_mod };
    });
    Almacen.reemplazarColeccion(COLECCION, nuevos);
    Almacen.reemplazarColeccion(HISTORIAL, historial);
    return { ok: true, parametros: nuevos };
  }

  static asegurarIniciales(usu_id_mod = null) {
    if (this.listarTodas().length === CRITERIOS.length) return this.listarTodas();
    const base = { tecnologia: 30, capacidad: 30, cercania: 15, prioridad_carrera: 15, franja_preferida: 10 };
    this.guardarTodos(base, usu_id_mod);
    return this.listarTodas();
  }
}
