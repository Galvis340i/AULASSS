import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES } from '../data/constantes.js';
import { leerArchivo, validarFilas, confirmarCarga, CARGA_FORMATOS } from '../controllers/CargaMasivaController.js';
import { mostrarAviso } from '../componentes/interfaz.js';

await sembrarSiVacio();
const usuario=protegerPagina([ROLES.COORDINADOR,ROLES.ADMIN_PLANTA]);
if(!usuario)throw new Error('Acceso no autorizado');
montarNavegacion(usuario,'carga-masiva.html');
const $=id=>document.getElementById(id); let resultado=null;
const tipo=()=>$('tipo').value; const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('\"','&quot;');
function csvLine(vals){return vals.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')+'\n';}
function plantilla(){const t=tipo();const filas=[CARGA_FORMATOS[t],t==='aulas'?['AUL-301','Bloque C','35','Salón','Activa']:['Cálculo I','Ingeniería de Sistemas','Laura Pérez','30','Proyector','Alta']];const blob=new Blob([filas.map(csvLine).join('')],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`plantilla-${t}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);}
function pintar(rows,validacion){$('resultado').hidden=false;$('confirmar').disabled=!validacion.ok;$('resumen-validacion').textContent=`${validacion.registros.length} filas detectadas · ${validacion.ok?'Lista para confirmar':'Corrige los errores antes de continuar.'}`;$('errores-carga').innerHTML=validacion.errores.length?`<div class="aviso aviso--error"><strong>Revisa estos datos:</strong><ul>${validacion.errores.map(e=>`<li>${e}</li>`).join('')}</ul></div>`:'';const headers=rows[0]||[];$('encabezado-preview').innerHTML=`<tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr>`;$('preview').innerHTML=rows.slice(1,21).map(r=>`<tr>${headers.map((_,i)=>`<td>${esc(r[i])}</td>`).join('')}</tr>`).join('')||'<tr><td colspan="20" class="estado-vacio-tabla">No hay datos.</td></tr>';}
$('plantilla').addEventListener('click',plantilla);
$('validar').addEventListener('click',async()=>{const file=$('archivo').files[0];if(!file){mostrarAviso('zona-aviso','error','Selecciona un archivo.');return;}try{const rows=await leerArchivo(file);resultado=validarFilas(tipo(),rows,usuario);pintar(rows,resultado);if(resultado.ok)mostrarAviso('zona-aviso','ok','Archivo validado correctamente. Aún no se ha guardado información.');else mostrarAviso('zona-aviso','error','El archivo contiene datos que deben corregirse.');}catch(e){resultado=null;$('resultado').hidden=true;mostrarAviso('zona-aviso','error',e.message||'No fue posible leer el archivo.');}});
$('confirmar').addEventListener('click',()=>{if(!resultado?.ok)return;const r=confirmarCarga(tipo(),resultado.registros,usuario.usu_id);if(r.ok){mostrarAviso('zona-aviso','ok',`Carga completada: ${r.cargados} registros incorporados.`);$('archivo').value='';$('confirmar').disabled=true;$('resultado').hidden=true;resultado=null;}else mostrarAviso('zona-aviso','error',r.error);});
