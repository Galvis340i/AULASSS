import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES } from '../data/constantes.js';
import { Facultad } from '../models/Facultad.js';
import { Carrera } from '../models/Carrera.js';
import { abrirModal, cerrarModal, mostrarAviso } from '../componentes/interfaz.js';
import { campoNoVacio, mostrarErrorCampo, limpiarErroresFormulario } from '../utils/validadores.js';

await sembrarSiVacio();
const admin = protegerPagina([ROLES.ADMIN_SISTEMA]);
if (!admin) throw new Error('Sesión no válida');
montarNavegacion(admin, 'administrador-facultades.html');

let filtroTexto = '';
let facultadEnEdicion = null;

function pintarTabla() {
  const cuerpo = document.getElementById('cuerpo-tabla');
  const vacio = document.getElementById('tabla-vacia');
  const texto = filtroTexto.trim().toLowerCase();

  const facultades = Facultad.listarTodas()
    .filter((f) => !texto || f.facultad_nombre.toLowerCase().includes(texto))
    .sort((a, b) => a.facultad_nombre.localeCompare(b.facultad_nombre));

  if (facultades.length === 0) {
    cuerpo.innerHTML = '';
    vacio.classList.remove('oculto');
    return;
  }
  vacio.classList.add('oculto');

  cuerpo.innerHTML = facultades
    .map((f) => {
      const totalCarreras = Carrera.porFacultad(f.facultad_id).length;
      const insignia =
        f.facultad_estado === 'Activa'
          ? '<span class="insignia insignia-activo">Activa</span>'
          : '<span class="insignia insignia-inactivo">Inactiva</span>';
      const accion = f.facultad_estado === 'Activa' ? 'inactivar' : 'activar';
      const icono =
        f.facultad_estado === 'Activa'
          ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M8.5 8.5l7 7"/></svg>'
          : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="m9 12 2 2 4-4"/></svg>';
      return `
        <tr>
          <td class="celda-principal"><strong>${f.facultad_nombre}</strong></td>
          <td>${totalCarreras}</td>
          <td>${insignia}</td>
          <td>
            <div class="acciones-fila">
              <button class="icono-btn" title="Editar" data-accion="editar" data-id="${f.facultad_id}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/></svg>
              </button>
              <button class="icono-btn" title="${accion === 'inactivar' ? 'Inactivar' : 'Activar'}" data-accion="${accion}" data-id="${f.facultad_id}">${icono}</button>
            </div>
          </td>
        </tr>`;
    })
    .join('');
}

function abrirModalCrear() {
  facultadEnEdicion = null;
  document.getElementById('titulo-modal-facultad').textContent = 'Nueva facultad';
  document.getElementById('form-facultad').reset();
  document.getElementById('facultad-id').value = '';
  mostrarAviso('zona-aviso-facultad', null, '');
  limpiarErroresFormulario(['facultad-nombre']);
  abrirModal('modal-facultad');
}

function abrirModalEditar(id) {
  const f = Facultad.porId(id);
  if (!f) return;
  facultadEnEdicion = f;
  document.getElementById('titulo-modal-facultad').textContent = 'Editar facultad';
  document.getElementById('facultad-id').value = f.facultad_id;
  document.getElementById('facultad-nombre').value = f.facultad_nombre;
  mostrarAviso('zona-aviso-facultad', null, '');
  limpiarErroresFormulario(['facultad-nombre']);
  abrirModal('modal-facultad');
}

document.getElementById('boton-nuevo').addEventListener('click', abrirModalCrear);
document.getElementById('cerrar-modal-facultad').addEventListener('click', () => cerrarModal('modal-facultad'));
document.getElementById('cancelar-modal-facultad').addEventListener('click', () => cerrarModal('modal-facultad'));

document.getElementById('form-facultad').addEventListener('submit', (evento) => {
  evento.preventDefault();
  mostrarAviso('zona-aviso-facultad', null, '');
  limpiarErroresFormulario(['facultad-nombre']);

  const nombre = document.getElementById('facultad-nombre').value.trim();
  if (!campoNoVacio(nombre)) {
    mostrarErrorCampo('facultad-nombre', 'Ingresa el nombre de la facultad.');
    return;
  }

  const resultado = facultadEnEdicion
    ? Facultad.actualizar(facultadEnEdicion.facultad_id, { facultad_nombre: nombre })
    : Facultad.crear({ facultad_nombre: nombre });

  if (!resultado.ok) {
    mostrarAviso('zona-aviso-facultad', 'error', resultado.error);
    return;
  }
  cerrarModal('modal-facultad');
  pintarTabla();
});

let facultadObjetivoEstado = null;
let nuevoEstadoObjetivo = null;

document.getElementById('cuerpo-tabla').addEventListener('click', (evento) => {
  const boton = evento.target.closest('button[data-accion]');
  if (!boton) return;
  const id = Number(boton.dataset.id);
  const accion = boton.dataset.accion;

  if (accion === 'editar') {
    abrirModalEditar(id);
    return;
  }

  const f = Facultad.porId(id);
  if (!f) return;
  facultadObjetivoEstado = f;
  nuevoEstadoObjetivo = accion === 'inactivar' ? 'Inactiva' : 'Activa';

  document.getElementById('titulo-modal-estado').textContent = accion === 'inactivar' ? 'Inactivar facultad' : 'Activar facultad';
  document.getElementById('texto-modal-estado').innerHTML =
    accion === 'inactivar'
      ? `¿Marcar <strong>${f.facultad_nombre}</strong> como inactiva? Sus carreras existentes se conservan.`
      : `¿Marcar <strong>${f.facultad_nombre}</strong> como activa nuevamente?`;
  abrirModal('modal-estado');
});

document.getElementById('cerrar-modal-estado').addEventListener('click', () => cerrarModal('modal-estado'));
document.getElementById('cancelar-modal-estado').addEventListener('click', () => cerrarModal('modal-estado'));
document.getElementById('confirmar-modal-estado').addEventListener('click', () => {
  if (!facultadObjetivoEstado) return;
  Facultad.cambiarEstado(facultadObjetivoEstado.facultad_id, nuevoEstadoObjetivo);
  cerrarModal('modal-estado');
  pintarTabla();
});

document.getElementById('buscador').addEventListener('input', (evento) => {
  filtroTexto = evento.target.value;
  pintarTabla();
});

pintarTabla();
