import { Almacen, siguienteId } from '../data/almacen.js';
import { cifrarContrasena, verificarContrasena, generarTokenUnico } from '../utils/cifrado.js';
import { guardarSesion, limpiarSesion, obtenerSesion } from '../utils/sesion.js';
import { VIGENCIA_RECUPERACION_MIN } from '../data/constantes.js';

const COLECCION = 'usuarios';

export class Usuario {
  constructor({ usu_id, usu_nombres, usu_apellidos, usu_correo, usu_pwd_hash, usu_rol, facultad_id, usu_estado }) {
    this.usu_id = usu_id;
    this.usu_nombres = usu_nombres;
    this.usu_apellidos = usu_apellidos;
    this.usu_correo = usu_correo;
    this.usu_pwd_hash = usu_pwd_hash;
    this.usu_rol = usu_rol;
    this.facultad_id = facultad_id;
    this.usu_estado = usu_estado;
  }

  static porCorreo(correo) {
    if (!correo) return null;
    const objetivo = correo.trim().toLowerCase();
    return Almacen.listar(COLECCION).find((u) => u.usu_correo.toLowerCase() === objetivo) || null;
  }

  static porId(id) {
    return Almacen.obtenerPorId(COLECCION, id, 'usu_id');
  }

  static listarTodos() {
    return Almacen.listar(COLECCION);
  }

  static correoYaRegistrado(correo) {
    return Boolean(Usuario.porCorreo(correo));
  }

  static async crear({ usu_nombres, usu_apellidos, usu_correo, contrasenaInicial, usu_rol, facultad_id }) {
    if (Usuario.correoYaRegistrado(usu_correo)) {
      return { ok: false, error: 'Ese correo institucional ya está registrado.' };
    }
    const usu_pwd_hash = await cifrarContrasena(contrasenaInicial);
    const registro = Almacen.insertar(COLECCION, {
      usu_id: siguienteId('usuario'),
      usu_nombres: usu_nombres.trim(),
      usu_apellidos: usu_apellidos.trim(),
      usu_correo: usu_correo.trim().toLowerCase(),
      usu_pwd_hash,
      usu_rol,
      facultad_id: facultad_id ?? null,
      usu_estado: 'Activo',
    });
    return { ok: true, usuario: registro };
  }

  static actualizarDatos(usu_id, cambios) {
    const permitidos = ['usu_nombres', 'usu_apellidos', 'usu_rol', 'facultad_id'];
    const filtrado = {};
    permitidos.forEach((campo) => {
      if (campo in cambios) filtrado[campo] = cambios[campo];
    });
    return Almacen.actualizar(COLECCION, usu_id, 'usu_id', filtrado);
  }

  static cambiarEstado(usu_id, nuevoEstado) {
    return Almacen.actualizar(COLECCION, usu_id, 'usu_id', { usu_estado: nuevoEstado });
  }

  // ---- Métodos de acceso (según diagrama de clases: iniciarSesion, cerrarSesion, recuperarContrasena) ----

  static async iniciarSesion(correo, contrasena) {
    const usuario = Usuario.porCorreo(correo);
    const mensajeGenerico = 'El correo o la contraseña no son válidos, o la cuenta está inhabilitada.';

    if (!usuario) return { ok: false, error: mensajeGenerico };
    if (usuario.usu_estado !== 'Activo') return { ok: false, error: mensajeGenerico };

    const coincide = await verificarContrasena(contrasena, usuario.usu_pwd_hash);
    if (!coincide) return { ok: false, error: mensajeGenerico };

    const token = generarTokenUnico();
    guardarSesion({ usu_id: usuario.usu_id, token });
    return { ok: true, usuario, token };
  }

  static cerrarSesion() {
    limpiarSesion();
  }

  static async recuperarContrasena(correo) {
    const usuario = Usuario.porCorreo(correo);
    // Por seguridad no se revela si el correo existe o no; el enlace solo
    // se genera cuando sí corresponde a una cuenta registrada.
    if (!usuario) {
      return { ok: true, generado: false };
    }
    const token = generarTokenUnico();
    const ahora = Date.now();
    const registro = {
      token,
      usu_id: usuario.usu_id,
      creado: ahora,
      expira: ahora + VIGENCIA_RECUPERACION_MIN * 60 * 1000,
      usada: false,
    };
    Almacen.insertar('recuperaciones', registro);
    return { ok: true, generado: true, token, correo: usuario.usu_correo };
  }

  static verificarTokenRecuperacion(token) {
    const solicitud = Almacen.listar('recuperaciones').find((r) => r.token === token);
    if (!solicitud) return { valido: false, error: 'El enlace no es válido. Solicita uno nuevo.' };
    if (solicitud.usada) return { valido: false, error: 'Este enlace ya fue utilizado. Solicita uno nuevo.' };
    if (Date.now() > solicitud.expira) return { valido: false, error: 'El enlace venció. Solicita uno nuevo.' };
    return { valido: true };
  }

  static async definirNuevaContrasena(token, nuevaContrasena) {
    const recuperaciones = Almacen.listar('recuperaciones');
    const solicitud = recuperaciones.find((r) => r.token === token);

    if (!solicitud) return { ok: false, error: 'El enlace no es válido. Solicita uno nuevo.' };
    if (solicitud.usada) return { ok: false, error: 'Este enlace ya fue utilizado. Solicita uno nuevo.' };
    if (Date.now() > solicitud.expira) return { ok: false, error: 'El enlace venció. Solicita uno nuevo.' };

    const usu_pwd_hash = await cifrarContrasena(nuevaContrasena);
    Almacen.actualizar(COLECCION, solicitud.usu_id, 'usu_id', { usu_pwd_hash });

    const actualizadas = recuperaciones.map((r) => (r.token === token ? { ...r, usada: true } : r));
    Almacen.reemplazarColeccion('recuperaciones', actualizadas);

    return { ok: true };
  }

  static sesionActual() {
    const sesion = obtenerSesion();
    if (!sesion) return null;
    const usuario = Usuario.porId(sesion.usu_id);
    if (!usuario || usuario.usu_estado !== 'Activo') return null;
    return usuario;
  }
}
