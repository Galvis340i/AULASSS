import { sembrarSiVacio } from '../data/semilla.js';
import { Almacen } from '../data/almacen.js';
import { Usuario } from '../models/Usuario.js';
import { formatearFecha } from '../componentes/interfaz.js';

await sembrarSiVacio();

const lista = document.getElementById('lista-correos');
const recuperaciones = [...Almacen.listar('recuperaciones')].reverse();

if (recuperaciones.length === 0) {
  lista.innerHTML = '<div class="panel-vacio"><h3>Sin enlaces todavía</h3><p>Solicita la recuperación de contraseña desde el login para ver aquí el enlace generado.</p></div>';
} else {
  lista.innerHTML = recuperaciones
    .map((r) => {
      const usuario = Usuario.porId(r.usu_id);
      const vencido = Date.now() > r.expira;
      const estado = r.usada ? 'Ya utilizado' : vencido ? 'Vencido' : 'Vigente';
      const enlace = `restablecer-contrasena.html?token=${r.token}`;
      return `
        <div class="correo-item">
          <p>Para: <strong>${usuario ? usuario.usu_correo : 'correo desconocido'}</strong> · Generado: ${formatearFecha(r.creado)}</p>
          <a href="${enlace}">${window.location.origin}${window.location.pathname.replace('simulador-correo.html', '')}${enlace}</a>
          <p class="venc">Estado: ${estado} · Vence: ${formatearFecha(r.expira)}</p>
        </div>`;
    })
    .join('');
}
