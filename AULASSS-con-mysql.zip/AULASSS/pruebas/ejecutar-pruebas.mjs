import assert from 'node:assert/strict';

globalThis.localStorage = {
  _m: new Map(),
  getItem(k){ return this._m.get(k) ?? null; },
  setItem(k,v){ this._m.set(k,String(v)); },
  removeItem(k){ this._m.delete(k); }
};

const { Almacen } = await import('../js/data/almacen.js');
const { Aula } = await import('../js/models/Aula.js');
const { Tecnologia } = await import('../js/models/Tecnologia.js');
const { AulaTecnologia } = await import('../js/models/AulaTecnologia.js');
const { Curso } = await import('../js/models/Curso.js');
const { CursoController } = await import('../js/controllers/CursoController.js');
const { FranjaHoraria } = await import('../js/models/FranjaHoraria.js');

Almacen.reemplazarColeccion('facultades', [
  { facultad_id: 1, facultad_nombre: 'Ingeniería', facultad_estado: 'Activa' },
  { facultad_id: 2, facultad_nombre: 'Ciencias Humanas', facultad_estado: 'Activa' }
]);
Almacen.reemplazarColeccion('carreras', [
  { carrera_id: 1, carrera_nombre: 'Ingeniería de Sistemas', facultad_id: 1, carrera_estado: 'Activa' },
  { carrera_id: 2, carrera_nombre: 'Psicología', facultad_id: 2, carrera_estado: 'Activa' }
]);
Almacen.reemplazarColeccion('usuarios', []);

const resultados = [];
function prueba(id, fn){ fn(); resultados.push(id); }

prueba('C2-01', () => {
  Aula.crear({aula_codigo:'A-01',aula_edificio:'Bloque A',aula_capacidad:30,aula_tipo:'Salón'});
  assert.equal(Aula.crear({aula_codigo:'A-01',aula_edificio:'Bloque B',aula_capacidad:20,aula_tipo:'Salón'}).ok,false);
});
prueba('C2-02', () => assert.equal(Aula.crear({aula_codigo:'A-02',aula_edificio:'Bloque A',aula_capacidad:0,aula_tipo:'Salón'}).ok,false));
prueba('C2-03', () => { Aula.cambiarEstado(1,'Inactiva'); assert.equal(Aula.porId(1).aula_estado,'Inactiva'); Aula.cambiarEstado(1,'Activa'); assert.equal(Aula.porId(1).aula_estado,'Activa'); });
prueba('C2-04', () => { Tecnologia.crear({tec_nombre:'Proyector'}); assert.equal(Tecnologia.crear({tec_nombre:'Proyector'}).ok,false); });
prueba('C2-05', () => { assert.equal(AulaTecnologia.asociar(1,[1]).ok,true); Tecnologia.crear({tec_nombre:'Computadores'}); AulaTecnologia.asociar(1,[2]); assert.equal(AulaTecnologia.porAula(1).length,2); });
prueba('C2-06', () => assert.equal(Tecnologia.eliminar(1).ok,false));
prueba('C2-07', () => assert.equal(CursoController.crearCurso({curso_nombre:'Psicología General',carrera_id:2,curso_docente:'Docente',curso_num_estudiantes:20,curso_tec_requerida:'Proyector',curso_prioridad:'Alta'},1).ok,false));
prueba('C2-08', () => assert.equal(Curso.crear({curso_nombre:'Curso inválido',carrera_id:1,curso_docente:'Docente',curso_num_estudiantes:2.5,curso_tec_requerida:'Proyector',curso_prioridad:'Alta'}).ok,false));
prueba('C2-09', () => { const c=Curso.crear({curso_nombre:'Programación Web',carrera_id:1,curso_docente:'Docente',curso_num_estudiantes:28,curso_tec_requerida:'Computadores',curso_prioridad:'Alta'}); assert.equal(c.curso.curso_tec_requerida,'Computadores'); });
prueba('C2-10', () => assert.equal(FranjaHoraria.crear({franja_dia:'Lunes',franja_hora_inicio:'10:00',franja_hora_fin:'09:00'}).ok,false));
prueba('C2-11', () => { FranjaHoraria.crear({franja_dia:'Lunes',franja_hora_inicio:'07:00',franja_hora_fin:'09:00'}); assert.equal(FranjaHoraria.crear({franja_dia:'Lunes',franja_hora_inicio:'07:00',franja_hora_fin:'09:00'}).ok,false); });
prueba('C2-12', () => { const antes=Almacen.listar('aulas').length; const raw=localStorage.getItem('aulas_db_v1'); assert.ok(raw); const otraBase=JSON.parse(raw); assert.equal(otraBase.aulas.length,antes); });

console.log(`${resultados.length}/12 comprobaciones del Ciclo 2 aprobadas.`);
