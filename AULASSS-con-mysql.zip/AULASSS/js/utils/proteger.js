import { Usuario } from '../models/Usuario.js';
import { ROLES_INFO } from '../data/constantes.js';

// Debe llamarse al inicio de cada página interna, antes de pintar contenido.
// Si no hay sesión válida, envía al login. Si el rol no está autorizado para
// esa página, envía al usuario a su propio inicio (no a un error técnico).
export function protegerPagina(rolesPermitidos) {
  const usuario = Usuario.sesionActual();
  if (!usuario) {
    window.location.replace('index.html');
    return null;
  }
  if (rolesPermitidos && !rolesPermitidos.includes(usuario.usu_rol)) {
    const inicio = ROLES_INFO[usuario.usu_rol]?.inicio || 'index.html';
    window.location.replace(inicio);
    return null;
  }
  return usuario;
}
