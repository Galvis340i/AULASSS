import { sembrarSiVacio } from '../data/semilla.js';
import { protegerPagina } from '../utils/proteger.js';
import { montarNavegacion } from '../componentes/navegacion.js';
import { ROLES } from '../data/constantes.js';
import { Asignacion } from '../models/Asignacion.js';
import { Curso } from '../models/Curso.js';
import { Aula } from '../models/Aula.js';
import { FranjaHoraria } from '../models/FranjaHoraria.js';
import { AulaTecnologia } from '../models/AulaTecnologia.js';
import { Tecnologia } from '../models/Tecnologia.js';
import { formatearFecha } from '../componentes/interfaz.js';

await sembrarSiVacio();
const usuario = protegerPagina([ROLES.DOCENTE]);
if (!usuario) throw new Error('Acceso no autorizado');
montarNavegacion(usuario, 'panel-docente.html');

const cursos = Curso.listarTodas().filter(c => c.curso_docente.trim().toLowerCase() === `${usuario.usu_nombres} ${usuario.usu_apellidos}`.trim().toLowerCase());
const asignaciones = Asignacion.confirmadas();
const filas = cursos.map(c => {
  const a = asignaciones.find(x => x.curso_id === c.curso_id);
  const aula = a ? Aula.porId(a.aula_id) : null;
  const franja = a ? FranjaHoraria.porId(a.franja_id) : null;
  const tecnologias = aula ? AulaTecnologia.porAula(aula.aula_id).map(r => Tecnologia.porId(r.tec_id)?.tec_nombre).filter(Boolean).join(', ') : '';
  return `<tr><td><strong>${c.curso_nombre}</strong></td><td>${aula?.aula_codigo || 'Pendiente'}</td><td>${franja ? `${franja.franja_dia} ${franja.franja_hora_inicio}–${franja.franja_hora_fin}` : 'Pendiente'}</td><td>${tecnologias || '—'}</td></tr>`;
}).join('');
document.getElementById('tabla-docente').innerHTML = filas || '<tr><td colspan="4" class="estado-vacio-tabla">No hay cursos registrados a tu nombre.</td></tr>';
document.getElementById('cantidad-cursos').textContent = cursos.length;
document.getElementById('cantidad-asignados').textContent = cursos.filter(c => asignaciones.some(a => a.curso_id === c.curso_id)).length;
