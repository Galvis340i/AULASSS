import { Almacen, siguienteId } from '../data/almacen.js';

const COLECCION = 'asignaciones';

export class Asignacion {
  constructor({ asignacion_id, curso_id, aula_id, franja_id, asignacion_hora_inicio, asignacion_hora_fin, asignacion_puntaje, asignacion_tipo, asignacion_estado, usu_id_mod, asignacion_fecha_mod }) {
    Object.assign(this, { asignacion_id, curso_id, aula_id, franja_id, asignacion_hora_inicio, asignacion_hora_fin, asignacion_puntaje, asignacion_tipo, asignacion_estado, usu_id_mod, asignacion_fecha_mod });
  }

  static listarTodas() { return Almacen.listar(COLECCION); }
  static porId(id) { return Almacen.obtenerPorId(COLECCION, id, 'asignacion_id'); }
  static porCurso(curso_id) { return this.listarTodas().filter(a => a.curso_id === curso_id); }
  static confirmadas() { return this.listarTodas().filter(a => a.asignacion_estado === 'confirmada'); }
  static eliminarDeCurso(curso_id) { Almacen.reemplazarColeccion(COLECCION, this.listarTodas().filter(a => a.curso_id !== curso_id)); }

  static crear(datos) {
    const ahora = new Date().toISOString();
    const registro = {
      asignacion_id: siguienteId('asignacion'),
      ...datos,
      asignacion_fecha_mod: ahora,
    };
    Almacen.insertar(COLECCION, registro);
    return { ok: true, asignacion: registro };
  }

  static actualizar(id, cambios) {
    return Almacen.actualizar(COLECCION, id, 'asignacion_id', { ...cambios, asignacion_fecha_mod: new Date().toISOString() });
  }
}
