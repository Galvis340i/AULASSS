import { Almacen, obtenerBase } from '../data/almacen.js';
import { Asignacion } from '../models/Asignacion.js';
import { ParametroPeso } from '../models/ParametroPeso.js';
import { Curso } from '../models/Curso.js';
import { Aula } from '../models/Aula.js';
import { AulaTecnologia } from '../models/AulaTecnologia.js';
import { Tecnologia } from '../models/Tecnologia.js';
import { FranjaHoraria } from '../models/FranjaHoraria.js';
import { Carrera } from '../models/Carrera.js';

const CLAVE_BLOQUEO = 'aulas_motor_bloqueo_v1';
const CLAVE_CARGA = 'aulas_carga_bloqueo_v1';
const VIGENCIA_BLOQUEO_MS = 120000;

function cargaActiva(){ try { const x=JSON.parse(localStorage.getItem(CLAVE_CARGA)||'null'); return x && Date.now()-x.creado<120000; } catch { return false; } }

function obtenerBloqueo() {
  try { return JSON.parse(localStorage.getItem(CLAVE_BLOQUEO) || 'null'); } catch { return null; }
}

function adquirirBloqueo(facultad_id) {
  if(cargaActiva()) return {ok:false,error:'Hay una carga de información en curso. Espera a que finalice antes de ejecutar la asignación.'};
  const actual = obtenerBloqueo();
  if (actual && Date.now() - actual.creado < VIGENCIA_BLOQUEO_MS) {
    return { ok: false, error: 'La asignación de esta facultad ya se está ejecutando. Espera a que finalice.' };
  }
  const token = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  localStorage.setItem(CLAVE_BLOQUEO, JSON.stringify({ token, facultad_id, creado: Date.now() }));
  return { ok: true, token };
}

function liberarBloqueo(token) {
  const actual = obtenerBloqueo();
  if (actual?.token === token) localStorage.removeItem(CLAVE_BLOQUEO);
}

function normalizarHora(hora) { return String(hora || '').slice(0, 5); }
function minutos(hora) { const [h,m]=normalizarHora(hora).split(':').map(Number); return (h*60)+(m||0); }
function horaTexto(total) { const h=Math.floor(total/60); const m=total%60; return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`; }
function duracionCurso(curso) { return Math.round(Number(curso.curso_horas_sesion || 2) * 60); }
function ventanasEnFranja(franja, curso) { const dur=duracionCurso(curso); const inicio=minutos(franja.franja_hora_inicio), fin=minutos(franja.franja_hora_fin); if(fin-inicio<dur)return []; const out=[]; for(let t=inicio;t+dur<=fin;t+=30) out.push({...franja,franja_hora_inicio:horaTexto(t),franja_hora_fin:horaTexto(t+dur)}); return out; }
function duracionAsignacion(asig, franja) { return { ...franja, franja_hora_inicio: asig.asignacion_hora_inicio || franja?.franja_hora_inicio, franja_hora_fin: asig.asignacion_hora_fin || franja?.franja_hora_fin }; }

function solapa(f1, f2) {
  return f1.franja_dia === f2.franja_dia && normalizarHora(f1.franja_hora_inicio) < normalizarHora(f2.franja_hora_fin) && normalizarHora(f2.franja_hora_inicio) < normalizarHora(f1.franja_hora_fin);
}

function tecnologiaDisponible(aula_id, requerida) {
  const tecnologia = String(requerida || '').trim().toLowerCase();
  return AulaTecnologia.porAula(aula_id).some(rel => {
    const t = Tecnologia.porId(rel.tec_id);
    return t?.tec_nombre?.trim().toLowerCase() === tecnologia;
  });
}

function puntajeCapacidad(aula, curso) {
  const diferencia = aula.aula_capacidad - curso.curso_num_estudiantes;
  if (diferencia < 0) return 0;
  if (diferencia === 0) return 100;
  const porcentaje = diferencia / aula.aula_capacidad;
  if (porcentaje <= 0.15) return 95;
  if (porcentaje <= 0.30) return 85;
  if (porcentaje <= 0.50) return 70;
  return 55;
}

function puntajePrioridad(curso) {
  return ({ Alta: 100, Media: 60, Baja: 30 }[curso.curso_prioridad] ?? 50);
}

function puntajeCercania() {
  // El modelo actual no contiene una relación aula-facultad ni coordenadas.
  // Se conserva un valor neutral hasta que esa relación forme parte del modelo aprobado.
  return 50;
}

function puntajeFranja() {
  // El modelo actual de Curso no contiene una franja preferida.
  return 50;
}

function combinacionOcupada(aula_id, franja_id, excluirCurso = null) {
  const franja = FranjaHoraria.porId(franja_id);
  if (!franja) return true;
  return Asignacion.confirmadas().some(asig => {
    if (asig.curso_id === excluirCurso) return false;
    if (asig.aula_id !== aula_id) return false;
    const otraBase = FranjaHoraria.porId(asig.franja_id);
    const otra = otraBase ? duracionAsignacion(asig, otraBase) : null;
    return otra ? solapa(franja, otra) : false;
  });
}

function docenteOcupado(curso, franja_id, excluirCurso = null) {
  const franja = FranjaHoraria.porId(franja_id);
  if (!franja) return true;
  return Asignacion.confirmadas().some(asig => {
    if (asig.curso_id === excluirCurso) return false;
    const otroCurso = Curso.porId(asig.curso_id);
    const otraBase = FranjaHoraria.porId(asig.franja_id);
    const otra = otraBase ? duracionAsignacion(asig, otraBase) : null;
    return otroCurso?.curso_docente?.trim().toLowerCase() === curso.curso_docente.trim().toLowerCase() && otra ? solapa(franja, otra) : false;
  });
}

function calcularPuntaje(curso, aula, franja, pesos) {
  const componentes = {
    tecnologia: tecnologiaDisponible(aula.aula_id, curso.curso_tec_requerida) ? 100 : 0,
    capacidad: puntajeCapacidad(aula, curso),
    cercania: puntajeCercania(),
    prioridad_carrera: puntajePrioridad(curso),
    franja_preferida: puntajeFranja(),
  };
  const total = Object.entries(componentes).reduce((sum, [criterio, valor]) => sum + valor * (Number(pesos[criterio]) / 100), 0);
  return { total: Number(total.toFixed(2)), componentes };
}

function calcularPuntajeRapido(curso, aula, pesos, tecnologiaOk) {
  const componentes = {
    tecnologia: tecnologiaOk ? 100 : 0,
    capacidad: puntajeCapacidad(aula, curso),
    cercania: 50,
    prioridad_carrera: puntajePrioridad(curso),
    franja_preferida: 50,
  };
  const total = Object.entries(componentes).reduce((sum, [criterio, valor]) => sum + valor * (Number(pesos[criterio]) / 100), 0);
  return { total: Number(total.toFixed(2)), componentes };
}

function intervaloSolapa(f1, f2) { return solapa(f1, f2); }
function aulaOcupadaEn(aula_id, franja, ocupaciones) {
  return (ocupaciones.get(aula_id) || []).some(otra => intervaloSolapa(franja, otra));
}
function docenteOcupadoEn(curso, franja, ocupaciones) {
  const clave = curso.curso_docente.trim().toLowerCase();
  return (ocupaciones.get(clave) || []).some(otra => intervaloSolapa(franja, otra));
}
function registrarOcupacion(map, clave, franja) {
  if (!map.has(clave)) map.set(clave, []);
  map.get(clave).push(franja);
}
function candidatoValido(curso, aula, franja, ocupacion = null, docentesOcupados = null) {
  if (aula.aula_estado !== 'Activa') return false;
  if (aula.aula_capacidad < curso.curso_num_estudiantes) return false;
  if (!tecnologiaDisponible(aula.aula_id, curso.curso_tec_requerida)) return false;
  if (ocupacion ? aulaOcupadaEn(aula.aula_id, franja, ocupacion) : combinacionOcupada(aula.aula_id, franja.franja_id)) return false;
  if (docentesOcupados ? docenteOcupadoEn(curso, franja, docentesOcupados) : docenteOcupado(curso, franja.franja_id)) return false;
  return true;
}

export class AsignacionController {
  static calcularPuntaje(curso, aula, franja, pesos) { return calcularPuntaje(curso, aula, franja, pesos); }

  static ejecutarAsignacion(facultad_id) {
    ParametroPeso.asegurarIniciales();
    const bloqueo = adquirirBloqueo(facultad_id);
    if (!bloqueo.ok) return bloqueo;

    const inicio = performance.now();
    try {
      const carreraIds = Carrera.listarTodas().filter(c => c.facultad_id === facultad_id && c.carrera_estado === 'Activa').map(c => c.carrera_id);
      const cursos = Curso.listarTodas().filter(c => carreraIds.includes(c.carrera_id));
      const asignacionesActuales = Asignacion.listarTodas();
      const cursosAsignados = new Set(asignacionesActuales.filter(a => a.asignacion_estado === 'confirmada').map(a => a.curso_id));
      const pendientes = cursos.filter(c => !cursosAsignados.has(c.curso_id));
      const aulas = Aula.listarTodas();
      const franjas = FranjaHoraria.listarTodas();
      const pesos = Object.fromEntries(ParametroPeso.listarTodas().map(p => [p.peso_criterio, Number(p.peso_valor)]));
      const resultados = [];
      const asignacionesNuevas = [];
      let nextAsignacionId = Math.max(0, ...Asignacion.listarTodas().map(a => Number(a.asignacion_id) || 0)) + 1;
      const ahora = () => new Date().toISOString();
      const ocupacion = new Map();
      const docentesOcupados = new Map();
      const tecnologiaPorAula = new Map();
      for (const rel of AulaTecnologia.listarTodas()) {
        if (!tecnologiaPorAula.has(rel.aula_id)) tecnologiaPorAula.set(rel.aula_id, new Set());
        const t = Tecnologia.porId(rel.tec_id);
        if (t) tecnologiaPorAula.get(rel.aula_id).add(t.tec_nombre.trim().toLowerCase());
      }
      for (const a of Asignacion.confirmadas()) {
        const f = FranjaHoraria.porId(a.franja_id);
        const c = Curso.porId(a.curso_id);
        if (f && a.aula_id != null) registrarOcupacion(ocupacion, a.aula_id, f);
        if (f && c) registrarOcupacion(docentesOcupados, c.curso_docente.trim().toLowerCase(), f);
      }

      for (const curso of pendientes) {
        const sesionesNecesarias = Number(curso.curso_sesiones_semana || 1);
        const candidatos = [];
        const tecnologiaRequerida = String(curso.curso_tec_requerida || '').trim().toLowerCase();
        for (const aula of aulas) {
          if (aula.aula_estado !== 'Activa' || aula.aula_capacidad < curso.curso_num_estudiantes) continue;
          const tieneTecnologia = tecnologiaPorAula.get(aula.aula_id)?.has(tecnologiaRequerida) ?? false;
          if (!tieneTecnologia) continue;
          for (const franjaBase of franjas) {
            for (const franja of ventanasEnFranja(franjaBase, curso)) {
              if (aulaOcupadaEn(aula.aula_id, franja, ocupacion)) continue;
              if (docenteOcupadoEn(curso, franja, docentesOcupados)) continue;
              const score = calcularPuntajeRapido(curso, aula, pesos, true);
              candidatos.push({ curso, aula, franja, ...score });
            }
          }
        }
        candidatos.sort((a, b) => { if (b.total !== a.total) return b.total-a.total; return a.aula.aula_id-b.aula.aula_id; });
        const elegidas = [];
        const dias = new Set();
        for (const candidato of candidatos) {
          if (dias.has(candidato.franja.franja_dia)) continue;
          if (aulaOcupadaEn(candidato.aula.aula_id, candidato.franja, ocupacion)) continue;
          if (docenteOcupadoEn(curso, candidato.franja, docentesOcupados)) continue;
          elegidas.push(candidato); dias.add(candidato.franja.franja_dia);
          if (elegidas.length === sesionesNecesarias) break;
        }
        if (elegidas.length < sesionesNecesarias) {
          const conflicto = { asignacion_id: nextAsignacionId++, curso_id: curso.curso_id, aula_id: null, franja_id: null, asignacion_puntaje: 0, asignacion_tipo: 'automática', asignacion_estado: 'conflicto', usu_id_mod: null, asignacion_fecha_mod: ahora() };
          asignacionesNuevas.push(conflicto);
          resultados.push({ curso_id: curso.curso_id, curso_nombre: curso.curso_nombre, estado: 'conflicto', motivo: `No hay ${sesionesNecesarias} sesiones semanales disponibles en días distintos para la duración configurada.`, asignacion: conflicto });
          continue;
        }
        const asignacionesCurso = [];
        for (const mejor of elegidas) {
          const creado = { asignacion_id: nextAsignacionId++, curso_id: curso.curso_id, aula_id: mejor.aula.aula_id, franja_id: mejor.franja.franja_id, asignacion_hora_inicio: mejor.franja.franja_hora_inicio, asignacion_hora_fin: mejor.franja.franja_hora_fin, asignacion_puntaje: mejor.total, asignacion_tipo: 'automática', asignacion_estado: 'confirmada', usu_id_mod: null, asignacion_fecha_mod: ahora() };
          asignacionesNuevas.push(creado); asignacionesCurso.push(creado);
          registrarOcupacion(ocupacion, mejor.aula.aula_id, mejor.franja);
          registrarOcupacion(docentesOcupados, curso.curso_docente.trim().toLowerCase(), mejor.franja);
        }
        cursosAsignados.add(curso.curso_id);
        resultados.push({ curso_id: curso.curso_id, curso_nombre: curso.curso_nombre, estado: 'asignado', asignaciones: asignacionesCurso, asignacion: asignacionesCurso[0], puntaje: Number((asignacionesCurso.reduce((s,a)=>s+a.asignacion_puntaje,0)/asignacionesCurso.length).toFixed(2)) });
      }

      if (asignacionesNuevas.length) {
        const idsProcesados = new Set(resultados.map(r => r.curso_id));
        const existentes = Asignacion.listarTodas().filter(a => !(idsProcesados.has(a.curso_id) && a.asignacion_estado === 'conflicto'));
        Almacen.reemplazarColeccion('asignaciones', [...existentes, ...asignacionesNuevas]);
        const baseActual = obtenerBase();
        baseActual.secuencias.asignacion = nextAsignacionId - 1;
      }
      const asignados = resultados.filter(r => r.estado === 'asignado').length;
      const conflictos = resultados.filter(r => r.estado === 'conflicto').length;
      return {
        ok: true,
        facultad_id,
        asignados,
        conflictos,
        totalProcesados: resultados.length,
        duracionMs: Number((performance.now() - inicio).toFixed(2)),
        resultados,
      };
    } finally {
      liberarBloqueo(bloqueo.token);
    }
  }

  static validarAjuste({ asignacion_id, curso_id, aula_id, franja_id, hora_inicio }) {
    const curso = Curso.porId(curso_id);
    const aula = Aula.porId(aula_id);
    const franja = FranjaHoraria.porId(franja_id);
    if (!curso || !aula || !franja) return { ok: false, error: 'La información seleccionada no está disponible.' };
    const inicio = hora_inicio || franja.franja_hora_inicio;
    const ventanas = ventanasEnFranja(franja, curso);
    const ventana = ventanas.find(v => v.franja_hora_inicio === inicio);
    if (!ventana) return { ok: false, error: 'La duración del curso no cabe en la franja seleccionada.' };
    if (aula.aula_estado !== 'Activa') return { ok: false, error: 'El aula seleccionada está inactiva.' };
    if (aula.aula_capacidad < curso.curso_num_estudiantes) return { ok: false, error: 'El aula no tiene capacidad suficiente para el curso.' };
    if (!tecnologiaDisponible(aula.aula_id, curso.curso_tec_requerida)) return { ok: false, error: 'El aula no cuenta con la tecnología obligatoria del curso.' };
    if (combinacionOcupada(aula.aula_id, franja.franja_id, curso_id)) return { ok: false, error: 'El aula ya está ocupada en ese horario.' };
    if (docenteOcupado(curso, franja.franja_id, curso_id)) return { ok: false, error: 'El docente ya tiene un curso asignado en ese horario.' };
    return { ok: true, hora_inicio: ventana.franja_hora_inicio, hora_fin: ventana.franja_hora_fin };
  }

  static ajustarAsignacion(datos, usu_id_mod) {
    const actual = Asignacion.porId(datos.asignacion_id);
    if (!actual) return { ok: false, error: 'La asignación no existe.' };
    const validacion = this.validarAjuste(datos);
    if (!validacion.ok) return validacion;
    const actualizada = Asignacion.actualizar(datos.asignacion_id, {
      aula_id: datos.aula_id,
      franja_id: datos.franja_id,
      asignacion_hora_inicio: validacion.hora_inicio,
      asignacion_hora_fin: validacion.hora_fin,
      asignacion_tipo: 'manual',
      asignacion_estado: 'confirmada',
      usu_id_mod,
    });
    return { ok: true, asignacion: actualizada };
  }
}
