import { sembrarSiVacio } from '../data/semilla.js';
import { Usuario } from '../models/Usuario.js';
import { esContrasenaValida, mostrarErrorCampo, limpiarErrorCampo } from '../utils/validadores.js';
import { mostrarAviso } from '../componentes/interfaz.js';

await sembrarSiVacio();

const parametros = new URLSearchParams(window.location.search);
const token = parametros.get('token') || '';

const textoEstado = document.getElementById('texto-estado');
const formulario = document.getElementById('form-restablecer');
const boton = document.getElementById('boton-restablecer');

function verificarEnlace() {
  const estado = Usuario.verificarTokenRecuperacion(token);
  if (!estado.valido) {
    textoEstado.textContent = estado.error;
    mostrarAviso('zona-aviso', 'error', 'No es posible continuar con este enlace.');
    formulario.querySelectorAll('input, button').forEach((el) => (el.disabled = true));
    return false;
  }
  textoEstado.textContent = 'Ingresa y confirma tu nueva contraseña.';
  return true;
}

verificarEnlace();

formulario.addEventListener('submit', async (evento) => {
  evento.preventDefault();
  mostrarAviso('zona-aviso', null, '');
  limpiarErrorCampo('contrasena');
  limpiarErrorCampo('confirmar');

  const contrasena = document.getElementById('contrasena').value;
  const confirmar = document.getElementById('confirmar').value;

  let valido = true;
  if (!esContrasenaValida(contrasena)) {
    mostrarErrorCampo('contrasena', 'Usa mínimo 8 caracteres, con letras y números.');
    valido = false;
  }
  if (contrasena !== confirmar) {
    mostrarErrorCampo('confirmar', 'Las contraseñas no coinciden.');
    valido = false;
  }
  if (!valido) return;

  // Revalidar el enlace justo antes de guardar, por si venció mientras se escribía.
  if (!verificarEnlace()) return;

  boton.disabled = true;
  boton.textContent = 'Guardando…';

  const resultado = await Usuario.definirNuevaContrasena(token, contrasena);
  if (!resultado.ok) {
    mostrarAviso('zona-aviso', 'error', resultado.error);
    boton.disabled = false;
    boton.textContent = 'Guardar contraseña';
    return;
  }

  mostrarAviso('zona-aviso', 'ok', 'Tu contraseña se actualizó correctamente. Ya puedes iniciar sesión.');
  formulario.querySelectorAll('input, button').forEach((el) => (el.disabled = true));
  setTimeout(() => window.location.replace('index.html'), 1800);
});
