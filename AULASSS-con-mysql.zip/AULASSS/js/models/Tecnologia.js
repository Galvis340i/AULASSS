import { Almacen, siguienteId } from '../data/almacen.js';
const COLECCION='tecnologias';
export class Tecnologia {
  constructor({ tec_id, tec_nombre }) { this.tec_id=tec_id; this.tec_nombre=tec_nombre; }
  static listarTodas(){return Almacen.listar(COLECCION);}
  static porId(id){return Almacen.obtenerPorId(COLECCION,id,'tec_id');}
  static nombreYaExiste(nombre, excluirId=null){const x=nombre.trim().toLowerCase(); return this.listarTodas().some(t=>t.tec_nombre.toLowerCase()===x && t.tec_id!==excluirId);}
  static crear({tec_nombre}){if(this.nombreYaExiste(tec_nombre))return {ok:false,error:'Ya existe una tecnología con ese nombre.'}; const r=Almacen.insertar(COLECCION,{tec_id:siguienteId('tecnologia'),tec_nombre:tec_nombre.trim()}); return {ok:true,tecnologia:r};}
  static actualizar(id,{tec_nombre}){if(this.nombreYaExiste(tec_nombre,id))return {ok:false,error:'Ya existe una tecnología con ese nombre.'}; const r=Almacen.actualizar(COLECCION,id,'tec_id',{tec_nombre:tec_nombre.trim()}); return {ok:true,tecnologia:r};}
  static eliminar(id){if(Almacen.listar('aulaTecnologias').some(r=>r.tec_id===id))return {ok:false,error:'No se puede eliminar una tecnología asociada a un aula.'}; const base=this.listarTodas(); Almacen.reemplazarColeccion(COLECCION,base.filter(t=>t.tec_id!==id)); return {ok:true};}
}
