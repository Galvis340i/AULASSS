-- Esquema de referencia para la futura conexión con MySQL.
-- La aplicación del Ciclo 1 actualmente utiliza localStorage; este archivo
-- no es ejecutado por el frontend.

CREATE TABLE facultad (
  facultad_id INT PRIMARY KEY AUTO_INCREMENT,
  facultad_nombre VARCHAR(120) NOT NULL,
  facultad_estado VARCHAR(20) NOT NULL DEFAULT 'Activa'
);

CREATE TABLE carrera (
  carrera_id INT PRIMARY KEY AUTO_INCREMENT,
  carrera_nombre VARCHAR(120) NOT NULL,
  facultad_id INT NOT NULL,
  carrera_estado VARCHAR(20) NOT NULL DEFAULT 'Activa',
  CONSTRAINT fk_carrera_facultad FOREIGN KEY (facultad_id) REFERENCES facultad(facultad_id),
  CONSTRAINT uq_carrera_facultad_nombre UNIQUE (facultad_id, carrera_nombre)
);

CREATE TABLE usuario (
  usu_id INT PRIMARY KEY AUTO_INCREMENT,
  usu_nombres VARCHAR(100) NOT NULL,
  usu_apellidos VARCHAR(100) NOT NULL,
  usu_correo VARCHAR(180) NOT NULL UNIQUE,
  usu_pwd_hash VARCHAR(255) NOT NULL,
  usu_rol VARCHAR(30) NOT NULL,
  facultad_id INT NULL,
  usu_estado VARCHAR(20) NOT NULL DEFAULT 'Activo',
  CONSTRAINT fk_usuario_facultad FOREIGN KEY (facultad_id) REFERENCES facultad(facultad_id)
);

CREATE TABLE recuperacion_contrasena (
  token VARCHAR(48) PRIMARY KEY,
  usu_id INT NOT NULL,
  creado DATETIME NOT NULL,
  expira DATETIME NOT NULL,
  usada BOOLEAN NOT NULL DEFAULT FALSE,
  CONSTRAINT fk_recuperacion_usuario FOREIGN KEY (usu_id) REFERENCES usuario(usu_id)
);
