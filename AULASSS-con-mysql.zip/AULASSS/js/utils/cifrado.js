// Cifrado de contraseñas en el navegador para esta versión de datos simulados.
// Cuando el sistema se conecte a MySQL, este módulo se reemplaza por el
// cifrado con bcrypt/Argon2 ejecutado en el servidor; aquí ninguna contraseña
// se guarda ni se muestra en texto plano.

export async function cifrarContrasena(textoPlano) {
  const datos = new TextEncoder().encode(textoPlano);
  const hashBuffer = await crypto.subtle.digest('SHA-256', datos);
  const bytes = Array.from(new Uint8Array(hashBuffer));
  return bytes.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function verificarContrasena(textoPlano, hashAlmacenado) {
  const hashCalculado = await cifrarContrasena(textoPlano);
  return hashCalculado === hashAlmacenado;
}

export function generarTokenUnico() {
  const arreglo = new Uint8Array(24);
  crypto.getRandomValues(arreglo);
  return Array.from(arreglo, (b) => b.toString(16).padStart(2, '0')).join('');
}
