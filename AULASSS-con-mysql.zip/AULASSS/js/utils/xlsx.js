// Parser XLSX mínimo para lectura de archivos .xlsx sin dependencias externas.
// Soporta la estructura habitual de hojas de cálculo generadas por Excel/LibreOffice.
const textDecoder = new TextDecoder('utf-8');

function u16(a,o){return a[o]|(a[o+1]<<8)}
function u32(a,o){return (a[o]|(a[o+1]<<8)|(a[o+2]<<16)|(a[o+3]<<24))>>>0}
function bytesToString(a){return textDecoder.decode(a)}

async function inflate(raw){
  const ds = new DecompressionStream('deflate-raw');
  const stream = new Blob([raw]).stream().pipeThrough(ds);
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

function findEndOfCentralDirectory(a){
  for(let i=a.length-22;i>=Math.max(0,a.length-22-65535);i--){
    if(u32(a,i)===0x06054b50)return i;
  }
  throw new Error('El archivo XLSX no tiene una estructura ZIP válida.');
}

async function unzip(buffer){
  const a=new Uint8Array(buffer), eocd=findEndOfCentralDirectory(a), count=u16(a,eocd+10), cdSize=u32(a,eocd+12), cdOffset=u32(a,eocd+16);
  const entries=new Map(); let p=cdOffset;
  for(let i=0;i<count;i++){
    if(u32(a,p)!==0x02014b50) throw new Error('Entrada ZIP inválida.');
    const method=u16(a,p+10), compSize=u32(a,p+20), uncompSize=u32(a,p+24), nameLen=u16(a,p+28), extraLen=u16(a,p+30), commentLen=u16(a,p+32), localOffset=u32(a,p+42);
    const name=bytesToString(a.slice(p+46,p+46+nameLen));
    const lp=localOffset;
    if(u32(a,lp)!==0x04034b50) throw new Error('Cabecera ZIP inválida.');
    const ln=u16(a,lp+26), le=u16(a,lp+28), start=lp+30+ln+le;
    const raw=a.slice(start,start+compSize);
    let data;
    if(method===0)data=raw; else if(method===8)data=await inflate(raw); else throw new Error(`Compresión XLSX no soportada: ${method}.`);
    if(uncompSize && data.length!==uncompSize) throw new Error('El archivo XLSX está incompleto o dañado.');
    entries.set(name,data); p+=46+nameLen+extraLen+commentLen;
  }
  return entries;
}

function xml(entries,name){const d=entries.get(name);if(!d)throw new Error(`Falta ${name} en el XLSX.`);return new DOMParser().parseFromString(bytesToString(d),'application/xml')}
function local(el,n){return el.getElementsByTagNameNS('*',n)}
function attr(el,n){return el.getAttribute(n)||el.getAttributeNS(null,n)}
function colIndex(ref){let s=ref.replace(/\d/g,''),n=0;for(const c of s)n=n*26+c.charCodeAt(0)-64;return n-1}

export async function leerXlsx(file){
  if(!file.name.toLowerCase().endsWith('.xlsx'))throw new Error('El archivo no tiene extensión .xlsx.');
  const entries=await unzip(await file.arrayBuffer());
  const shared=[];
  if(entries.has('xl/sharedStrings.xml')){
    const doc=xml(entries,'xl/sharedStrings.xml');
    for(const si of local(doc,'si')) shared.push(Array.from(local(si,'t')).map(t=>t.textContent).join(''));
  }
  const wb=xml(entries,'xl/workbook.xml');
  const rels=xml(entries,'xl/_rels/workbook.xml.rels');
  const relMap=new Map(Array.from(local(rels,'Relationship')).map(r=>[attr(r,'Id'),attr(r,'Target')]));
  const sheets=Array.from(local(wb,'sheet'));
  if(!sheets.length)throw new Error('El XLSX no contiene hojas.');
  const rid=attr(sheets[0],'r:id')||attr(sheets[0],'id');
  let target=relMap.get(rid)||'worksheets/sheet1.xml';
  target=target.replace(/^\//,''); if(!target.startsWith('xl/'))target='xl/'+target.replace(/^\.\//,'');
  const doc=xml(entries,target), rows=[];
  for(const row of local(doc,'row')){
    const cells=Array.from(local(row,'c')), vals=[]; let cursor=0;
    for(const c of cells){
      const ref=attr(c,'r')||''; const idx=ref?colIndex(ref):cursor;
      while(vals.length<idx)vals.push('');
      const type=attr(c,'t'); let value='';
      if(type==='inlineStr') value=Array.from(local(c,'t')).map(t=>t.textContent).join('');
      else { const v=local(c,'v')[0]; value=v?.textContent||''; if(type==='s') value=shared[Number(value)]??''; }
      vals[idx]=value; cursor=idx+1;
    }
    while(vals.length&&vals[vals.length-1]==='')vals.pop(); rows.push(vals);
  }
  return {sheetName:attr(sheets[0],'name')||'Hoja 1',rows};
}
