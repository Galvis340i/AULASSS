import { Almacen, siguienteId } from '../data/almacen.js';
import { Aula } from '../models/Aula.js';
import { Curso } from '../models/Curso.js';
import { Carrera } from '../models/Carrera.js';
import { Tecnologia } from '../models/Tecnologia.js';
import { ROLES } from '../data/constantes.js';

const LIMITE=5*1024*1024;
const CLAVE_BLOQUEO='aulas_carga_bloqueo_v1';
function adquirirCarga(){const a=JSON.parse(localStorage.getItem(CLAVE_BLOQUEO)||'null');if(a&&Date.now()-a.creado<120000)return null;const token=`${Date.now()}-${Math.random().toString(36).slice(2)}`;localStorage.setItem(CLAVE_BLOQUEO,JSON.stringify({token,creado:Date.now()}));return token;}
function liberarCarga(token){const a=JSON.parse(localStorage.getItem(CLAVE_BLOQUEO)||'null');if(a?.token===token)localStorage.removeItem(CLAVE_BLOQUEO);}
const NORMAL=s=>String(s??'').trim();
const CLAVES={aulas:['aula_codigo','aula_edificio','aula_capacidad','aula_tipo','aula_estado'],cursos:['curso_nombre','carrera_nombre','curso_docente','curso_num_estudiantes','curso_tec_requerida','curso_prioridad']};
function parseCsv(text){
  const rows=[]; let row=[],cell='',quoted=false;
  for(let i=0;i<text.length;i++){const ch=text[i],next=text[i+1]; if(quoted){if(ch==='"'&&next==='"'){cell+='"';i++;}else if(ch==='"')quoted=false;else cell+=ch;}else if(ch==='"')quoted=true;else if(ch===','){row.push(cell);cell='';}else if(ch==='\n'){row.push(cell.replace(/\r$/,''));rows.push(row);row=[];cell='';}else cell+=ch;}
  if(cell.length||row.length){row.push(cell.replace(/\r$/,''));rows.push(row);} return rows;
}
export async function leerArchivo(file){
  if(file.size>LIMITE) throw new Error('El archivo supera el tamaño máximo permitido de 5 MB.');
  if(file.name.toLowerCase().endsWith('.csv')) return parseCsv(await file.text());
  if(file.name.toLowerCase().endsWith('.xlsx')) { const mod=await import('../utils/xlsx.js'); return (await mod.leerXlsx(file)).rows; }
  throw new Error('Formato no permitido. Selecciona un archivo .xlsx o .csv.');
}

export function validarFilas(tipo,rows,usuario=null){
  if(!rows.length)return {ok:false,errores:['El archivo no contiene filas.'],registros:[]};
  const headers=rows[0].map(h=>NORMAL(h).toLowerCase());
  const esperadas=CLAVES[tipo];
  const faltantes=esperadas.filter(h=>!headers.includes(h));
  if(faltantes.length)return {ok:false,errores:[`Faltan columnas obligatorias: ${faltantes.join(', ')}.`],registros:[]};
  const registros=rows.slice(1).filter(r=>r.some(v=>NORMAL(v))).map((r,i)=>{const o={};headers.forEach((h,j)=>o[h]=NORMAL(r[j]));o.__fila=i+2;return o;});
  const errores=[];
  if(usuario?.usu_rol===ROLES.COORDINADOR && tipo==='aulas') return {ok:false,errores:['El coordinador no tiene permisos para cargar aulas.'],registros:[]};
  const existentesAulas=new Set(Aula.listarTodas().map(a=>a.aula_codigo.toLowerCase()));
  const existentesCursos=new Set(Curso.listarTodas().map(c=>c.curso_nombre.toLowerCase()));
  const vistos=new Set();
  registros.forEach(o=>{
    const fila=o.__fila;
    if(tipo==='aulas'){
      if(!o.aula_codigo)errores.push(`Fila ${fila}: el código del aula es obligatorio.`);
      if(!o.aula_edificio)errores.push(`Fila ${fila}: el edificio es obligatorio.`);
      const cap=Number(o.aula_capacidad); if(!Number.isInteger(cap)||cap<=0)errores.push(`Fila ${fila}: la capacidad debe ser un entero mayor que 0.`);
      if(!['Salón','Laboratorio','Auditorio'].includes(o.aula_tipo))errores.push(`Fila ${fila}: el tipo de aula debe ser Salón, Laboratorio o Auditorio.`);
      const estado=o.aula_estado||'Activa'; if(!['Activa','Inactiva'].includes(estado))errores.push(`Fila ${fila}: el estado debe ser Activa o Inactiva.`);
      const k=o.aula_codigo.toLowerCase(); if(existentesAulas.has(k)||vistos.has(k))errores.push(`Fila ${fila}: el código de aula ya existe.`); vistos.add(k);
    } else {
      if(!o.curso_nombre)errores.push(`Fila ${fila}: el nombre del curso es obligatorio.`);
      const carrera=Carrera.listarTodas().find(c=>c.carrera_nombre.toLowerCase()===o.carrera_nombre.toLowerCase()&&c.carrera_estado==='Activa'); if(!carrera)errores.push(`Fila ${fila}: la carrera indicada no existe o está inactiva.`); else if(usuario?.usu_rol===ROLES.COORDINADOR && carrera.facultad_id!==usuario.facultad_id) errores.push(`Fila ${fila}: la carrera no pertenece a tu facultad.`);
      if(!o.curso_docente)errores.push(`Fila ${fila}: el docente es obligatorio.`);
      const n=Number(o.curso_num_estudiantes);if(!Number.isInteger(n)||n<=0)errores.push(`Fila ${fila}: el número de estudiantes debe ser un entero mayor que 0.`);
      if(!Tecnologia.listarTodas().some(t=>t.tec_nombre.toLowerCase()===o.curso_tec_requerida.toLowerCase()))errores.push(`Fila ${fila}: la tecnología obligatoria no existe en el catálogo.`);
      if(!['Baja','Media','Alta'].includes(o.curso_prioridad))errores.push(`Fila ${fila}: la prioridad debe ser Baja, Media o Alta.`);
      const k=o.curso_nombre.toLowerCase();if(existentesCursos.has(k)||vistos.has(k))errores.push(`Fila ${fila}: el curso ya existe.`);vistos.add(k);
    }
  });
  return {ok:errores.length===0,errores,registros};
}
export function confirmarCarga(tipo,registros,usuarioId){
  if(!registros.length)return {ok:false,error:'No hay registros para cargar.'};
  const token=adquirirCarga(); if(!token)return {ok:false,error:'Ya existe una carga de información en curso. Espera a que finalice.'};
  const inicio=performance.now();
  try {
  if(tipo==='aulas'){
    const base=Almacen.listar('aulas'); let id=Math.max(0,...base.map(a=>Number(a.aula_id)||0));
    const nuevos=registros.map(o=>({aula_id:++id,aula_codigo:o.aula_codigo,aula_edificio:o.aula_edificio,aula_capacidad:Number(o.aula_capacidad),aula_tipo:o.aula_tipo,aula_estado:o.aula_estado||'Activa'}));
    Almacen.insertarMasivo('aulas',nuevos); Almacen.fijarSecuencia('aula',id);
  }else{
    const base=Almacen.listar('cursos'); let id=Math.max(0,...base.map(c=>Number(c.curso_id)||0));
    const carreras=Carrera.listarTodas(); const nuevos=registros.map(o=>{const carrera=carreras.find(c=>c.carrera_nombre.toLowerCase()===o.carrera_nombre.toLowerCase());return {curso_id:++id,curso_nombre:o.curso_nombre,carrera_id:carrera.carrera_id,curso_docente:o.curso_docente,curso_num_estudiantes:Number(o.curso_num_estudiantes),curso_tec_requerida:o.curso_tec_requerida,curso_prioridad:o.curso_prioridad};});
    Almacen.insertarMasivo('cursos',nuevos); Almacen.fijarSecuencia('curso',id);
  }
  return {ok:true,cargados:registros.length,ms:Math.round(performance.now()-inicio),usuarioId};
  } finally { liberarCarga(token); }
}
export const CARGA_FORMATOS={aulas:['aula_codigo','aula_edificio','aula_capacidad','aula_tipo','aula_estado'],cursos:['curso_nombre','carrera_nombre','curso_docente','curso_num_estudiantes','curso_tec_requerida','curso_prioridad']};
export { ROLES };
