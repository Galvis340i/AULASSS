import { sembrarSiVacio } from '../data/semilla.js';
import { Usuario } from '../models/Usuario.js';
import { campoNoVacio, limpiarErrorCampo, mostrarErrorCampo } from '../utils/validadores.js';
import { mostrarAviso } from '../componentes/interfaz.js';

await sembrarSiVacio();

const formulario = document.getElementById('form-recuperar');
const boton = document.getElementById('boton-recuperar');

formulario.addEventListener('submit', async (evento) => {
  evento.preventDefault();
  mostrarAviso('zona-aviso', null, '');
  limpiarErrorCampo('correo');

  const correo = document.getElementById('correo').value.trim();
  if (!campoNoVacio(correo)) {
    mostrarErrorCampo('correo', 'Ingresa tu correo institucional.');
    return;
  }

  boton.disabled = true;
  boton.textContent = 'Enviando…';

  await Usuario.recuperarContrasena(correo);

  mostrarAviso(
    'zona-aviso',
    'ok',
    'Si el correo está registrado, en unos minutos llegará un enlace de un solo uso para definir tu nueva contraseña. El enlace vence pronto, así que revisa tu bandeja de inmediato.'
  );
  formulario.reset();
  boton.disabled = false;
  boton.textContent = 'Enviar enlace';
});

document.getElementById('correo').addEventListener('input', () => limpiarErrorCampo('correo'));
