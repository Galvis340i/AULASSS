import { Almacen, siguienteId } from '../data/almacen.js';

const COLECCION = 'facultades';

export class Facultad {
  constructor({ facultad_id, facultad_nombre, facultad_estado }) {
    this.facultad_id = facultad_id;
    this.facultad_nombre = facultad_nombre;
    this.facultad_estado = facultad_estado;
  }

  static listarTodas() {
    return Almacen.listar(COLECCION);
  }

  static porId(id) {
    return Almacen.obtenerPorId(COLECCION, id, 'facultad_id');
  }

  static nombreYaExiste(nombre, excluirId = null) {
    const objetivo = nombre.trim().toLowerCase();
    return Facultad.listarTodas().some(
      (f) => f.facultad_nombre.trim().toLowerCase() === objetivo && f.facultad_id !== excluirId
    );
  }

  static crear({ facultad_nombre }) {
    if (Facultad.nombreYaExiste(facultad_nombre)) {
      return { ok: false, error: 'Ya existe una facultad con ese nombre.' };
    }
    const registro = Almacen.insertar(COLECCION, {
      facultad_id: siguienteId('facultad'),
      facultad_nombre: facultad_nombre.trim(),
      facultad_estado: 'Activa',
    });
    return { ok: true, facultad: registro };
  }

  static actualizar(facultad_id, { facultad_nombre }) {
    if (Facultad.nombreYaExiste(facultad_nombre, facultad_id)) {
      return { ok: false, error: 'Ya existe una facultad con ese nombre.' };
    }
    const registro = Almacen.actualizar(COLECCION, facultad_id, 'facultad_id', {
      facultad_nombre: facultad_nombre.trim(),
    });
    return { ok: true, facultad: registro };
  }

  static cambiarEstado(facultad_id, nuevoEstado) {
    return Almacen.actualizar(COLECCION, facultad_id, 'facultad_id', { facultad_estado: nuevoEstado });
  }
}
