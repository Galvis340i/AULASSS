import { ROLES } from './constantes.js';

const ICONOS = {
  reporte: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19V5M4 19h16"/><path d="M7 15l3-4 3 2 4-6"/></svg>',
  inicio:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 11.5 12 4l8 7.5"/><path d="M6 10v9a1 1 0 0 0 1 1h3v-6h4v6h3a1 1 0 0 0 1-1v-9"/></svg>',
  usuarios:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8" r="3.2"/><path d="M2.8 19c.7-3 3-4.8 6.2-4.8s5.5 1.8 6.2 4.8"/><circle cx="17" cy="7.5" r="2.4"/><path d="M15.8 14.6c2.5.4 4.2 2 4.8 4.4"/></svg>',
  facultad:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9.5 12 4l9 5.5-9 5.5-9-5.5Z"/><path d="M6.5 11.7V17c0 1 2.5 2.3 5.5 2.3s5.5-1.3 5.5-2.3v-5.3"/></svg>',
  carrera:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 4v16M4 9h4M4 15h4"/></svg>',
  aula:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 20h18M5 20V7h14v13M8 10h2m2 0h2m-6 4h2m2 0h2"/></svg>',
  tecnologia:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
  curso:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21V5.5Z"/><path d="M4 5.5V21"/></svg>',
  horario:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/></svg>',
  docente:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="3.4"/><path d="M5 20c1-4 3.6-6 7-6s6 2 7 6"/></svg>',
};

export const MENU_POR_ROL = {
  [ROLES.ADMIN_SISTEMA]: [
    { href: 'panel-administrador.html', texto: 'Inicio', icono: ICONOS.inicio },
    { href: 'administrador-usuarios.html', texto: 'Usuarios', icono: ICONOS.usuarios },
    { href: 'administrador-facultades.html', texto: 'Facultades', icono: ICONOS.facultad },
    { href: 'administrador-carreras.html', texto: 'Carreras', icono: ICONOS.carrera },
    { href: 'franjas.html', texto: 'Franjas horarias', icono: ICONOS.horario },
    { href: 'parametros-peso.html', texto: 'Parámetros de asignación', icono: ICONOS.carrera },
  ],
  [ROLES.COORDINADOR]: [
    { href: 'panel-coordinador.html', texto: 'Inicio', icono: ICONOS.inicio },
    { href: 'coordinador-docentes.html', texto: 'Docentes de mi facultad', icono: ICONOS.docente },
    { href: 'cursos.html', texto: 'Cursos', icono: ICONOS.curso },
    { href: 'franjas.html', texto: 'Franjas horarias', icono: ICONOS.horario },
    { href: 'asignaciones.html', texto: 'Asignaciones', icono: ICONOS.aula },
    { href: 'carga-masiva.html', texto: 'Cargar información', icono: ICONOS.aula },
    { href: 'reportes.html', texto: 'Reportes', icono: ICONOS.reporte },
  ],
  [ROLES.DOCENTE]: [{ href: 'panel-docente.html', texto: 'Inicio', icono: ICONOS.inicio }],
  [ROLES.ADMIN_PLANTA]: [
    { href: 'panel-planta-fisica.html', texto: 'Inicio', icono: ICONOS.inicio },
    { href: 'aulas.html', texto: 'Aulas', icono: ICONOS.aula },
    { href: 'tecnologias.html', texto: 'Tecnologías', icono: ICONOS.tecnologia },
    { href: 'carga-masiva.html', texto: 'Cargar información', icono: ICONOS.aula },
  ],
  [ROLES.DECANO]: [{ href: 'panel-decano.html', texto: 'Inicio', icono: ICONOS.inicio },
    { href: 'reportes.html', texto: 'Reportes', icono: ICONOS.reporte },],
};
