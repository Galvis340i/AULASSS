# Registro de revisión — Ciclo 1

## Revisión realizada

Se revisó la implementación del primer ciclo frente al modelo de identidad y estructura académica: usuarios, inicio/cierre de sesión, recuperación de contraseña, facultades y carreras.

## Resultado de la ejecución automática

Ejecutar:

```bash
npm run test:ciclo1
```

El resultado esperado es:

```text
Resultado: TODAS LAS PRUEBAS APROBADAS.
```

## Evidencia del riesgo de cronograma

La validación del modelo de roles se incorporó al cierre del Ciclo 1 antes de continuar con los módulos del siguiente ciclo. La evidencia técnica de funcionamiento queda en la matriz de pruebas; la evidencia de seguimiento del cronograma corresponde al registro de revisión del proyecto.

## Observación de alcance detectada

La especificación del registro de docentes menciona indicar la carrera correspondiente, mientras que el modelo de Usuario entregado en la documentación solo contempla `facultad_id` y no contempla `carrera_id`. En este ciclo no se agregó un campo que contradiga el modelo aprobado. La decisión debe resolverse antes de implementar el flujo de cursos/docentes que dependa de esa relación.

## Observación de seguridad

La versión actual funciona sin backend y usa datos simulados en el navegador. La contraseña no se conserva en texto plano. La implementación de producción deberá trasladar el almacenamiento de contraseñas al servidor y utilizar el mecanismo de hashing seguro indicado en los requerimientos cuando se conecte con MySQL.
